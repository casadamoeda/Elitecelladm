# EliteCell v7 — Relatório de Implementação Offline-First

---

## Arquivos Criados

| Arquivo | Função |
|---|---|
| `lib/db.js` | Banco local IndexedDB via Dexie.js. Todas as tabelas, helpers de CRUD local e controle de status de sync |
| `lib/offlineFirestore.js` | Camada offline-first: lê do IndexedDB, escreve local imediatamente e sobe ao Firebase quando online. Exporta os mesmos módulos da API original |
| `lib/syncEngine.js` | Motor de sincronização. Processa a fila de pendentes e sobe ao Firebase quando a conexão volta |
| `lib/contexts/ConnectionContext.js` | Contexto React de conexão: status online/offline/syncing, contador de pendentes, última sync |
| `components/ConnectionIndicator.js` | Indicador visual no topo: 🟢 Online / 🔴 Offline / 🔄 Sincronizando. Clicável, abre tela de sync |
| `app/(app)/sincronizacao/page.js` | Tela de sincronização: pendentes por módulo, última sync, botão "Sincronizar agora" |
| `public/offline.html` | Página de fallback quando não há cache e está offline |

---

## Arquivos Alterados

| Arquivo | O que mudou |
|---|---|
| `lib/firestore.js` | Substituído por re-export de `offlineFirestore.js`. Nenhum módulo precisou ser alterado |
| `app/layout.js` | Adicionado `ConnectionProvider` envolvendo toda a app + `RegisterSW` |
| `components/Sidebar.js` | `ConnectionIndicator` na top bar mobile e no menu lateral + link para `/sincronizacao` |
| `public/sw.js` | Reescrito completo: Cache First para assets, Stale-While-Revalidate para páginas, pré-cache de todas as rotas |
| `app/(app)/ordens/editar/page.js` | Substituído `getDoc/updateDoc` direto por `ordensDb.get/update` offline-first |
| `app/(app)/ordens/imprimir/page.js` | Substituído por `ordensDb.get` + `pecasDb.byOrdem` offline-first |
| `app/(app)/ordens/detalhe/page.js` | `fetchPecasOrdem` reescrito via `pecas.byOrdem` offline-first |
| `app/(app)/clientes/detalhe/page.js` | `fetchOrdensDoCliente` reescrito via `ordens.byCliente` offline-first |
| `app/(app)/garantias/nova/page.js` | `fetchPecasOrdem` reescrito offline-first |
| `app/(app)/garantias/page.js` | Removidos imports Firebase diretos desnecessários |
| `app/acompanhar/[numero]/AcompanharClient.js` | Fallback offline: se Firebase falhar, busca a OS no IndexedDB local |

---

## Estrutura de Sincronização

```
ESCRITA
  ↓
localAdd/localUpdate/localDelete  (IndexedDB — instantâneo)
  ↓ (se online)
Firebase                          (em paralelo, não bloqueia UI)
  ↓ (se offline)
_syncStatus = 'pending_add'       (fica na fila)
  |         = 'pending_update'
  |         = 'pending_delete'
  ↓ (quando volta a internet)
syncEngine.runSync()              (processa toda a fila)
  ↓
Firebase atualizado + local marcado como 'synced'

LEITURA
  ↓
IndexedDB local                   (instantâneo, sempre funciona)
  ↓ (se online, em background)
Firebase → replaceAllFromServer   (atualiza o cache local)
```

---

## Como Funciona o Modo Offline

1. **Instalação do PWA**: Service Worker pré-cacheia todas as páginas e assets na instalação.

2. **Abertura sem internet**: O SW entrega as páginas do cache. O app abre normalmente.

3. **Leitura de dados**: Toda leitura vai direto ao IndexedDB local — instantânea, sem rede.

4. **Escrita sem internet**: O dado é salvo localmente com `_syncStatus: 'pending_add/update/delete'`. O usuário vê o dado imediatamente.

5. **Quando a internet volta**: O evento `window.online` dispara o `syncEngine.runSync()` que processa toda a fila de pendentes e sobe ao Firebase.

6. **Resolução de conflito**: `replaceAllFromServer` preserva registros locais pendentes — nunca sobrescreve dados que ainda não subiram.

7. **Dados nunca perdidos**: IndexedDB persiste após fechar o app, reiniciar o celular ou acabar a bateria.

---

## Como Testar o Modo Offline

### No Chrome / Android

1. Abra o app e faça login
2. Navegue por todas as páginas para popular o cache
3. Abra DevTools → Network → selecione **Offline**
4. Recarregue — o app deve abrir normalmente
5. Cadastre um cliente, crie uma OS
6. Observe o badge amarelo com número de pendentes no indicador de conexão
7. Volte para **Online** — o sync acontece automaticamente em ~2s
8. Verifique no Firebase Console que os dados chegaram

### No celular Android (campo)

1. Instale como PWA (Adicionar à tela inicial)
2. Ative o modo avião
3. Abra o app — deve funcionar completamente
4. Crie OSs, clientes, atualize status
5. Desative o modo avião
6. O indicador muda para 🔄 e em seguida 🟢
7. Toast "Dados sincronizados com sucesso." aparece

### Tela de Sincronização

- Acesse pelo indicador no topo ou menu lateral → "Sincronização"
- Mostra quantidade de pendentes por módulo
- Botão "Sincronizar agora" para forçar sync manual

---

## Dependência Adicionada

```json
"dexie": "3.2.7"
```

Execute `npm install` após extrair o ZIP.

---

## Compatibilidade

- ✅ Android Chrome
- ✅ Samsung Internet
- ✅ PWA instalado (standalone)
- ✅ Modo avião
- ✅ Sinal instável
- ✅ App fechado e reaberto offline
- ✅ Celular reiniciado
