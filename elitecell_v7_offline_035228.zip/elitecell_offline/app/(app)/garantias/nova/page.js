'use client'
import { useEffect, useState, Suspense } from 'react'
import { useRouter, useSearchParams } from 'next/navigation'
import { garantias as db, ordens as ordensDb, fornecedores as fornDb } from '@/lib/firestore'
import toast from 'react-hot-toast'
import { addDays, format } from 'date-fns'
import { ptBR } from 'date-fns/locale'
import { ArrowLeft, Shield, Search } from 'lucide-react'

async function fetchPecasOrdem(ordemId) {
  if (!ordemId) return []
  try {
    const { pecas } = await import('@/lib/firestore')
    return await pecas.byOrdem(ordemId)
  } catch { return [] }
}

function NovaGarantiaInner() {
  const router  = useRouter()
  const params  = useSearchParams()
  const [form, setForm] = useState({
    clienteNome:'', osNumero:'', ordemId:'',
    descricao:'', tipo:'servico',
    pecaId:'', pecaNome:'', fornecedorNome:'', fornecedorId:'',
    dataInicio: format(new Date(),'yyyy-MM-dd'),
    diasGarantia:'90',
  })
  const [ordens, setOrdens] = useState([])
  const [pecas,  setPecas]  = useState([])
  const [saving, setSaving] = useState(false)
  const [loading, setLoad]  = useState(true)

  useEffect(() => {
    ordensDb.list().then(o => {
      setOrdens(o)
      const ordemId = params.get('ordemId') || ''
      if (ordemId) {
        const os = o.find(x=>x.id===ordemId)
        if (os) {
          setForm(p=>({...p, ordemId, osNumero:os.numero, clienteNome:os.clienteNome}))
          fetchPecasOrdem(ordemId).then(setPecas)
        }
      }
      setLoad(false)
    })
  }, [])

  const set = (f,v) => setForm(p=>({...p,[f]:v}))

  const handleOrdem = async (ordemId) => {
    const os = ordens.find(x=>x.id===ordemId)
    if (os) {
      set('ordemId', ordemId); set('osNumero', os.numero); set('clienteNome', os.clienteNome)
      const p = await fetchPecasOrdem(ordemId)
      setPecas(p)
    } else {
      set('ordemId',''); set('osNumero',''); setPecas([])
    }
  }

  const handlePeca = (pecaId) => {
    const p = pecas.find(x=>x.id===pecaId)
    if (p) {
      set('pecaId', pecaId); set('pecaNome', p.nome)
      set('fornecedorNome', p.fornecedorNome||''); set('fornecedorId', p.fornecedorId||'')
      if (!form.descricao) set('descricao', `Garantia: ${p.nome}`)
    } else {
      set('pecaId',''); set('pecaNome','')
    }
  }

  const dataExpiracao = form.dataInicio
    ? format(addDays(new Date(form.dataInicio), parseInt(form.diasGarantia)||90), 'yyyy-MM-dd')
    : ''

  const save = async () => {
    if (!form.clienteNome||!form.descricao) return toast.error('Preencha cliente e descrição')
    setSaving(true)
    try {
      await db.add({
        ...form,
        diasGarantia: parseInt(form.diasGarantia)||90,
        dataExpiracao,
      })
      toast.success('Garantia registrada!')
      router.back()
    } catch { toast.error('Erro ao salvar') } finally { setSaving(false) }
  }

  if (loading) return <div className="flex justify-center py-20"><div className="w-6 h-6 border-2 border-neon border-t-transparent rounded-full animate-spin"/></div>

  return (
    <div className="fu">
      <div className="flex items-center gap-3 mb-6">
        <button onClick={()=>router.back()} className="p-2 hover:bg-surface-light rounded-lg transition-colors flex-shrink-0">
          <ArrowLeft className="w-5 h-5 text-gray-400"/>
        </button>
        <div>
          <h1 className="text-xl font-black flex items-center gap-2"><Shield className="w-5 h-5 text-neon"/>Nova Garantia</h1>
          <p className="text-xs text-gray-500">Vincule à OS e peça</p>
        </div>
      </div>

      <div className="flex flex-col gap-4 mb-6">
        {/* Selecionar OS */}
        <div>
          <label className="lbl">Ordem de Serviço</label>
          <select value={form.ordemId} onChange={e=>handleOrdem(e.target.value)} className="input-dark">
            <option value="">Selecione a OS...</option>
            {ordens.map(o=><option key={o.id} value={o.id}>OS #{o.numero} — {o.clienteNome} ({o.marca} {o.modelo})</option>)}
          </select>
        </div>

        {/* Info auto-preenchida */}
        {form.clienteNome && (
          <div style={{background:'rgba(0,255,65,0.05)',border:'1px solid rgba(0,255,65,0.2)',borderRadius:12,padding:12}}>
            <p className="text-xs text-neon font-bold mb-1">Cliente</p>
            <p className="text-sm text-white">{form.clienteNome}</p>
          </div>
        )}

        {/* Peça vinculada */}
        {pecas.length > 0 && (
          <div>
            <label className="lbl">Peça utilizada (opcional)</label>
            <select value={form.pecaId} onChange={e=>handlePeca(e.target.value)} className="input-dark">
              <option value="">Sem vínculo com peça específica</option>
              {pecas.map(p=><option key={p.id} value={p.id}>{p.nome}{p.fornecedorNome?` — ${p.fornecedorNome}`:''}</option>)}
            </select>
            {form.pecaId && form.fornecedorNome && (
              <p className="text-xs text-gray-500 mt-1">Fornecedor: {form.fornecedorNome}</p>
            )}
          </div>
        )}

        <div>
          <label className="lbl">Tipo</label>
          <div className="flex gap-2">
            {[['servico','Serviço'],['peca','Peça'],['ambos','Serviço + Peça']].map(([v,l])=>(
              <button key={v} type="button" onClick={()=>set('tipo',v)}
                className={`flex-1 py-2.5 rounded-xl text-xs font-bold border transition-all ${form.tipo===v?'bg-neon/10 border-neon/40 text-neon':'border-surface-border text-gray-500'}`}>
                {l}
              </button>
            ))}
          </div>
        </div>

        <div>
          <label className="lbl">Descrição *</label>
          <input type="text" value={form.descricao} onChange={e=>set('descricao',e.target.value)} className="input-dark" placeholder="Ex: Troca de tela, reparo de placa..."/>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="lbl">Data início</label>
            <input type="date" value={form.dataInicio} onChange={e=>set('dataInicio',e.target.value)} className="input-dark"/>
          </div>
          <div>
            <label className="lbl">Dias de garantia</label>
            <select value={form.diasGarantia} onChange={e=>set('diasGarantia',e.target.value)} className="input-dark">
              {['30','60','90','120','180','365'].map(d=><option key={d} value={d}>{d} dias</option>)}
            </select>
          </div>
        </div>

        {dataExpiracao && (
          <div style={{background:'rgba(0,255,65,0.05)',border:'1px solid rgba(0,255,65,0.2)',borderRadius:12,padding:12}}>
            <p className="text-xs text-gray-500 mb-1">Vencimento</p>
            <p className="text-sm font-bold text-neon">
              {format(new Date(dataExpiracao), "dd 'de' MMMM 'de' yyyy", {locale:ptBR})}
            </p>
          </div>
        )}
      </div>

      <div className="flex flex-col gap-2">
        <button onClick={save} disabled={saving} className="btn-neon w-full py-3 text-base">
          {saving ? 'Salvando...' : 'Registrar Garantia'}
        </button>
        <button onClick={()=>router.back()} className="btn-ghost w-full py-3">Cancelar</button>
      </div>
    </div>
  )
}

export default function NovaGarantiaPage() {
  return (
    <Suspense fallback={<div className="flex justify-center py-20"><div className="w-6 h-6 border-2 border-neon border-t-transparent rounded-full animate-spin"/></div>}>
      <NovaGarantiaInner/>
    </Suspense>
  )
}
