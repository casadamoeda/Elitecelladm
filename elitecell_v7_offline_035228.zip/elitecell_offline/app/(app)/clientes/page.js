'use client'
import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { clientes as db } from '@/lib/firestore'
import { Users, Plus, Search, User, Phone, MapPin, ChevronRight } from 'lucide-react'

export default function ClientesPage() {
  const router = useRouter()
  const [list, setList] = useState([])
  const [busca, setBusca] = useState('')
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    db.list().then(d => { setList(d); setLoading(false) })
  }, [])

  const filtered = list.filter(c =>
    c.nome?.toLowerCase().includes(busca.toLowerCase()) ||
    c.telefone?.includes(busca) ||
    c.cidade?.toLowerCase().includes(busca.toLowerCase())
  )

  return (
    <div className="fu">
      <div className="flex items-center justify-between mb-5">
        <div>
          <h1 className="text-xl font-black flex items-center gap-2">
            <Users className="w-5 h-5 text-neon" />Clientes
          </h1>
          <p className="text-xs text-gray-500">{list.length} cadastrados</p>
        </div>
        <button onClick={() => router.push('/clientes/novo')} className="btn-neon flex items-center gap-2 text-sm">
          <Plus className="w-4 h-4" />Novo
        </button>
      </div>

      <div className="relative mb-4">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
        <input value={busca} onChange={e => setBusca(e.target.value)}
          placeholder="Nome, telefone ou cidade..." className="input-dark pl-10" />
      </div>

      {loading
        ? <div className="flex justify-center py-12">
            <div className="w-6 h-6 border-2 border-neon border-t-transparent rounded-full animate-spin" />
          </div>
        : filtered.length === 0
          ? <div className="card text-center py-12">
              <Users className="w-10 h-10 text-gray-700 mx-auto mb-3" />
              <p className="text-gray-500 text-sm">Nenhum cliente</p>
              <button onClick={() => router.push('/clientes/novo')} className="btn-neon mt-4 text-sm">
                Cadastrar primeiro
              </button>
            </div>
          : <div className="flex flex-col gap-2">
              {filtered.map(c => (
                <button key={c.id}
                  onClick={() => router.push(`/clientes/detalhe?id=${c.id}`)}
                  className="card text-left flex items-center gap-3 hover:border-neon/20 transition-colors w-full">
                  <div className="w-10 h-10 rounded-xl bg-neon/10 border border-neon/20 flex items-center justify-center flex-shrink-0">
                    <User className="w-5 h-5 text-neon" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-semibold text-sm">{c.nome}</p>
                    <div className="flex items-center gap-3 mt-0.5">
                      {c.telefone && <span className="flex items-center gap-1 text-xs text-gray-500"><Phone className="w-3 h-3" />{c.telefone}</span>}
                      {c.cidade && <span className="flex items-center gap-1 text-xs text-gray-500"><MapPin className="w-3 h-3" />{c.cidade}</span>}
                    </div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-gray-600" />
                </button>
              ))}
            </div>
      }
    </div>
  )
}
