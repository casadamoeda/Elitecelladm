'use client'
import { useEffect } from 'react'
import { X } from 'lucide-react'

// ═══════════════════════════════════════════════════════
//  Modal — Bottom Sheet 92% altura, scroll interno
//
//  Estratégia (definitiva para Android/iOS):
//  • O CARD tem altura FIXA de 92dvh (adapta ao teclado)
//  • HEADER e FOOTER são flex-shrink:0 (nunca encolhem)
//  • CONTENT tem flex:1 + minHeight:0 + overflowY:auto
//    → min-height:0 é OBRIGATÓRIO para flex+scroll funcionar
//  • Usa dvh (dynamic viewport) → correto com teclado aberto
//  • Fallback para 92vh em browsers antigos
// ═══════════════════════════════════════════════════════

export default function Modal({ title, onClose, children, footer }) {
  // Trava o scroll da página enquanto o modal está aberto
  useEffect(() => {
    const prev = document.body.style.overflow
    document.body.style.overflow = 'hidden'
    return () => { document.body.style.overflow = prev }
  }, [])

  return (
    /* ── Overlay ── */
    <div
      onClick={onClose}
      style={{
        position: 'fixed',
        inset: 0,
        zIndex: 50,
        background: 'rgba(0,0,0,0.82)',
        backdropFilter: 'blur(3px)',
        WebkitBackdropFilter: 'blur(3px)',
        display: 'flex',
        alignItems: 'flex-end',       // ancora no rodapé da tela
        justifyContent: 'center',
      }}
    >
      {/* ── Card ── */}
      <div
        onClick={e => e.stopPropagation()}   // não fecha ao tocar no card
        style={{
          width: '100%',
          maxWidth: 600,

          // Altura: 92% do viewport dinâmico (dvh adapta ao teclado)
          // fallback para vh em browsers que não suportam dvh
          height: 'min(92dvh, 92vh)',

          background: '#111111',
          borderRadius: '20px 20px 0 0',
          border: '1px solid rgba(255,255,255,0.10)',
          borderBottom: 'none',

          // Flex coluna: header fixo + content scroll + footer fixo
          display: 'flex',
          flexDirection: 'column',
          overflow: 'hidden',          // clippa fora do card
        }}
      >

        {/* ─── HEADER (fixo, nunca rola) ─── */}
        <div style={{
          flexShrink: 0,
          padding: '10px 16px 14px',
          background: '#111111',
          borderBottom: '1px solid rgba(255,255,255,0.08)',
          borderRadius: '20px 20px 0 0',
        }}>
          {/* Alça visual */}
          <div style={{ display:'flex', justifyContent:'center', paddingBottom: 10 }}>
            <div style={{ width:40, height:4, borderRadius:2, background:'rgba(255,255,255,0.18)' }} />
          </div>
          {/* Título + botão fechar */}
          <div style={{ display:'flex', alignItems:'center', gap: 8 }}>
            <div style={{ width: 32 }} />
            <h2 style={{
              flex: 1, margin: 0,
              textAlign: 'center',
              color: '#ffffff',
              fontWeight: 900,
              fontSize: 13,
              textTransform: 'uppercase',
              letterSpacing: '0.08em',
            }}>
              {title}
            </h2>
            <button
              type="button"
              onClick={onClose}
              style={{
                width: 32, height: 32,
                borderRadius: '50%',
                border: 'none',
                background: 'rgba(255,255,255,0.10)',
                cursor: 'pointer',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                flexShrink: 0,
              }}
            >
              <X size={16} color="#9ca3af" />
            </button>
          </div>
        </div>

        {/* ─── CONTENT (rola verticalmente) ─── */}
        {/*
          min-height: 0  → CRÍTICO: sem isso o flex-child não consegue
                            encolher abaixo do tamanho do conteúdo,
                            quebrando o overflow/scroll.
          flex: 1        → ocupa todo o espaço entre header e footer
          overflow-y     → ativa o scroll nativo do browser (suave no iOS)
        */}
        <div style={{
          flex: 1,
          minHeight: 0,
          overflowY: 'auto',
          overflowX: 'hidden',
          WebkitOverflowScrolling: 'touch',
          padding: '20px 16px',
        }}>
          {children}
        </div>

        {/* ─── FOOTER (fixo, nunca rola) ─── */}
        {footer && (
          <div style={{
            flexShrink: 0,
            padding: '14px 16px 28px',   // 28px extra: barra home do iPhone
            background: '#111111',
            borderTop: '1px solid rgba(255,255,255,0.08)',
          }}>
            {footer}
          </div>
        )}

      </div>
    </div>
  )
}
