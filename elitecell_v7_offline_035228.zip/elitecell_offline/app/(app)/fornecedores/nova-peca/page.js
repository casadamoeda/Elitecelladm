'use client'
import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { fornecedores as fornDb, pecas as pecasDb } from '@/lib/firestore'
import toast from 'react-hot-toast'
import { ArrowLeft, Package } from 'lucide-react'

const R$ = v => (v || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })

export default function NovaPecaPage() {
  const router = useRouter()
  const [form, setForm] = useState({ nome: '', marca: '', modeloCompativel: '', fornecedorId: '', fornecedorNome: '', valorPago: '', valorCobrado: '', garantiaDias: '90' })
  const [forns, setForns] = useState([])
  const [saving, setSaving] = useState(false)

  useEffect(() => { fornDb.list().then(setForns) }, [])

  const set = (f, v) => setForm(p => ({ ...p, [f]: v }))
  const lucro = (parseFloat(form.valorCobrado) || 0) - (parseFloat(form.valorPago) || 0)

  const save = async () => {
    if (!form.nome.trim()) return toast.error('Nome obrigatório')
    setSaving(true)
    try {
      await pecasDb.add({
        ...form,
        valorPago: parseFloat(form.valorPago) || 0,
        valorCobrado: parseFloat(form.valorCobrado) || 0,
        garantiaDias: parseInt(form.garantiaDias) || 90,
      })
      toast.success('Peça registrada!')
      router.back()
    } catch { toast.error('Erro ao salvar') } finally { setSaving(false) }
  }

  return (
    <div className="fu">
      {/* Header */}
      <div className="flex items-center gap-3 mb-6">
        <button onClick={() => router.back()} className="p-2 hover:bg-surface-light rounded-lg transition-colors flex-shrink-0">
          <ArrowLeft className="w-5 h-5 text-gray-400" />
        </button>
        <div>
          <h1 className="text-xl font-black flex items-center gap-2">
            <Package className="w-5 h-5 text-neon" />Registrar Peça
          </h1>
          <p className="text-xs text-gray-500">Dados da peça comprada</p>
        </div>
      </div>

      {/* Formulário */}
      <div className="flex flex-col gap-4 mb-6">
        <div>
          <label className="lbl">Nome da peça *</label>
          <input type="text" value={form.nome} onChange={e => set('nome', e.target.value)} className="input-dark" placeholder="Ex: Tela, Bateria, Conector..." autoFocus />
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="lbl">Marca</label>
            <input type="text" value={form.marca} onChange={e => set('marca', e.target.value)} className="input-dark" placeholder="Samsung..." />
          </div>
          <div>
            <label className="lbl">Modelo compat.</label>
            <input type="text" value={form.modeloCompativel} onChange={e => set('modeloCompativel', e.target.value)} className="input-dark" placeholder="A54, S23..." />
          </div>
        </div>

        <div>
          <label className="lbl">Fornecedor</label>
          <select value={form.fornecedorId} onChange={e => { const f = forns.find(x => x.id === e.target.value); set('fornecedorId', e.target.value); set('fornecedorNome', f?.nome || '') }} className="input-dark">
            <option value="">Sem fornecedor</option>
            {forns.map(f => <option key={f.id} value={f.id}>{f.nome}</option>)}
          </select>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="lbl">Valor pago (R$)</label>
            <input type="number" value={form.valorPago} onChange={e => set('valorPago', e.target.value)} className="input-dark" step="0.01" placeholder="0,00" />
          </div>
          <div>
            <label className="lbl">Valor cobrado (R$)</label>
            <input type="number" value={form.valorCobrado} onChange={e => set('valorCobrado', e.target.value)} className="input-dark" step="0.01" placeholder="0,00" />
          </div>
        </div>

        <div className="bg-neon/5 border border-neon/20 rounded-xl px-4 py-3 text-center">
          <p className="text-xs text-gray-400 mb-1">Lucro na peça</p>
          <p className={`text-2xl font-black ${lucro >= 0 ? 'text-neon' : 'text-red-400'}`}>{R$(lucro)}</p>
        </div>

        <div>
          <label className="lbl">Garantia (dias)</label>
          <select value={form.garantiaDias} onChange={e => set('garantiaDias', e.target.value)} className="input-dark">
            <option value="30">30 dias</option>
            <option value="60">60 dias</option>
            <option value="90">90 dias</option>
            <option value="180">6 meses</option>
            <option value="365">1 ano</option>
          </select>
        </div>
      </div>

      {/* Ações */}
      <div className="flex flex-col gap-2">
        <button onClick={save} disabled={saving} className="btn-neon w-full py-3 text-base">
          {saving ? 'Salvando...' : 'Registrar Peça'}
        </button>
        <button onClick={() => router.back()} className="btn-ghost w-full py-3">
          Cancelar
        </button>
      </div>
    </div>
  )
}
