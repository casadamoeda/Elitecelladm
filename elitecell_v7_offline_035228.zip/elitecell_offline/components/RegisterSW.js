'use client'
import { useEffect } from 'react'

export default function RegisterSW() {
  useEffect(() => {
    if (typeof window === 'undefined') return
    if (!('serviceWorker' in navigator)) return

    const register = async () => {
      try {
        const reg = await navigator.serviceWorker.register('/sw.js', {
          scope: '/',
          updateViaCache: 'none',
        })

        // Verifica update silenciosamente a cada 60s
        setInterval(() => reg.update(), 60_000)

        reg.addEventListener('updatefound', () => {
          const worker = reg.installing
          if (!worker) return
          worker.addEventListener('statechange', () => {
            if (worker.state === 'installed' && navigator.serviceWorker.controller) {
              // Nova versão disponível — recarrega silenciosamente
              worker.postMessage({ type: 'SKIP_WAITING' })
              window.location.reload()
            }
          })
        })
      } catch (err) {
        console.warn('SW registration failed:', err)
      }
    }

    // Registra após carregamento completo da página
    if (document.readyState === 'complete') {
      register()
    } else {
      window.addEventListener('load', register, { once: true })
    }
  }, [])

  return null
}
