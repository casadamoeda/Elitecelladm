'use client'
import { useEffect, useState, Suspense } from 'react'
import { useSearchParams } from 'next/navigation'
import { ordens as ordensDb, pecas as pecasDb } from '@/lib/firestore'

const R$ = v => (v||0).toLocaleString('pt-BR',{style:'currency',currency:'BRL'})
const SL = {
  recebido:'Recebido', em_analise:'Em Análise', aguardando_aprovacao:'Aguardando Aprovação',
  aguardando_peca:'Aguardando Peça', em_reparo:'Em Reparo', testes_finais:'Testes Finais',
  pronto:'Pronto para Retirada', entregue:'Entregue', cancelado:'Cancelado', sem_reparo:'Sem Reparo Possível'
}

async function fetchPecas(ordemId) {
  try { return await pecasDb.byOrdem(ordemId) } catch { return [] }
}

function ImprimirInner() {
  const params  = useSearchParams()
  const id      = params.get('id')
  const [os, setOs]       = useState(null)
  const [pecas, setPecas] = useState([])
  const [loading, setLoad] = useState(true)
  const [origin, setOrigin] = useState('')

  useEffect(() => {
    setOrigin(window.location.origin)
    if (!id) { setLoad(false); return }
    Promise.all([
      ordensDb.get(id),
      fetchPecas(id),
    ]).then(([ordem, p]) => {
      if (ordem) setOs(ordem)
      setPecas(p)
      setLoad(false)
    })
  }, [id])

  useEffect(() => {
    if (!loading && os) setTimeout(() => window.print(), 700)
  }, [loading, os])

  if (loading) return (
    <div style={{display:'flex',alignItems:'center',justifyContent:'center',minHeight:'100vh',fontFamily:'Arial,sans-serif'}}>
      <p style={{color:'#888'}}>Preparando comprovante...</p>
    </div>
  )
  if (!os) return (
    <div style={{display:'flex',alignItems:'center',justifyContent:'center',minHeight:'100vh',fontFamily:'Arial,sans-serif'}}>
      <p style={{color:'#888'}}>OS não encontrada.</p>
    </div>
  )

  const valorTotal = os.valorTotal || os.valorServico || 0
  const trackUrl   = `${origin}/acompanhar/${os.numero}`
  const qrUrl      = `https://api.qrserver.com/v1/create-qr-code/?size=110x110&color=000000&bgcolor=ffffff&data=${encodeURIComponent(trackUrl)}`
  const dataEmissao = new Date().toLocaleDateString('pt-BR',{day:'2-digit',month:'long',year:'numeric'})

  return (
    <>
      <style>{`
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { background: #fff; font-family: Arial, Helvetica, sans-serif; color: #111; }
        @media screen { body { background: #f0f0f0; } .page { box-shadow: 0 4px 24px rgba(0,0,0,0.15); } }
        @media print { @page { margin: 12mm 14mm; size: A4; } body { background: #fff; } .no-print { display: none !important; } }
      `}</style>

      <div className="page" style={{background:'#fff',maxWidth:600,margin:'0 auto',padding:'32px 28px'}}>

        {/* ── CABEÇALHO ── */}
        <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',paddingBottom:20,borderBottom:'3px solid #00aa00',marginBottom:24}}>
          <div style={{display:'flex',alignItems:'center',gap:14}}>
            <img src="/logo.png" alt="EliteCell" style={{width:64,height:64,borderRadius:'50%',objectFit:'cover',flexShrink:0}}/>
            <div>
              <div style={{fontSize:22,fontWeight:900,letterSpacing:'-0.5px'}}>
                ELITE<span style={{color:'#00aa00'}}>CELL</span>
              </div>
              <div style={{fontSize:11,color:'#888',marginTop:2}}>Assistência Técnica</div>
            </div>
          </div>
          <div style={{textAlign:'right'}}>
            <div style={{fontSize:13,fontWeight:900,color:'#111'}}>COMPROVANTE DE SERVIÇO</div>
            <div style={{fontSize:20,fontWeight:900,color:'#00aa00',marginTop:2}}>OS #{os.numero}</div>
            <div style={{fontSize:11,color:'#888',marginTop:4}}>Emitido em {dataEmissao}</div>
          </div>
        </div>

        {/* ── DADOS DO CLIENTE ── */}
        <Section title="DADOS DO CLIENTE">
          <Row label="Nome" value={os.clienteNome}/>
          {os.clienteTelefone && <Row label="Telefone" value={os.clienteTelefone}/>}
        </Section>

        {/* ── DADOS DO APARELHO ── */}
        <Section title="DADOS DO APARELHO">
          <Row label="Marca / Modelo" value={`${os.marca||''} ${os.modelo||''}`.trim()}/>
          {os.cor   && <Row label="Cor"         value={os.cor}/>}
          {os.imei  && <Row label="IMEI/Serial" value={os.imei}/>}
        </Section>

        {/* ── DEFEITO RELATADO ── */}
        {os.defeito && (
          <Section title="DEFEITO RELATADO">
            <p style={{fontSize:13,color:'#333',lineHeight:1.6}}>{os.defeito}</p>
          </Section>
        )}

        {/* ── SERVIÇO REALIZADO ── */}
        {(os.finalizacao?.obsFinais || pecas.length > 0) && (
          <Section title="SERVIÇO REALIZADO">
            {pecas.length > 0 && (
              <div style={{marginBottom: os.finalizacao?.obsFinais ? 10 : 0}}>
                <div style={{fontSize:11,color:'#888',marginBottom:6,fontWeight:700}}>Peças substituídas:</div>
                {pecas.map((p,i) => (
                  <div key={i} style={{display:'flex',alignItems:'center',gap:8,padding:'5px 0',borderBottom:'1px solid #f5f5f5',fontSize:13}}>
                    <span style={{color:'#00aa00',fontWeight:700}}>•</span>
                    <span>{p.nome}{p.quantidade > 1 ? ` (${p.quantidade}x)` : ''}</span>
                  </div>
                ))}
              </div>
            )}
            {os.finalizacao?.obsFinais && (
              <p style={{fontSize:13,color:'#333',lineHeight:1.6,marginTop:4}}>{os.finalizacao.obsFinais}</p>
            )}
          </Section>
        )}

        {/* ── GARANTIA ── */}
        {os.finalizacao && (
          <Section title="GARANTIA">
            <div style={{background:'#f0fff0',border:'1.5px solid #00aa00',borderRadius:10,padding:'14px 16px'}}>
              <div style={{display:'flex',alignItems:'center',gap:8,marginBottom:8}}>
                <span style={{fontSize:18}}>🛡️</span>
                <span style={{fontSize:14,fontWeight:900,color:'#00aa00'}}>
                  {os.finalizacao.garantiaDias} dias de garantia
                </span>
              </div>
              {/* peças já exibidas na seção "Serviço Realizado" acima, vindas da lista real */}
              {os.finalizacao.dataEntrega && (() => {
                const dataEnt = new Date(os.finalizacao.dataEntrega)
                const dataVenc = new Date(dataEnt)
                dataVenc.setDate(dataVenc.getDate() + (os.finalizacao.garantiaDias || 90))
                return (
                  <div style={{display:'flex',gap:24,marginTop:8,fontSize:12,color:'#555'}}>
                    <div>Entregue: <strong>{dataEnt.toLocaleDateString('pt-BR')}</strong></div>
                    <div>Válida até: <strong style={{color:'#00aa00'}}>{dataVenc.toLocaleDateString('pt-BR')}</strong></div>
                  </div>
                )
              })()}
              <p style={{fontSize:11,color:'#888',marginTop:10,lineHeight:1.5}}>
                A garantia cobre o serviço realizado. Não inclui danos físicos, oxidação ou mau uso após a entrega.
              </p>
            </div>
          </Section>
        )}

        {/* ── VALOR ── */}
        <div style={{background:'#f9f9f9',border:'1px solid #e8e8e8',borderRadius:10,padding:'16px 18px',marginBottom:24}}>
          <div style={{display:'flex',justifyContent:'space-between',alignItems:'center'}}>
            <span style={{fontSize:13,color:'#555',fontWeight:700}}>TOTAL COBRADO</span>
            <span style={{fontSize:22,fontWeight:900,color:'#00aa00'}}>{R$(valorTotal)}</span>
          </div>
        </div>

        {/* ── ACOMPANHAMENTO ── */}
        <div style={{display:'flex',gap:16,alignItems:'center',background:'#fafafa',border:'1px solid #eee',borderRadius:10,padding:'14px 16px',marginBottom:28}}>
          <img src={qrUrl} alt="QR" width={80} height={80} style={{borderRadius:6,flexShrink:0}}/>
          <div>
            <p style={{fontSize:12,fontWeight:700,color:'#111',marginBottom:4}}>Acompanhe sua OS pelo celular</p>
            <p style={{fontSize:11,color:'#888',wordBreak:'break-all',lineHeight:1.5}}>{trackUrl}</p>
            <p style={{fontSize:10,color:'#aaa',marginTop:4}}>Aponte a câmera para o QR Code</p>
          </div>
        </div>

        {/* ── ASSINATURAS ── */}
        <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:32,marginTop:8}}>
          {['Técnico Responsável','Assinatura do Cliente'].map(l => (
            <div key={l} style={{textAlign:'center'}}>
              <div style={{borderTop:'1px solid #ccc',paddingTop:8}}>
                <p style={{fontSize:11,color:'#999'}}>{l}</p>
              </div>
            </div>
          ))}
        </div>

        <p style={{textAlign:'center',fontSize:10,color:'#ccc',marginTop:24}}>
          EliteCell Assistência Técnica • {dataEmissao}
        </p>
      </div>
    </>
  )
}

function Section({ title, children }) {
  return (
    <div style={{marginBottom:20}}>
      <div style={{fontSize:10,fontWeight:700,color:'#888',letterSpacing:'0.12em',textTransform:'uppercase',marginBottom:8,borderLeft:'3px solid #00aa00',paddingLeft:8}}>
        {title}
      </div>
      {children}
    </div>
  )
}

function Row({ label, value }) {
  if (!value) return null
  return (
    <div style={{display:'flex',justifyContent:'space-between',padding:'5px 0',borderBottom:'1px solid #f5f5f5',fontSize:13}}>
      <span style={{color:'#888'}}>{label}</span>
      <span style={{fontWeight:600,textAlign:'right',maxWidth:'60%'}}>{value}</span>
    </div>
  )
}

export default function ImprimirPage() {
  return (
    <Suspense fallback={
      <div style={{display:'flex',alignItems:'center',justifyContent:'center',minHeight:'100vh'}}>
        <p style={{color:'#888',fontFamily:'Arial'}}>Preparando comprovante...</p>
      </div>
    }>
      <ImprimirInner/>
    </Suspense>
  )
}
