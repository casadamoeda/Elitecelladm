'use client'
import { useEffect, useState } from 'react'
import { entregas as db } from '@/lib/firestore'
import Modal from '@/components/Modal'
import toast from 'react-hot-toast'
import { format } from 'date-fns'
import { ptBR } from 'date-fns/locale'
import { Truck,Plus,MapPin,Clock,CheckCircle,Package,Trash2 } from 'lucide-react'
const EMPTY={clienteNome:'',osNumero:'',endereco:'',bairro:'',cidade:'',tipo:'entrega',status:'agendado',dataAgendada:format(new Date(),'yyyy-MM-dd'),horario:'',observacoes:''}
const ST={agendado:{l:'Agendado',c:'text-blue-400 bg-blue-500/10 border-blue-500/20'},em_rota:{l:'Em rota 🚗',c:'text-yellow-400 bg-yellow-500/10 border-yellow-500/20'},concluido:{l:'Concluído ✓',c:'text-neon bg-neon/10 border-neon/20'},cancelado:{l:'Cancelado',c:'text-red-400 bg-red-500/10 border-red-500/20'}}
export default function EntregasPage(){
  const [list,setList]=useState([]);const [filtro,setFiltro]=useState('todos');const [modal,setModal]=useState(false);const [form,setForm]=useState(EMPTY);const [saving,setSaving]=useState(false);const [loading,setLoad]=useState(true)
  const load=async()=>{setLoad(true);setList(await db.list());setLoad(false)}
  useEffect(()=>{load()},[])
  const set=(f,v)=>setForm(p=>({...p,[f]:v}))
  const save=async()=>{if(!form.clienteNome||!form.endereco)return toast.error('Cliente e endereço obrigatórios');setSaving(true);try{await db.add(form);toast.success('Agendado!');setModal(false);setForm(EMPTY);load()}catch{toast.error('Erro')}finally{setSaving(false)}}
  const updStatus=async(id,status)=>{await db.update(id,{status});toast.success('Atualizado!');load()}
  const del=async(e)=>{if(!confirm('Remover?'))return;await db.delete(e.id);toast.success('Removido');load()}
  const filtered=list.filter(e=>filtro==='todos'||e.status===filtro)
  return(<div className="fu">
    <div className="flex items-center justify-between mb-5"><div><h1 className="text-xl font-black flex items-center gap-2"><Truck className="w-5 h-5 text-neon"/>Coletas & Entregas</h1><p className="text-xs text-gray-500">{list.length} agendamentos</p></div><button onClick={()=>{setForm(EMPTY);setModal(true)}} className="btn-neon flex items-center gap-2 text-sm"><Plus className="w-4 h-4"/>Agendar</button></div>
    <div className="flex gap-1 mb-4 overflow-x-auto pb-1">{[['todos','Todos'],['agendado','Agendados'],['em_rota','Em rota'],['concluido','Concluídos']].map(([f,l])=><button key={f} onClick={()=>setFiltro(f)} className={`flex-shrink-0 px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${filtro===f?'bg-neon text-black':'bg-surface-light text-gray-400 hover:text-white'}`}>{l}</button>)}</div>
    {loading?<div className="flex justify-center py-12"><div className="w-6 h-6 border-2 border-neon border-t-transparent rounded-full animate-spin"/></div>
    :filtered.length===0?<div className="card text-center py-12"><Truck className="w-10 h-10 text-gray-700 mx-auto mb-3"/><p className="text-gray-500 text-sm">Nenhum agendamento</p></div>
    :<div className="flex flex-col gap-2">{filtered.map(e=>{const st=ST[e.status]||ST.agendado;return(
      <div key={e.id} className="card hover:border-neon/20 transition-colors">
        <div className="flex items-start gap-3">
          <div className={`w-10 h-10 rounded-xl border flex items-center justify-center flex-shrink-0 ${st.c}`}>{e.tipo==='entrega'?<Package className="w-5 h-5"/>:<Truck className="w-5 h-5"/>}</div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 flex-wrap"><p className="font-semibold text-sm">{e.clienteNome}</p><span className={`badge border text-xs ${st.c}`}>{st.l}</span><span className={`badge border text-xs ${e.tipo==='entrega'?'text-cyan-400 bg-cyan-500/10 border-cyan-500/20':'text-purple-400 bg-purple-500/10 border-purple-500/20'}`}>{e.tipo==='entrega'?'📦 Entrega':'🚗 Coleta'}</span></div>
            <p className="text-xs text-gray-400 flex items-center gap-1 mt-1"><MapPin className="w-3 h-3 flex-shrink-0"/>{e.endereco}{e.bairro?`, ${e.bairro}`:''}</p>
            <p className="text-xs text-gray-500 flex items-center gap-1"><Clock className="w-3 h-3"/>{format(new Date(e.dataAgendada),'dd/MM/yy',{locale:ptBR})}{e.horario?` às ${e.horario}`:''}</p>
          </div>
          <button onClick={()=>del(e)} className="p-1.5 hover:bg-red-500/10 rounded-lg flex-shrink-0"><Trash2 className="w-3.5 h-3.5 text-red-500/50"/></button>
        </div>
        {e.status!=='concluido'&&e.status!=='cancelado'&&<div className="flex gap-2 mt-3 pt-3 border-t border-surface-border">{e.status==='agendado'&&<button onClick={()=>updStatus(e.id,'em_rota')} className="btn-ghost flex-1 text-xs py-1.5">🚗 Iniciar rota</button>}<button onClick={()=>updStatus(e.id,'concluido')} className="btn-neon flex-1 text-xs py-1.5"><CheckCircle className="w-3 h-3 inline mr-1"/>Concluir</button></div>}
      </div>
    )})}</div>}
    {modal&&<Modal title="Agendar Coleta/Entrega" onClose={()=>setModal(false)} footer={<div className="flex flex-col gap-2"><button onClick={save} disabled={saving} className="btn-neon w-full py-3">{saving?'Agendando...':'Agendar'}</button><button onClick={()=>setModal(false)} className="btn-ghost w-full">Cancelar</button></div>}>
      <div className="flex flex-col gap-3">
        <div><label className="lbl">Tipo</label><div className="flex flex-col gap-2">{[['entrega','📦 Entrega'],['coleta','🚗 Coleta']].map(([v,l])=><button key={v} onClick={()=>set('tipo',v)} className={`flex-1 py-2.5 rounded-xl text-sm font-medium border transition-all ${form.tipo===v?'bg-neon/10 border-neon/40 text-neon':'border-surface-border text-gray-500'}`}>{l}</button>)}</div></div>
        {[['clienteNome','Cliente *'],['osNumero','Nº OS'],['endereco','Endereço *'],['bairro','Bairro'],['cidade','Cidade']].map(([f,l])=><div key={f}><label className="lbl">{l}</label><input type="text" value={form[f]} onChange={e=>set(f,e.target.value)} className="input-dark"/></div>)}
        <div className="grid grid-cols-2 gap-3"><div><label className="lbl">Data</label><input type="date" value={form.dataAgendada} onChange={e=>set('dataAgendada',e.target.value)} className="input-dark"/></div><div><label className="lbl">Horário</label><input type="time" value={form.horario} onChange={e=>set('horario',e.target.value)} className="input-dark"/></div></div>
        <div><label className="lbl">Observações</label><textarea value={form.observacoes} onChange={e=>set('observacoes',e.target.value)} rows={2} className="input-dark resize-none"/></div>
      </div>
    </Modal>}
  </div>)
}
