'use client'
import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { useConnection } from '@/lib/contexts/ConnectionContext'
import { localDB } from '@/lib/db'
import { ArrowLeft, RefreshCw, CheckCircle2, WifiOff, Clock, Database, AlertTriangle } from 'lucide-react'

const TABLES = [
  { key: 'clientes',     label: 'Clientes' },
  { key: 'ordens',       label: 'Ordens de Serviço' },
  { key: 'financeiro',   label: 'Financeiro' },
  { key: 'garantias',    label: 'Garantias' },
  { key: 'entregas',     label: 'Entregas' },
  { key: 'pecas',        label: 'Peças' },
  { key: 'fornecedores', label: 'Fornecedores' },
]

function fmt(date) {
  if (!date) return 'Nunca'
  const d = new Date(date)
  return d.toLocaleDateString('pt-BR') + ' às ' + d.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })
}

export default function SincronizacaoPage() {
  const router = useRouter()
  const { online, status, pending, lastSync, syncNow, refreshPending } = useConnection()
  const [details, setDetails] = useState({})
  const [loading, setLoading] = useState(true)

  const loadDetails = async () => {
    setLoading(true)
    const result = {}
    for (const t of TABLES) {
      try {
        const add = await localDB[t.key].where('_syncStatus').equals('pending_add').count()
        const upd = await localDB[t.key].where('_syncStatus').equals('pending_update').count()
        const del = await localDB[t.key].where('_syncStatus').equals('pending_delete').count()
        const total = await localDB[t.key].filter(r => r._syncStatus !== 'pending_delete').count()
        result[t.key] = { add, upd, del, total }
      } catch { result[t.key] = { add: 0, upd: 0, del: 0, total: 0 } }
    }
    setDetails(result)
    await refreshPending()
    setLoading(false)
  }

  useEffect(() => { loadDetails() }, [])

  const handleSync = async () => {
    await syncNow()
    await loadDetails()
  }

  const statusConfig = {
    synced:  { icon: <CheckCircle2 className="w-5 h-5 text-neon" />,    text: 'Sincronizado',      color: 'text-neon' },
    syncing: { icon: <RefreshCw    className="w-5 h-5 text-yellow-400 animate-spin" />, text: 'Sincronizando...', color: 'text-yellow-400' },
    offline: { icon: <WifiOff      className="w-5 h-5 text-red-400" />,  text: 'Offline',           color: 'text-red-400' },
    error:   { icon: <AlertTriangle className="w-5 h-5 text-orange-400" />, text: 'Erro de sync',   color: 'text-orange-400' },
  }
  const sc = statusConfig[status] || statusConfig.synced

  return (
    <div className="fu">
      {/* Header */}
      <div className="flex items-center gap-3 mb-6">
        <button onClick={() => router.back()} className="p-2 hover:bg-surface-light rounded-lg transition-colors">
          <ArrowLeft className="w-5 h-5 text-gray-400" />
        </button>
        <div>
          <h1 className="text-xl font-black flex items-center gap-2">
            <Database className="w-5 h-5 text-neon" />Sincronização
          </h1>
          <p className="text-xs text-gray-500">Modo offline-first ativo</p>
        </div>
      </div>

      {/* Status Card */}
      <div className="card mb-4">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            {sc.icon}
            <span className={`font-bold text-sm ${sc.color}`}>{sc.text}</span>
          </div>
          <div className={`text-xs px-2 py-1 rounded-full border ${online ? 'text-neon bg-neon/10 border-neon/20' : 'text-red-400 bg-red-500/10 border-red-500/20'}`}>
            {online ? '● Online' : '● Offline'}
          </div>
        </div>

        <div className="flex items-center gap-2 text-xs text-gray-500 mb-4">
          <Clock className="w-3 h-3" />
          <span>Última sincronização: {fmt(lastSync)}</span>
        </div>

        {pending > 0 && (
          <div className="bg-yellow-500/10 border border-yellow-500/20 rounded-xl p-3 mb-4">
            <p className="text-yellow-400 text-sm font-bold">
              ⚠️ {pending} registro{pending !== 1 ? 's' : ''} pendente{pending !== 1 ? 's' : ''}
            </p>
            <p className="text-yellow-400/70 text-xs mt-1">
              {online ? 'Clique em "Sincronizar agora" para enviar.' : 'Será sincronizado quando a internet voltar.'}
            </p>
          </div>
        )}

        {pending === 0 && !loading && (
          <div className="bg-neon/5 border border-neon/20 rounded-xl p-3 mb-4">
            <p className="text-neon text-sm font-bold">✓ Tudo sincronizado</p>
            <p className="text-neon/60 text-xs mt-1">Nenhum dado pendente.</p>
          </div>
        )}

        <button
          onClick={handleSync}
          disabled={!online || status === 'syncing'}
          className="btn-neon w-full flex items-center justify-center gap-2 text-sm disabled:opacity-50 disabled:cursor-not-allowed"
        >
          <RefreshCw className={`w-4 h-4 ${status === 'syncing' ? 'animate-spin' : ''}`} />
          {status === 'syncing' ? 'Sincronizando...' : 'Sincronizar agora'}
        </button>
      </div>

      {/* Detalhes por módulo */}
      <h2 className="text-sm font-bold text-gray-400 mb-3 uppercase tracking-wider">Registros por módulo</h2>

      {loading ? (
        <div className="flex justify-center py-8">
          <div className="w-6 h-6 border-2 border-neon border-t-transparent rounded-full animate-spin" />
        </div>
      ) : (
        <div className="flex flex-col gap-2">
          {TABLES.map(t => {
            const d = details[t.key] || {}
            const hasPending = (d.add || 0) + (d.upd || 0) + (d.del || 0) > 0
            return (
              <div key={t.key} className={`card flex items-center justify-between ${hasPending ? 'border-yellow-500/30' : ''}`}>
                <div>
                  <p className="text-sm font-semibold">{t.label}</p>
                  <p className="text-xs text-gray-500">{d.total || 0} registro{d.total !== 1 ? 's' : ''} locais</p>
                </div>
                <div className="flex gap-2 text-right">
                  {d.add > 0 && <span className="text-xs bg-neon/10 text-neon border border-neon/20 px-2 py-0.5 rounded-full">+{d.add} novo</span>}
                  {d.upd > 0 && <span className="text-xs bg-blue-500/10 text-blue-400 border border-blue-500/20 px-2 py-0.5 rounded-full">~{d.upd} edit</span>}
                  {d.del > 0 && <span className="text-xs bg-red-500/10 text-red-400 border border-red-500/20 px-2 py-0.5 rounded-full">-{d.del} del</span>}
                  {!hasPending && <CheckCircle2 className="w-4 h-4 text-neon/40" />}
                </div>
              </div>
            )
          })}
        </div>
      )}

      <p className="text-center text-xs text-gray-600 mt-6">
        Todos os dados são salvos localmente.<br />
        Nunca serão perdidos em caso de queda de internet.
      </p>
    </div>
  )
}
