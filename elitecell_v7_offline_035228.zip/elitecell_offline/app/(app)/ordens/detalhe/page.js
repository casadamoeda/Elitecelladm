'use client'
import { useEffect, useState, Suspense } from 'react'
import { useRouter, useSearchParams } from 'next/navigation'
import { ordens as db, fornecedores as fornDb, pecas as pecasDb } from '@/lib/firestore'
import toast from 'react-hot-toast'
import {
  ArrowLeft, Pencil, Trash2, Clock, CheckCircle,
  ShieldCheck, QrCode, ExternalLink, Copy, Package,
  Smartphone, AlertCircle, Printer, Shield
} from 'lucide-react'

const R$ = v => (v||0).toLocaleString('pt-BR',{style:'currency',currency:'BRL'})

const STATUS = [
  {v:'recebido',            l:'Recebido',       bg:'rgba(59,130,246,0.1)',  bd:'rgba(59,130,246,0.3)', cor:'#3b82f6'},
  {v:'em_analise',          l:'Em análise',      bg:'rgba(234,179,8,0.1)',   bd:'rgba(234,179,8,0.3)',  cor:'#eab308'},
  {v:'aguardando_aprovacao',l:'Ag. aprovação',   bg:'rgba(249,115,22,0.1)', bd:'rgba(249,115,22,0.3)', cor:'#f97316'},
  {v:'aguardando_peca',     l:'Ag. peça',        bg:'rgba(168,85,247,0.1)', bd:'rgba(168,85,247,0.3)', cor:'#a855f7'},
  {v:'em_reparo',           l:'Em reparo',       bg:'rgba(6,182,212,0.1)',   bd:'rgba(6,182,212,0.3)',  cor:'#06b6d4'},
  {v:'testes_finais',       l:'Testes finais',   bg:'rgba(99,102,241,0.1)', bd:'rgba(99,102,241,0.3)', cor:'#6366f1'},
  {v:'pronto',              l:'Pronto ✓',        bg:'rgba(0,255,65,0.1)',   bd:'rgba(0,255,65,0.3)',   cor:'#00FF41'},
  {v:'entregue',            l:'Entregue ✓✓',     bg:'rgba(107,114,128,0.1)',bd:'rgba(107,114,128,0.3)',cor:'#6b7280'},
  {v:'cancelado',           l:'Cancelado',       bg:'rgba(239,68,68,0.1)',  bd:'rgba(239,68,68,0.3)',  cor:'#ef4444'},
  {v:'sem_reparo',          l:'Sem reparo',      bg:'rgba(220,38,38,0.1)',  bd:'rgba(220,38,38,0.3)',  cor:'#dc2626'},
]

const TESTES_LABEL = {
  wifi:'Wi-Fi', camera_f:'Câm. Frontal', camera_t:'Câm. Traseira',
  bluetooth:'Bluetooth', microfone:'Microfone', alto_fal:'Alto-falante',
  carregando:'Carregamento', touch:'Touch', biometria:'Biometria', botoes:'Botões'
}

const EMPTY_FIN  = {garantiaDias:'90',obsFinais:''}
const EMPTY_PECA = {nome:'',fornecedorId:'',fornecedorNome:'',valor:'',quantidade:'1'}

// Busca peças — offline-first via lib/firestore (que usa IndexedDB local)
async function fetchPecasOrdem(ordemId) {
  try {
    const { pecas } = await import('@/lib/firestore')
    return await pecas.byOrdem(ordemId)
  } catch { return [] }
}

function TrackingCard({ numero }) {
  const [copied, setCopied] = useState(false)
  const [origin, setOrigin] = useState('')
  useEffect(() => { setOrigin(window.location.origin) }, [])
  const url = `${origin}/acompanhar/${numero}`
  const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=180x180&color=00FF41&bgcolor=111111&data=${encodeURIComponent(url)}`

  const copy = () => {
    navigator.clipboard.writeText(url)
    setCopied(true); setTimeout(()=>setCopied(false), 2500)
    toast.success('Link copiado!')
  }

  return (
    <div style={{background:'rgba(0,255,65,0.04)',border:'1px solid rgba(0,255,65,0.2)',borderRadius:14,padding:16,marginBottom:4}}>
      <p style={{fontSize:11,color:'#00FF41',fontWeight:700,marginBottom:12,display:'flex',alignItems:'center',gap:6,letterSpacing:'0.05em'}}>
        <QrCode size={13}/> LINK DE ACOMPANHAMENTO
      </p>
      <div style={{display:'flex',gap:12,alignItems:'flex-start'}}>
        <div style={{flexShrink:0,background:'#111',borderRadius:10,padding:6,border:'1px solid rgba(0,255,65,0.15)'}}>
          {origin && <img src={qrUrl} alt="QR Code" width={88} height={88} style={{display:'block',borderRadius:6}}/>}
        </div>
        <div style={{flex:1,minWidth:0}}>
          <p style={{fontSize:10,color:'#444',marginBottom:10,wordBreak:'break-all',lineHeight:1.5}}>{url}</p>
          <div style={{display:'flex',flexDirection:'column',gap:6}}>
            <button onClick={copy} style={{
              display:'flex',alignItems:'center',justifyContent:'center',gap:6,
              padding:'9px 12px',borderRadius:8,border:'1px solid rgba(0,255,65,0.35)',
              background:copied?'rgba(0,255,65,0.15)':'transparent',
              color:'#00FF41',fontSize:12,fontWeight:700,cursor:'pointer'
            }}>
              <Copy size={12}/>{copied?'✓ Copiado!':'Copiar link'}
            </button>
            <a href={url} target="_blank" rel="noreferrer" style={{
              display:'flex',alignItems:'center',justifyContent:'center',gap:6,
              padding:'9px 12px',borderRadius:8,border:'1px solid rgba(255,255,255,0.08)',
              color:'#666',fontSize:12,textDecoration:'none'
            }}>
              <ExternalLink size={12}/>Abrir página
            </a>
          </div>
        </div>
      </div>
    </div>
  )
}

function DetalheOSInner() {
  const router = useRouter()
  const params = useSearchParams()
  const id = params.get('id')

  const [os, setOs]           = useState(null)
  const [forns, setForns]     = useState([])
  const [pecasOS, setPecasOS] = useState([])
  const [tab, setTab]         = useState('info')
  const [finForm, setFinForm] = useState(EMPTY_FIN)
  const [pecaForm, setPecaForm] = useState(EMPTY_PECA)
  const [saving, setSaving]   = useState(false)
  const [loading, setLoading] = useState(true)
  const [erro, setErro]       = useState(false)
  const [confirmando, setConfirmando] = useState(false)

  const carregarDados = async () => {
    try {
      const [o, f, p] = await Promise.all([
        db.get(id).catch(()=>null),
        fornDb.list().catch(()=>[]),
        fetchPecasOrdem(id)
      ])
      setOs(o); setForns(f); setPecasOS(p)
    } catch {
      setErro(true)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    if (!id) { router.replace('/ordens'); return }
    carregarDados()
  }, [id])

  const setFin  = (f,v) => setFinForm(p=>({...p,[f]:v}))
  const setPeca = (f,v) => setPecaForm(p=>({...p,[f]:v}))

  const changeStatus = async (status) => {
    if (status==='entregue') { setConfirmando(true); setTab('status'); return }
    try {
      await db.update(id,{status})
      toast.success('Status atualizado!')
      setOs(p=>({...p,status}))
    } catch { toast.error('Erro ao atualizar') }
  }

  const salvarFinalizacao = async () => {
    setSaving(true)
    try {
      const finalizacao = {
        garantiaDias: parseInt(finForm.garantiaDias)||90,
        obsFinais: finForm.obsFinais,
        dataEntrega: new Date().toISOString(),
        // snapshot das peças já cadastradas nesta OS, pra exibir rápido sem nova consulta
        pecasResumo: pecasOS.map(p => p.nome),
      }
      await db.update(id,{status:'entregue',finalizacao})
      toast.success('OS finalizada e entregue!')
      setConfirmando(false)
      setOs(p=>({...p,status:'entregue',finalizacao}))
    } catch { toast.error('Erro ao finalizar') } finally { setSaving(false) }
  }

  const adicionarPeca = async () => {
    if (!pecaForm.nome) return toast.error('Informe o nome da peça')
    setSaving(true)
    try {
      const forn = forns.find(f=>f.id===pecaForm.fornecedorId)
      await pecasDb.add({
        ordemId:id, ordemNumero:os.numero,
        clienteId:os.clienteId, clienteNome:os.clienteNome,
        nome:pecaForm.nome,
        fornecedorId:pecaForm.fornecedorId,
        fornecedorNome:forn?.nome||'',
        valor:parseFloat(pecaForm.valor)||0,
        quantidade:parseInt(pecaForm.quantidade)||1,
        dataCompra:new Date().toISOString(),
      })
      toast.success('Peça registrada!')
      setPecaForm(EMPTY_PECA)
      setPecasOS(await fetchPecasOrdem(id))
    } catch { toast.error('Erro') } finally { setSaving(false) }
  }

  const remover = async () => {
    if (!confirm(`Remover OS #${os.numero}?`)) return
    try {
      await db.delete(id)
      toast.success('OS removida')
      router.push('/ordens')
    } catch { toast.error('Erro ao remover') }
  }

  if (loading) return (
    <div className="flex flex-col items-center justify-center py-20 gap-3">
      <div className="w-7 h-7 border-2 border-neon border-t-transparent rounded-full animate-spin"/>
      <p className="text-xs text-gray-500">Carregando...</p>
    </div>
  )

  if (erro || !os) return (
    <div className="flex flex-col items-center justify-center py-20 gap-4">
      <AlertCircle className="w-10 h-10 text-red-500"/>
      <p className="text-gray-400 text-sm">Erro ao carregar OS</p>
      <button onClick={()=>router.back()} className="btn-ghost text-sm">Voltar</button>
    </div>
  )

  const sel = STATUS.find(s=>s.v===os.status)
  const testesOK      = os.testes ? Object.values(os.testes).filter(v=>v==='ok').length      : 0
  const testesDefeito = os.testes ? Object.values(os.testes).filter(v=>v==='defeito').length  : 0

  return (
    <div className="fu">
      {/* Header */}
      <div className="flex items-center gap-3 mb-5">
        <button onClick={()=>router.back()} className="p-2 hover:bg-surface-light rounded-lg transition-colors flex-shrink-0">
          <ArrowLeft className="w-5 h-5 text-gray-400"/>
        </button>
        <div className="flex-1 min-w-0">
          <h1 className="text-xl font-black">OS #{os.numero}</h1>
          <p className="text-xs text-gray-500 truncate">{os.clienteNome} — {os.marca} {os.modelo}</p>
        </div>
        {sel && (
          <span className="text-xs font-bold px-2.5 py-1 rounded-full border flex-shrink-0"
            style={{color:sel.cor, background:sel.bg, borderColor:sel.bd}}>
            {sel.l}
          </span>
        )}
      </div>

      {/* Abas */}
      <div style={{display:'flex',gap:3,background:'rgba(255,255,255,0.04)',borderRadius:12,padding:4,marginBottom:20}}>
        {[['info','Info'],['status','Status'],['testes','Testes'],['pecas','Peças']].map(([v,l])=>(
          <button key={v} onClick={()=>setTab(v)} style={{
            flex:1,padding:'9px 4px',borderRadius:9,fontSize:12,fontWeight:700,border:'none',cursor:'pointer',
            background:tab===v?'#00FF41':'transparent',
            color:tab===v?'#000':'#555',
            transition:'all 0.15s'
          }}>{l}</button>
        ))}
      </div>

      {/* ─── INFO ─── */}
      {tab==='info' && (
        <div className="flex flex-col gap-4">
          <TrackingCard numero={os.numero}/>

          <div className="card">
            <p className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-3">Aparelho</p>
            {[
              ['Cliente',os.clienteNome],
              ['Aparelho',`${os.marca||''} ${os.modelo||''}`],
              ['IMEI / Serial',os.imei],
              ['Cor',os.cor],
              ['Senha / Padrão',os.senha],
              ['Data prevista',os.dataPrevista],
            ].filter(([,v])=>v).map(([k,v])=>(
              <div key={k} className="flex justify-between text-sm border-b border-surface-border py-2 last:border-0 last:pb-0">
                <span className="text-gray-500">{k}</span>
                <span className="font-medium text-right max-w-[55%] break-words">{v}</span>
              </div>
            ))}
          </div>

          <div className="card">
            <p className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-3">Financeiro</p>
            <div className="flex justify-between text-sm mb-2"><span className="text-gray-500">Serviço</span><span>{R$(os.valorServico)}</span></div>
            <div className="flex justify-between text-sm pb-2 border-b border-surface-border"><span className="text-gray-500">Peça</span><span>{R$(os.valorPeca)}</span></div>
            <div className="flex justify-between text-sm mt-2 mb-1"><span className="font-bold">Total</span><span className="font-bold text-neon text-base">{R$((os.valorServico||0)+(os.valorPeca||0))}</span></div>
            <div className="flex justify-between text-sm"><span className="text-gray-500">Lucro est.</span><span className="font-bold text-neon">{R$(os.lucro||0)}</span></div>
          </div>

          {os.defeito && (
            <div className="card">
              <p className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-2">Defeito relatado</p>
              <p className="text-sm text-gray-300">{os.defeito}</p>
            </div>
          )}

          {os.finalizacao && (
            <div style={{background:'rgba(0,255,65,0.05)',border:'1px solid rgba(0,255,65,0.2)',borderRadius:14,padding:14}}>
              <p className="text-xs font-bold text-neon mb-3 flex items-center gap-2">
                <ShieldCheck className="w-3.5 h-3.5"/>FINALIZAÇÃO
              </p>
              {pecasOS.length > 0 && (
                <div className="flex justify-between text-sm py-1">
                  <span className="text-gray-500">Peças</span>
                  <span className="font-medium text-right">{pecasOS.map(p=>p.nome).join(', ')}</span>
                </div>
              )}
              {[
                ['Garantia',`${os.finalizacao.garantiaDias} dias`],
                ['Entregue em',os.finalizacao.dataEntrega?new Date(os.finalizacao.dataEntrega).toLocaleDateString('pt-BR'):''],
              ].filter(([,v])=>v).map(([k,v])=>(
                <div key={k} className="flex justify-between text-sm py-1"><span className="text-gray-500">{k}</span><span className="font-medium">{v}</span></div>
              ))}
              {os.finalizacao.obsFinais && (
                <p className="text-xs text-gray-400 mt-2 pt-2 border-t border-neon/10">{os.finalizacao.obsFinais}</p>
              )}
            </div>
          )}

          <div className="flex flex-col gap-2 mt-2">
            <button onClick={()=>router.push(`/ordens/editar?id=${id}`)} className="btn-neon w-full py-3 flex items-center justify-center gap-2">
              <Pencil className="w-4 h-4"/>Editar OS
            </button>
            <button onClick={()=>window.open(`/ordens/imprimir?id=${id}`,'_blank')} className="btn-ghost w-full py-3 flex items-center justify-center gap-2">
              <Printer className="w-4 h-4"/>Imprimir / Salvar PDF
            </button>
            <button onClick={()=>router.push(`/garantias/nova?ordemId=${id}`)} className="btn-ghost w-full py-3 flex items-center justify-center gap-2">
              <Shield className="w-4 h-4"/>Registrar Garantia
            </button>
            <button onClick={remover} className="btn-ghost w-full py-3 text-red-400 flex items-center justify-center gap-2">
              <Trash2 className="w-4 h-4"/>Remover OS
            </button>
          </div>
        </div>
      )}

      {/* ─── STATUS ─── */}
      {tab==='status' && (
        <div className="flex flex-col gap-4">
          {sel && (
            <div className="card">
              <p className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-3">Status atual</p>
              <div className="flex items-center gap-3 p-3 rounded-xl" style={{background:sel.bg,border:`1px solid ${sel.bd}`}}>
                <Clock className="w-5 h-5 flex-shrink-0" style={{color:sel.cor}}/>
                <span className="font-bold" style={{color:sel.cor}}>{sel.l}</span>
              </div>
            </div>
          )}

          <div className="card">
            <p className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-3">Alterar para</p>
            <div className="grid grid-cols-2 gap-2">
              {STATUS.map(s=>(
                <button key={s.v} onClick={()=>changeStatus(s.v)}
                  className="px-3 py-3 rounded-xl text-xs font-bold border text-left transition-all"
                  style={{
                    background:os.status===s.v?s.bg:'rgba(255,255,255,0.02)',
                    borderColor:os.status===s.v?s.bd:'rgba(255,255,255,0.07)',
                    color:os.status===s.v?s.cor:'#555',
                  }}>
                  {os.status===s.v?'✓ ':''}{s.l}
                </button>
              ))}
            </div>
          </div>

          {/* Formulário de entrega */}
          {confirmando && (
            <div style={{background:'rgba(0,255,65,0.04)',border:'1px solid rgba(0,255,65,0.25)',borderRadius:14,padding:16}}>
              <div className="flex flex-col items-center gap-3 py-2 mb-4">
                <div className="w-14 h-14 rounded-full bg-neon/10 border border-neon/30 flex items-center justify-center">
                  <CheckCircle className="w-7 h-7 text-neon"/>
                </div>
                <div className="text-center">
                  <p className="font-bold text-white">Finalizar OS #{os.numero}?</p>
                  <p className="text-sm text-gray-400 mt-1">{os.clienteNome}</p>
                </div>
              </div>

              {/* Resumo das peças já cadastradas — sem retrabalho */}
              <div style={{background:'rgba(255,255,255,0.03)',borderRadius:10,padding:12,marginBottom:14}}>
                <p className="lbl mb-2">Peças desta OS</p>
                {pecasOS.length === 0
                  ? <div className="flex items-center justify-between gap-2">
                      <p className="text-xs text-gray-500">Nenhuma peça cadastrada — serviço sem troca de peça?</p>
                      <button type="button" onClick={()=>{setConfirmando(false);setTab('pecas')}}
                        className="text-xs text-neon font-bold flex-shrink-0">+ Adicionar</button>
                    </div>
                  : <div className="flex flex-col gap-1.5">
                      {pecasOS.map(p => (
                        <div key={p.id} className="flex items-center gap-2 text-sm">
                          <span className="text-neon">●</span>
                          <span>{p.nome}{p.quantidade>1?` (${p.quantidade}x)`:''}</span>
                        </div>
                      ))}
                      <button type="button" onClick={()=>{setConfirmando(false);setTab('pecas')}}
                        className="text-xs text-neon font-bold mt-1 self-start">+ Adicionar outra peça</button>
                    </div>
                }
              </div>

              <div className="flex flex-col gap-3">
                <div>
                  <label className="lbl">Garantia do serviço</label>
                  <select value={finForm.garantiaDias} onChange={e=>setFin('garantiaDias',e.target.value)} className="input-dark">
                    <option value="30">30 dias</option><option value="60">60 dias</option>
                    <option value="90">90 dias</option><option value="180">6 meses</option>
                    <option value="365">1 ano</option>
                  </select>
                </div>
                <div><label className="lbl">Obs. finais</label><textarea value={finForm.obsFinais} onChange={e=>setFin('obsFinais',e.target.value)} rows={2} className="input-dark resize-none" placeholder="Laudo técnico..."/></div>
              </div>
              <div className="flex flex-col gap-2 mt-4">
                <button onClick={salvarFinalizacao} disabled={saving} className="btn-neon w-full py-3 flex items-center justify-center gap-2">
                  <ShieldCheck className="w-4 h-4"/>{saving?'Salvando...':'Confirmar entrega'}
                </button>
                <button onClick={()=>setConfirmando(false)} className="btn-ghost w-full py-2.5">Cancelar</button>
              </div>
            </div>
          )}
        </div>
      )}

      {/* ─── TESTES ─── */}
      {tab==='testes' && (
        <div>
          {!os.testes||Object.keys(os.testes).length===0
            ?<div className="card text-center py-12">
              <Smartphone className="w-10 h-10 text-gray-700 mx-auto mb-3"/>
              <p className="text-gray-500 text-sm">Nenhum teste registrado</p>
              <p className="text-xs text-gray-600 mt-1">Testes são adicionados ao criar a OS</p>
            </div>
            :<>
              <div className="card mb-4 flex gap-6 text-sm">
                <span style={{color:'#00FF41'}}>✓ {testesOK} OK</span>
                <span style={{color:'#ef4444'}}>✗ {testesDefeito} defeito</span>
                <span style={{color:'#444'}}>— {Object.keys(os.testes).length-testesOK-testesDefeito} n/t</span>
              </div>
              <div className="grid grid-cols-2 gap-2">
                {Object.entries(os.testes).map(([k,v])=>(
                  <div key={k} style={{
                    display:'flex',alignItems:'center',justifyContent:'space-between',
                    padding:'10px 12px',borderRadius:10,fontSize:12,
                    background:v==='ok'?'rgba(0,255,65,0.06)':v==='defeito'?'rgba(239,68,68,0.06)':'rgba(255,255,255,0.03)',
                    border:`1px solid ${v==='ok'?'rgba(0,255,65,0.2)':v==='defeito'?'rgba(239,68,68,0.2)':'rgba(255,255,255,0.07)'}`,
                  }}>
                    <span style={{color:'#777'}}>{TESTES_LABEL[k]||k}</span>
                    <span style={{fontWeight:700,color:v==='ok'?'#00FF41':v==='defeito'?'#ef4444':'#444'}}>
                      {v==='ok'?'✓':v==='defeito'?'✗':'—'}
                    </span>
                  </div>
                ))}
              </div>
            </>
          }
        </div>
      )}

      {/* ─── PEÇAS ─── */}
      {tab==='pecas' && (
        <div className="flex flex-col gap-4">
          {pecasOS.length===0
            ?<div className="card text-center py-8">
              <Package className="w-8 h-8 text-gray-700 mx-auto mb-2"/>
              <p className="text-gray-500 text-sm">Nenhuma peça registrada</p>
            </div>
            :pecasOS.map(p=>(
              <div key={p.id} className="card flex justify-between items-start">
                <div>
                  <p className="font-bold text-sm">{p.nome}</p>
                  {p.fornecedorNome&&<p className="text-xs text-gray-500 mt-0.5">{p.fornecedorNome}</p>}
                  {p.dataCompra&&<p className="text-xs text-gray-600 mt-0.5">{new Date(p.dataCompra).toLocaleDateString('pt-BR')}</p>}
                </div>
                <div className="text-right">
                  <p className="font-bold text-neon">{R$(p.valor)}</p>
                  {p.quantidade>1&&<p className="text-xs text-gray-500">x{p.quantidade}</p>}
                  {p.garantiaDias&&<p className="text-xs text-gray-600">Gar: {p.garantiaDias}d</p>}
                </div>
              </div>
            ))
          }
          <div style={{borderTop:'1px solid rgba(255,255,255,0.07)',paddingTop:16}}>
            <p className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-3">Registrar nova peça</p>
            <div className="flex flex-col gap-3">
              <div><label className="lbl">Peça *</label><input type="text" value={pecaForm.nome} onChange={e=>setPeca('nome',e.target.value)} className="input-dark" placeholder="Ex: Tela, Bateria..."/></div>
              <div>
                <label className="lbl">Fornecedor</label>
                <select value={pecaForm.fornecedorId} onChange={e=>{const f=forns.find(x=>x.id===e.target.value);setPeca('fornecedorId',e.target.value);setPeca('fornecedorNome',f?.nome||'')}} className="input-dark">
                  <option value="">Selecionar...</option>
                  {forns.map(f=><option key={f.id} value={f.id}>{f.nome}</option>)}
                </select>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div><label className="lbl">Valor (R$)</label><input type="number" value={pecaForm.valor} onChange={e=>setPeca('valor',e.target.value)} className="input-dark" step="0.01"/></div>
                <div><label className="lbl">Qtd.</label><input type="number" value={pecaForm.quantidade} onChange={e=>setPeca('quantidade',e.target.value)} className="input-dark" min="1"/></div>
              </div>
              <button onClick={adicionarPeca} disabled={saving} className="btn-ghost w-full py-3 flex items-center justify-center gap-2">
                <Package className="w-4 h-4"/>{saving?'Salvando...':'Registrar peça'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

export default function DetalheOSPage(){
  return(
    <Suspense fallback={
      <div className="flex flex-col items-center justify-center py-20 gap-3">
        <div className="w-7 h-7 border-2 border-neon border-t-transparent rounded-full animate-spin"/>
        <p className="text-xs text-gray-500">Carregando...</p>
      </div>
    }>
      <DetalheOSInner/>
    </Suspense>
  )
}
