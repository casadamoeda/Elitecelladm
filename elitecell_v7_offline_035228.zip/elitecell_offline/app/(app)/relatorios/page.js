'use client'
import { useEffect, useState } from 'react'
import { ordens as ordensDb, clientes as cliDb, getFinanceResumo } from '@/lib/firestore'
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts'
import { BarChart2, RefreshCw, TrendingUp, Users, ClipboardList, DollarSign } from 'lucide-react'

const R$ = v => (v||0).toLocaleString('pt-BR',{style:'currency',currency:'BRL'})
const COLORS = ['#00FF41','#00CC34','#4DFF7C','#80FFA6','#33FF77','#99FFCC']
const SL = {
  recebido:'Recebido', em_analise:'Análise', aguardando_aprovacao:'Aprov',
  aguardando_peca:'Peça', em_reparo:'Reparo', testes_finais:'Testes',
  pronto:'Pronto', entregue:'Entregue', cancelado:'Cancelado', sem_reparo:'Sem reparo'
}

export default function RelatoriosPage() {
  const [data, setData]     = useState(null)
  const [loading, setLoad]  = useState(true)

  const load = async () => {
    setLoad(true)
    const [os, cli, resumo] = await Promise.all([ordensDb.list(), cliDb.list(), getFinanceResumo()])

    // Faturamento mensal real — OS entregues, agrupadas por mês de entrega
    const meses = Array.from({ length: 6 }, (_, i) => {
      const d = new Date(); d.setMonth(d.getMonth() - (5 - i))
      return { mes: d.toLocaleString('pt-BR', { month: 'short' }), m: d.getMonth(), y: d.getFullYear(), v: 0 }
    })
    os.filter(o => o.status === 'entregue').forEach(o => {
      const d = o.finalizacao?.dataEntrega ? new Date(o.finalizacao.dataEntrega)
              : o.atualizadoEm?.toDate?.() ?? o.criadoEm?.toDate?.() ?? new Date()
      const idx = meses.findIndex(m => m.m === d.getMonth() && m.y === d.getFullYear())
      if (idx >= 0) meses[idx].v += o.valorTotal ?? o.valorServico ?? 0
    })

    // Ordens por status
    const stC = {}
    os.forEach(o => { stC[o.status] = (stC[o.status] || 0) + 1 })
    const porStatus = Object.entries(stC).map(([k, v]) => ({ name: SL[k] || k, value: v }))

    // Top clientes
    const cC = {}
    os.forEach(o => { if (o.clienteNome) cC[o.clienteNome] = (cC[o.clienteNome] || 0) + 1 })
    const topCli = Object.entries(cC).sort((a, b) => b[1] - a[1]).slice(0, 5).map(([nome, total]) => ({ nome, total }))

    setData({
      faturMensal: meses,
      porStatus,
      topCli,
      totalOS: os.length,
      totalCli: cli.length,
      // Mesmos números do Dashboard e Financeiro — fonte única
      faturTotal: resumo.faturTotal,
      lucroTotal: resumo.lucroTotal,
    })
    setLoad(false)
  }
  useEffect(() => { load() }, [])

  if (loading) return (
    <div className="flex justify-center py-24">
      <div className="w-8 h-8 border-2 border-neon border-t-transparent rounded-full animate-spin"/>
    </div>
  )

  return (
    <div className="fu">
      <div className="flex items-center justify-between mb-5">
        <div>
          <h1 className="text-xl font-black flex items-center gap-2"><BarChart2 className="w-5 h-5 text-neon"/>Relatórios</h1>
          <p className="text-xs text-gray-500">Visão geral do negócio</p>
        </div>
        <button onClick={load} className="p-2 hover:bg-surface-light rounded-lg border border-surface-border">
          <RefreshCw className="w-4 h-4 text-gray-400"/>
        </button>
      </div>

      {/* KPIs */}
      <div className="grid grid-cols-2 gap-2 mb-4">
        {[
          { icon: ClipboardList, label: 'Total de OS',   value: data.totalOS },
          { icon: Users,         label: 'Clientes',      value: data.totalCli },
          { icon: TrendingUp,    label: 'Faturamento',   value: R$(data.faturTotal) },
          { icon: DollarSign,    label: 'Lucro total',   value: R$(data.lucroTotal) },
        ].map(({ icon: Icon, label, value }) => (
          <div key={label} className="card hover:border-neon/30 transition-colors">
            <Icon className="w-4 h-4 text-neon mb-2"/>
            <p className="text-xl font-black text-neon">{value}</p>
            <p className="text-xs text-gray-500">{label}</p>
          </div>
        ))}
      </div>

      {/* Faturamento mensal */}
      <div className="card mb-4">
        <p className="text-sm font-bold mb-4">Faturamento — Últimos 6 meses</p>
        <ResponsiveContainer width="100%" height={180}>
          <BarChart data={data.faturMensal}>
            <XAxis dataKey="mes" tick={{ fill: '#555', fontSize: 11 }} axisLine={false} tickLine={false}/>
            <YAxis tick={{ fill: '#555', fontSize: 11 }} axisLine={false} tickLine={false} tickFormatter={v => `R$${v}`}/>
            <Tooltip contentStyle={{ background: '#161616', border: '1px solid #222', borderRadius: 8, color: '#fff', fontSize: 12 }}
              formatter={v => [R$(v), 'Faturamento']}/>
            <Bar dataKey="v" fill="#00FF41" radius={[4, 4, 0, 0]}/>
          </BarChart>
        </ResponsiveContainer>
      </div>

      {/* Ordens por status */}
      {data.porStatus.length > 0 && (
        <div className="card mb-4">
          <p className="text-sm font-bold mb-4">Ordens por status</p>
          <ResponsiveContainer width="100%" height={180}>
            <PieChart>
              <Pie data={data.porStatus} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={65}>
                {data.porStatus.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]}/>)}
              </Pie>
              <Tooltip contentStyle={{ background: '#161616', border: '1px solid #222', borderRadius: 8, color: '#fff', fontSize: 12 }}/>
            </PieChart>
          </ResponsiveContainer>
        </div>
      )}

      {/* Top clientes */}
      {data.topCli.length > 0 && (
        <div className="card">
          <p className="text-sm font-bold mb-4">Top clientes</p>
          <div className="flex flex-col gap-3">
            {data.topCli.map((c, i) => (
              <div key={c.nome} className="flex items-center gap-3">
                <span className="text-xs font-mono text-neon w-4">{i + 1}</span>
                <div className="flex-1">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs text-white">{c.nome}</span>
                    <span className="text-xs text-neon font-bold">{c.total} OS</span>
                  </div>
                  <div className="h-1.5 bg-surface-light rounded-full overflow-hidden">
                    <div className="h-full bg-neon rounded-full" style={{ width: `${(c.total / data.topCli[0].total) * 100}%` }}/>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}
