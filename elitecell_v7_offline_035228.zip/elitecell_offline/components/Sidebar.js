'use client'
import Link from 'next/link'
import { usePathname, useRouter } from 'next/navigation'
import { useAuth } from '@/lib/contexts/AuthContext'
import toast from 'react-hot-toast'
import { LayoutDashboard,Users,ClipboardList,Package,DollarSign,Shield,Truck,BarChart2,LogOut,Menu,X } from 'lucide-react'
import { useState } from 'react'
import ConnectionIndicator from '@/components/ConnectionIndicator'

const NAV_GROUPS = [
  {
    label: 'Operação',
    items: [
      { href: '/dashboard',    icon: LayoutDashboard, label: 'Dashboard' },
      { href: '/clientes',     icon: Users,           label: 'Clientes' },
      { href: '/ordens',       icon: ClipboardList,   label: 'Ordens de Serviço' },
      { href: '/entregas',     icon: Truck,           label: 'Coletas & Entregas' },
    ],
  },
  {
    label: 'Negócio',
    items: [
      { href: '/fornecedores', icon: Package,    label: 'Peças & Fornecedores' },
      { href: '/financeiro',   icon: DollarSign, label: 'Financeiro' },
      { href: '/garantias',    icon: Shield,     label: 'Garantias' },
      { href: '/relatorios',   icon: BarChart2,  label: 'Relatórios' },
    ],
  },
]

function Inner({ onClose }) {
  const pathname = usePathname()
  const { logout, user } = useAuth()
  const router = useRouter()
  const handleLogout = async () => { await logout(); toast.success('Até logo!'); router.push('/') }
  return (
    <div className="flex flex-col h-full">
      {/* Logo */}
      <div className="flex items-center gap-3 px-4 py-4 border-b border-surface-border">
        <img
          src="/logo.png"
          alt="EliteCell"
          style={{ width: 44, height: 44, borderRadius: '50%', objectFit: 'cover', border: '1.5px solid rgba(0,255,65,0.3)', flexShrink: 0 }}
        />
        <div>
          <p className="font-black text-sm">ELITE<span className="text-neon">CELL</span></p>
          <p className="text-[10px] text-gray-600">Assistência Técnica</p>
        </div>
      </div>

      <nav className="flex-1 overflow-y-auto py-3 px-2 flex flex-col gap-1">
        {NAV_GROUPS.map((group, gi) => (
          <div key={group.label} className={gi > 0 ? 'mt-3' : ''}>
            <p className="px-3 mb-1 text-[10px] font-bold text-gray-600 uppercase tracking-wider">{group.label}</p>
            <div className="flex flex-col gap-0.5">
              {group.items.map(({href,icon:Icon,label}) => (
                <Link key={href} href={href} onClick={onClose} className={`nav-item ${pathname===href?'active':''}`}>
                  <Icon className="w-4 h-4 flex-shrink-0"/><span className="truncate">{label}</span>
                </Link>
              ))}
            </div>
          </div>
        ))}
      </nav>

      <div className="border-t border-surface-border px-2 py-3">
        {/* Indicador de conexão */}
        <div className="px-3 mb-2">
          <ConnectionIndicator />
        </div>
        <Link href="/sincronizacao" onClick={onClose} className={`nav-item text-xs text-gray-500 hover:text-gray-300 mb-1 ${pathname==='/sincronizacao'?'active':''}`}>
          <span className="w-4 h-4 text-center">🔄</span>
          <span>Sincronização</span>
        </Link>
        <p className="text-[10px] text-gray-600 px-3 mb-1 truncate">{user?.email}</p>
        <button onClick={handleLogout} className="nav-item w-full text-red-500 hover:text-red-400 hover:bg-red-500/10">
          <LogOut className="w-4 h-4"/>Sair
        </button>
      </div>
    </div>
  )
}

export default function Sidebar() {
  const [open, setOpen] = useState(false)
  return (
    <>
      {/* Desktop sidebar */}
      <aside className="hidden lg:flex flex-col w-56 flex-shrink-0 bg-surface h-screen sticky top-0 border-r border-surface-border">
        <Inner onClose={()=>{}}/>
      </aside>

      {/* Mobile top bar */}
      <div className="lg:hidden fixed top-0 left-0 right-0 z-40 bg-dark/95 backdrop-blur border-b border-surface-border h-14 flex items-center px-4 gap-3">
        <button onClick={()=>setOpen(true)} className="p-2 rounded-lg hover:bg-surface-light">
          <Menu className="w-5 h-5 text-neon"/>
        </button>
        <img src="/logo.png" alt="Logo" style={{width:32,height:32,borderRadius:'50%',objectFit:'cover',border:'1px solid rgba(0,255,65,0.3)'}}/>
        <span className="font-black text-sm flex-1">ELITE<span className="text-neon">CELL</span></span>
        <ConnectionIndicator />
      </div>

      {/* Mobile drawer */}
      {open && <>
        <div className="lg:hidden fixed inset-0 z-50 bg-black/70" onClick={()=>setOpen(false)}/>
        <aside className="lg:hidden fixed left-0 top-0 bottom-0 z-50 w-64 bg-surface border-r border-surface-border flex flex-col sl">
          <button onClick={()=>setOpen(false)} className="absolute top-3 right-3 p-2 hover:bg-surface-light rounded-lg">
            <X className="w-4 h-4 text-gray-400"/>
          </button>
          <Inner onClose={()=>setOpen(false)}/>
        </aside>
      </>}
    </>
  )
}
