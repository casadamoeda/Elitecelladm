'use client'
import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { financeiro as db, getFinanceResumo } from '@/lib/firestore'
import toast from 'react-hot-toast'
import { format } from 'date-fns'
import { ptBR } from 'date-fns/locale'
import { DollarSign, Plus, ArrowUpRight, ArrowDownRight, Trash2, TrendingUp, Package, Info } from 'lucide-react'

const R$ = v => (v||0).toLocaleString('pt-BR',{style:'currency',currency:'BRL'})

export default function FinanceiroPage() {
  const router = useRouter()
  const [list,  setList]    = useState([])
  const [stats, setStats]   = useState(null)
  const [tab,   setTab]     = useState('resumo')
  const [loading, setLoad]  = useState(true)

  const load = async () => {
    setLoad(true)
    try {
      const [fin, resumo] = await Promise.all([db.list(), getFinanceResumo()])
      setList(fin)
      setStats(resumo)
    } catch {}
    setLoad(false)
  }
  useEffect(()=>{load()},[])

  const del = async (t) => {
    if (!confirm('Remover lançamento?')) return
    await db.delete(t.id); toast.success('Removido'); load()
  }

  const totalIn  = list.filter(t=>t.tipo==='entrada').reduce((s,t)=>s+(t.valor||0),0)
  const totalOut = list.filter(t=>t.tipo==='saida').reduce((s,t)=>s+(t.valor||0),0)

  return (
    <div className="fu">
      <div className="flex items-center justify-between mb-5">
        <div>
          <h1 className="text-xl font-black flex items-center gap-2"><DollarSign className="w-5 h-5 text-neon"/>Financeiro</h1>
          <p className="text-xs text-gray-500">Resultado do negócio e caixa</p>
        </div>
        <button onClick={()=>router.push('/financeiro/novo')} className="btn-neon flex items-center gap-2 text-sm">
          <Plus className="w-4 h-4"/>Lançar
        </button>
      </div>

      {/* Cards de resumo — fonte única, igual ao Dashboard e Relatórios */}
      {stats && (
        <div className="grid grid-cols-3 gap-2 mb-5">
          <div className="card text-center">
            <ArrowUpRight className="w-4 h-4 text-neon mx-auto mb-1"/>
            <p className="text-sm font-black text-neon">{R$(stats.faturTotal)}</p>
            <p className="text-[10px] text-gray-500">Faturamento</p>
          </div>
          <div className="card text-center">
            <Package className="w-4 h-4 text-red-400 mx-auto mb-1"/>
            <p className="text-sm font-black text-red-400">{R$(stats.custoTotal)}</p>
            <p className="text-[10px] text-gray-500">Custo peças</p>
          </div>
          <div className={`card text-center border ${stats.lucroTotal>=0?'border-neon/20':'border-red-500/20'}`}>
            <TrendingUp className={`w-4 h-4 mx-auto mb-1 ${stats.lucroTotal>=0?'text-neon':'text-red-400'}`}/>
            <p className={`text-sm font-black ${stats.lucroTotal>=0?'text-neon':'text-red-400'}`}>{R$(stats.lucroTotal)}</p>
            <p className="text-[10px] text-gray-500">Lucro</p>
          </div>
        </div>
      )}

      {/* Abas */}
      <div style={{display:'flex',gap:4,background:'rgba(255,255,255,0.04)',borderRadius:12,padding:4,marginBottom:16}}>
        {[['resumo','Resumo do negócio'],['caixa','Caixa manual']].map(([v,l])=>(
          <button key={v} onClick={()=>setTab(v)} style={{flex:1,padding:'8px 4px',borderRadius:9,fontSize:12,fontWeight:700,border:'none',cursor:'pointer',transition:'all .2s',background:tab===v?'#00FF41':'transparent',color:tab===v?'#000':'#666'}}>{l}</button>
        ))}
      </div>

      {loading
        ? <div className="flex justify-center py-12"><div className="w-6 h-6 border-2 border-neon border-t-transparent rounded-full animate-spin"/></div>
        : tab==='resumo'
          ? <div className="flex flex-col gap-3">
              <div className="card flex items-start gap-2" style={{background:'rgba(0,255,65,0.04)',borderColor:'rgba(0,255,65,0.15)'}}>
                <Info className="w-4 h-4 text-neon flex-shrink-0 mt-0.5"/>
                <p className="text-xs text-gray-400 leading-relaxed">
                  Esses números vêm das OS marcadas como <strong className="text-white">Entregue</strong> e do custo real das peças usadas. São os mesmos valores exibidos no Dashboard e nos Relatórios.
                </p>
              </div>
              <div className="card">
                <p className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-3">Total acumulado</p>
                {[
                  ['Faturamento (OS entregues)', stats.faturTotal, 'text-neon'],
                  ['Custo de peças', stats.custoTotal, 'text-red-400'],
                  ['Lucro líquido', stats.lucroTotal, stats.lucroTotal>=0?'text-neon':'text-red-400'],
                ].map(([l,v,c])=>(
                  <div key={l} className="flex justify-between text-sm py-2 border-b border-surface-border last:border-0">
                    <span className="text-gray-400">{l}</span>
                    <span className={`font-bold ${c}`}>{R$(v)}</span>
                  </div>
                ))}
              </div>
              <div className="card">
                <p className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-3">Este mês</p>
                {[
                  ['Faturamento do mês', stats.faturMes, 'text-neon'],
                  ['Custo do mês', stats.custoMes, 'text-red-400'],
                  ['Lucro do mês', stats.lucroMes, stats.lucroMes>=0?'text-neon':'text-red-400'],
                ].map(([l,v,c])=>(
                  <div key={l} className="flex justify-between text-sm py-2 border-b border-surface-border last:border-0">
                    <span className="text-gray-400">{l}</span>
                    <span className={`font-bold ${c}`}>{R$(v)}</span>
                  </div>
                ))}
              </div>
            </div>
          : <div className="flex flex-col gap-3">
              <div className="card flex items-start gap-2">
                <Info className="w-4 h-4 text-gray-500 flex-shrink-0 mt-0.5"/>
                <p className="text-xs text-gray-500 leading-relaxed">
                  Lançamentos manuais avulsos (gorjetas, despesas extras, etc). <strong className="text-gray-300">Não entram</strong> no cálculo de lucro do negócio acima.
                </p>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div className="card text-center">
                  <p className="text-sm font-black text-neon">{R$(totalIn)}</p>
                  <p className="text-[10px] text-gray-500">Entradas manuais</p>
                </div>
                <div className="card text-center">
                  <p className="text-sm font-black text-red-400">{R$(totalOut)}</p>
                  <p className="text-[10px] text-gray-500">Saídas manuais</p>
                </div>
              </div>
              {list.length===0
                ? <div className="card text-center py-12"><DollarSign className="w-10 h-10 text-gray-700 mx-auto mb-3"/><p className="text-gray-500 text-sm">Nenhum lançamento manual</p></div>
                : <div className="card p-0 overflow-hidden">
                    <div className="divide-y divide-surface-border">
                      {list.map(t=>(
                        <div key={t.id} className="flex items-center gap-3 px-4 py-3">
                          <div className={`w-8 h-8 rounded-xl flex items-center justify-center flex-shrink-0 ${t.tipo==='entrada'?'bg-neon/10':'bg-red-500/10'}`}>
                            {t.tipo==='entrada'?<ArrowUpRight className="w-4 h-4 text-neon"/>:<ArrowDownRight className="w-4 h-4 text-red-400"/>}
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-medium truncate">{t.descricao||t.categoria}</p>
                            <p className="text-[10px] text-gray-500">{t.categoria}{t.formaPagamento?` · ${t.formaPagamento}`:''}</p>
                          </div>
                          <div className="text-right flex-shrink-0">
                            <p className={`text-sm font-bold ${t.tipo==='entrada'?'text-neon':'text-red-400'}`}>
                              {t.tipo==='entrada'?'+':'-'}{R$(t.valor)}
                            </p>
                            <p className="text-[10px] text-gray-600">
                              {t.criadoEm?.toDate?format(t.criadoEm.toDate(),'dd/MM HH:mm',{locale:ptBR}):'—'}
                            </p>
                          </div>
                          <button onClick={()=>del(t)} className="p-1.5 hover:bg-red-500/10 rounded-lg flex-shrink-0">
                            <Trash2 className="w-3.5 h-3.5 text-red-500/50"/>
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
              }
            </div>
      }
    </div>
  )
}
