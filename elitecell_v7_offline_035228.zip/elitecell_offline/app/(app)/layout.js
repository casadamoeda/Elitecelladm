'use client'
import { useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { useAuth } from '@/lib/contexts/AuthContext'
import Sidebar from '@/components/Sidebar'

export default function AppLayout({ children }) {
  const { user, loading } = useAuth()
  const router = useRouter()
  useEffect(() => { if (!loading && !user) router.push('/') }, [user, loading, router])
  if (loading) return <div className="min-h-screen bg-dark flex items-center justify-center"><div className="w-8 h-8 border-2 border-neon border-t-transparent rounded-full animate-spin"/></div>
  if (!user) return null
  return (
    <div className="flex min-h-screen bg-dark">
      <Sidebar/>
      <main className="flex-1 min-w-0 pt-14 lg:pt-0 overflow-x-hidden">
        <div className="max-w-4xl mx-auto p-4 lg:p-6">{children}</div>
      </main>
    </div>
  )
}
