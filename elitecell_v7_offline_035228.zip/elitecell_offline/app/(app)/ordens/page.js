'use client'
import { useEffect, useState, Suspense } from 'react'
import { useRouter } from 'next/navigation'
import { ordens as db } from '@/lib/firestore'
import { ClipboardList, Plus, Search, Smartphone, ChevronRight, Archive } from 'lucide-react'

const R$ = v => (v||0).toLocaleString('pt-BR',{style:'currency',currency:'BRL'})

const STATUS_ATIVOS = [
  {v:'recebido',            l:'Recebido',         c:'text-blue-400   bg-blue-500/10   border-blue-500/20'},
  {v:'em_analise',          l:'Em análise',        c:'text-yellow-400 bg-yellow-500/10 border-yellow-500/20'},
  {v:'aguardando_aprovacao',l:'Ag. aprovação',     c:'text-orange-400 bg-orange-500/10 border-orange-500/20'},
  {v:'aguardando_peca',     l:'Ag. peça',          c:'text-purple-400 bg-purple-500/10 border-purple-500/20'},
  {v:'em_reparo',           l:'Em reparo',         c:'text-cyan-400   bg-cyan-500/10   border-cyan-500/20'},
  {v:'testes_finais',       l:'Testes finais',     c:'text-indigo-400 bg-indigo-500/10 border-indigo-500/20'},
  {v:'pronto',              l:'Pronto ✓',          c:'text-neon       bg-neon/10        border-neon/20'},
]
const STATUS_CONCLUIDOS = [
  {v:'entregue',   l:'Entregue ✓✓', c:'text-gray-400 bg-gray-500/10 border-gray-500/20'},
  {v:'cancelado',  l:'Cancelado',   c:'text-red-400  bg-red-500/10  border-red-500/20'},
  {v:'sem_reparo', l:'Sem reparo',  c:'text-red-500  bg-red-900/20  border-red-900/30'},
]
const STATUS_ALL = [...STATUS_ATIVOS, ...STATUS_CONCLUIDOS]
const ATIVOS_KEYS = STATUS_ATIVOS.map(s=>s.v)

function Badge({ status }) {
  const s = STATUS_ALL.find(x => x.v === status)
  return s ? <span className={`badge border ${s.c}`}>{s.l}</span> : null
}

function OrdemCard({ o, router }) {
  return (
    <button onClick={()=>router.push(`/ordens/detalhe?id=${o.id}`)}
      className="card text-left flex items-center gap-3 hover:border-neon/20 transition-colors w-full">
      <div className="w-11 h-11 rounded-xl bg-surface-light border border-surface-border flex flex-col items-center justify-center flex-shrink-0">
        <Smartphone className="w-4 h-4 text-neon"/>
        <span className="text-[9px] font-mono text-gray-500">#{o.numero}</span>
      </div>
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 flex-wrap">
          <p className="font-semibold text-sm">{o.clienteNome}</p>
          <Badge status={o.status}/>
        </div>
        <p className="text-xs text-gray-400 truncate">{o.marca} {o.modelo}</p>
      </div>
      <div className="flex items-center gap-2 flex-shrink-0">
        <p className="text-sm font-bold text-neon">{R$(o.valorTotal ?? o.valorServico ?? 0)}</p>
        <ChevronRight className="w-4 h-4 text-gray-600"/>
      </div>
    </button>
  )
}

function OrdensInner() {
  const router = useRouter()
  const [list, setList]     = useState([])
  const [busca, setBusca]   = useState('')
  const [filtro, setFiltro] = useState('')
  const [aba, setAba]       = useState('ativas')
  const [loading, setLoad]  = useState(true)

  useEffect(() => { db.list().then(o => { setList(o); setLoad(false) }) }, [])

  const ativas     = list.filter(o => ATIVOS_KEYS.includes(o.status))
  const concluidas = list.filter(o => !ATIVOS_KEYS.includes(o.status))
  const base = aba === 'ativas' ? ativas : concluidas
  const statusOptions = aba === 'ativas' ? STATUS_ATIVOS : STATUS_CONCLUIDOS

  const filtered = base.filter(o => {
    const m = o.clienteNome?.toLowerCase().includes(busca.toLowerCase())
           || o.modelo?.toLowerCase().includes(busca.toLowerCase())
           || o.numero?.includes(busca)
    return m && (!filtro || o.status === filtro)
  })

  return (
    <div className="fu">
      <div className="flex items-center justify-between mb-5">
        <div>
          <h1 className="text-xl font-black flex items-center gap-2">
            <ClipboardList className="w-5 h-5 text-neon"/>Ordens de Serviço
          </h1>
          <p className="text-xs text-gray-500">{ativas.length} em andamento · {concluidas.length} concluídas</p>
        </div>
        <button onClick={() => router.push('/ordens/nova')} className="btn-neon flex items-center gap-2 text-sm">
          <Plus className="w-4 h-4"/>Nova OS
        </button>
      </div>

      {/* Abas: Em Andamento vs Concluídas */}
      <div style={{display:'flex',gap:4,background:'rgba(255,255,255,0.04)',borderRadius:12,padding:4,marginBottom:16}}>
        {[['ativas',`Em Andamento (${ativas.length})`],['concluidas',`Concluídas (${concluidas.length})`]].map(([v,l]) => (
          <button key={v} onClick={() => { setAba(v); setFiltro('') }}
            style={{flex:1,padding:'9px 4px',borderRadius:9,fontSize:12,fontWeight:700,border:'none',cursor:'pointer',transition:'all .2s',
              background:aba===v?'#00FF41':'transparent', color:aba===v?'#000':'#666'}}>
            {l}
          </button>
        ))}
      </div>

      <div className="flex gap-2 mb-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500"/>
          <input value={busca} onChange={e => setBusca(e.target.value)}
            placeholder="OS, cliente, modelo..." className="input-dark pl-10"/>
        </div>
        <select value={filtro} onChange={e => setFiltro(e.target.value)} className="input-dark w-36">
          <option value="">Todos status</option>
          {statusOptions.map(s => <option key={s.v} value={s.v}>{s.l}</option>)}
        </select>
      </div>

      {loading
        ? <div className="flex justify-center py-12"><div className="w-6 h-6 border-2 border-neon border-t-transparent rounded-full animate-spin"/></div>
        : filtered.length === 0
          ? <div className="card text-center py-12">
              {aba === 'ativas'
                ? <>
                    <ClipboardList className="w-10 h-10 text-gray-700 mx-auto mb-3"/>
                    <p className="text-gray-500 text-sm">Nenhuma OS em andamento</p>
                    <button onClick={() => router.push('/ordens/nova')} className="btn-neon mt-4 text-sm">Criar primeira OS</button>
                  </>
                : <>
                    <Archive className="w-10 h-10 text-gray-700 mx-auto mb-3"/>
                    <p className="text-gray-500 text-sm">Nenhuma OS concluída ainda</p>
                  </>
              }
            </div>
          : <div className="flex flex-col gap-2">
              {filtered.map(o => <OrdemCard key={o.id} o={o} router={router}/>)}
            </div>
      }
    </div>
  )
}

export default function OrdensPage() {
  return (
    <Suspense fallback={<div className="flex justify-center py-12"><div className="w-6 h-6 border-2 border-neon border-t-transparent rounded-full animate-spin"/></div>}>
      <OrdensInner/>
    </Suspense>
  )
}
