'use client'
import { useEffect, useState, Suspense } from 'react'
import { useRouter, useSearchParams } from 'next/navigation'
import { clientes as db } from '@/lib/firestore'
import toast from 'react-hot-toast'
import { ArrowLeft, User } from 'lucide-react'

const EMPTY = { nome: '', telefone: '', whatsapp: '', cpf: '', endereco: '', bairro: '', cidade: '', observacoes: '' }

function EditarClienteInner() {
  const router = useRouter()
  const params = useSearchParams()
  const id = params.get('id')
  const [form, setForm] = useState(EMPTY)
  const [saving, setSaving] = useState(false)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (!id) { router.replace('/clientes'); return }
    db.get(id).then(c => {
      if (c) setForm({ nome: c.nome || '', telefone: c.telefone || '', whatsapp: c.whatsapp || '', cpf: c.cpf || '', endereco: c.endereco || '', bairro: c.bairro || '', cidade: c.cidade || '', observacoes: c.observacoes || '' })
      setLoading(false)
    })
  }, [id])

  const set = (f, v) => setForm(p => ({ ...p, [f]: v }))

  const save = async () => {
    if (!form.nome.trim()) return toast.error('Nome obrigatório')
    setSaving(true)
    try {
      await db.update(id, form)
      toast.success('Cliente atualizado!')
      router.back()
    } catch { toast.error('Erro ao salvar') } finally { setSaving(false) }
  }

  if (loading) return (
    <div className="flex justify-center py-20">
      <div className="w-6 h-6 border-2 border-neon border-t-transparent rounded-full animate-spin" />
    </div>
  )

  return (
    <div className="fu">
      <div className="flex items-center gap-3 mb-6">
        <button onClick={() => router.back()} className="p-2 hover:bg-surface-light rounded-lg transition-colors flex-shrink-0">
          <ArrowLeft className="w-5 h-5 text-gray-400" />
        </button>
        <div>
          <h1 className="text-xl font-black flex items-center gap-2">
            <User className="w-5 h-5 text-neon" />Editar Cliente
          </h1>
          <p className="text-xs text-gray-500 truncate">{form.nome}</p>
        </div>
      </div>

      <div className="flex flex-col gap-4 mb-6">
        <div>
          <label className="lbl">Nome *</label>
          <input type="text" value={form.nome} onChange={e => set('nome', e.target.value)} className="input-dark" />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="lbl">Telefone</label>
            <input type="tel" value={form.telefone} onChange={e => set('telefone', e.target.value)} className="input-dark" />
          </div>
          <div>
            <label className="lbl">WhatsApp</label>
            <input type="tel" value={form.whatsapp} onChange={e => set('whatsapp', e.target.value)} className="input-dark" />
          </div>
          <div>
            <label className="lbl">CPF</label>
            <input type="text" value={form.cpf} onChange={e => set('cpf', e.target.value)} className="input-dark" />
          </div>
          <div>
            <label className="lbl">Cidade</label>
            <input type="text" value={form.cidade} onChange={e => set('cidade', e.target.value)} className="input-dark" />
          </div>
          <div>
            <label className="lbl">Bairro</label>
            <input type="text" value={form.bairro} onChange={e => set('bairro', e.target.value)} className="input-dark" />
          </div>
        </div>
        <div>
          <label className="lbl">Endereço</label>
          <input type="text" value={form.endereco} onChange={e => set('endereco', e.target.value)} className="input-dark" />
        </div>
        <div>
          <label className="lbl">Observações</label>
          <textarea value={form.observacoes} onChange={e => set('observacoes', e.target.value)} rows={3} className="input-dark resize-none" />
        </div>
      </div>

      <div className="flex flex-col gap-2">
        <button onClick={save} disabled={saving} className="btn-neon w-full py-3 text-base">
          {saving ? 'Salvando...' : 'Salvar Alterações'}
        </button>
        <button onClick={() => router.back()} className="btn-ghost w-full py-3">Cancelar</button>
      </div>
    </div>
  )
}

export default function EditarClientePage() {
  return (
    <Suspense fallback={<div className="flex justify-center py-20"><div className="w-6 h-6 border-2 border-neon border-t-transparent rounded-full animate-spin" /></div>}>
      <EditarClienteInner />
    </Suspense>
  )
}
