'use client'
import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { fornecedores as fornDb, pecas as pecasDb } from '@/lib/firestore'
import toast from 'react-hot-toast'
import { Package, Plus, Truck, ShoppingBag, Phone, Trash2 } from 'lucide-react'

const R$ = v => (v || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })

export default function FornecedoresPage() {
  const router = useRouter()
  const [tab, setTab] = useState('fornecedores')
  const [forns, setForns] = useState([])
  const [pecas, setPecas] = useState([])
  const [loading, setLoading] = useState(true)

  const load = async () => {
    setLoading(true)
    const [f, p] = await Promise.all([fornDb.list(), pecasDb.list()])
    setForns(f); setPecas(p); setLoading(false)
  }
  useEffect(() => { load() }, [])

  const delForn = async (f) => {
    if (!confirm(`Remover ${f.nome}?`)) return
    await fornDb.delete(f.id)
    toast.success('Removido')
    load()
  }
  const delPeca = async (p) => {
    if (!confirm(`Remover ${p.nome}?`)) return
    await pecasDb.delete(p.id)
    toast.success('Removido')
    load()
  }

  return (
    <div className="fu">
      <div className="flex items-center justify-between mb-5">
        <h1 className="text-xl font-black flex items-center gap-2">
          <Package className="w-5 h-5 text-neon" />Peças & Fornecedores
        </h1>
        <button
          onClick={() => router.push(tab === 'fornecedores' ? '/fornecedores/novo' : '/fornecedores/nova-peca')}
          className="btn-neon flex items-center gap-2 text-sm"
        >
          <Plus className="w-4 h-4" />{tab === 'fornecedores' ? 'Fornecedor' : 'Peça'}
        </button>
      </div>

      <div className="flex gap-1 mb-4 bg-surface-light border border-surface-border rounded-xl p-1">
        {[['fornecedores', 'Fornecedores'], ['pecas', 'Peças']].map(([k, l]) => (
          <button key={k} onClick={() => setTab(k)} className={`flex-1 py-2 rounded-lg text-sm font-medium transition-all ${tab === k ? 'bg-neon text-black' : 'text-gray-400 hover:text-white'}`}>
            {l}
          </button>
        ))}
      </div>

      {loading
        ? <div className="flex justify-center py-12"><div className="w-6 h-6 border-2 border-neon border-t-transparent rounded-full animate-spin" /></div>
        : tab === 'fornecedores'
          ? <div className="flex flex-col gap-2">
              {forns.length === 0 && (
                <div className="card text-center py-12">
                  <Truck className="w-10 h-10 text-gray-700 mx-auto mb-3" />
                  <p className="text-gray-500 text-sm">Nenhum fornecedor</p>
                  <button onClick={() => router.push('/fornecedores/novo')} className="btn-neon mt-4 text-sm">Cadastrar primeiro</button>
                </div>
              )}
              {forns.map(f => (
                <div key={f.id} className="card flex items-center gap-3 hover:border-neon/20 transition-colors">
                  <div className="w-10 h-10 rounded-xl bg-neon/10 border border-neon/20 flex items-center justify-center flex-shrink-0">
                    <Truck className="w-5 h-5 text-neon" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-semibold text-sm">{f.nome}</p>
                    {f.whatsapp && <p className="text-xs text-gray-500 flex items-center gap-1"><Phone className="w-3 h-3" />{f.whatsapp}</p>}
                  </div>
                  <button onClick={() => delForn(f)} className="p-2 hover:bg-red-500/10 rounded-lg">
                    <Trash2 className="w-3.5 h-3.5 text-red-500/50" />
                  </button>
                </div>
              ))}
            </div>
          : <div className="flex flex-col gap-2">
              {pecas.length === 0 && (
                <div className="card text-center py-12">
                  <ShoppingBag className="w-10 h-10 text-gray-700 mx-auto mb-3" />
                  <p className="text-gray-500 text-sm">Nenhuma peça</p>
                  <button onClick={() => router.push('/fornecedores/nova-peca')} className="btn-neon mt-4 text-sm">Registrar primeira</button>
                </div>
              )}
              {pecas.map(p => {
                const l = (p.valorCobrado || 0) - (p.valorPago || 0)
                return (
                  <div key={p.id} className="card flex items-center gap-3 hover:border-neon/20 transition-colors">
                    <div className="w-10 h-10 rounded-xl bg-surface-light border border-surface-border flex items-center justify-center flex-shrink-0">
                      <Package className="w-5 h-5 text-gray-400" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-semibold text-sm">{p.nome}</p>
                      <p className="text-xs text-gray-500 truncate">{p.marca} · {p.modeloCompativel}</p>
                      {p.fornecedorNome && <p className="text-[10px] text-gray-600">{p.fornecedorNome}</p>}
                    </div>
                    <div className="text-right">
                      <p className={`text-sm font-bold ${l >= 0 ? 'text-neon' : 'text-red-400'}`}>{R$(l)}</p>
                      <p className="text-[10px] text-gray-500">pago: {R$(p.valorPago)}</p>
                    </div>
                    <button onClick={() => delPeca(p)} className="p-2 hover:bg-red-500/10 rounded-lg">
                      <Trash2 className="w-3.5 h-3.5 text-red-500/50" />
                    </button>
                  </div>
                )
              })}
            </div>
      }
    </div>
  )
}
