'use client'
import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { garantias as db } from '@/lib/firestore'
import toast from 'react-hot-toast'
import { differenceInDays, format } from 'date-fns'
import { ptBR } from 'date-fns/locale'
import { Shield, Plus, AlertTriangle, CheckCircle, X, Trash2, ChevronRight, Package } from 'lucide-react'

const getSt = (g) => {
  const d = differenceInDays(new Date(g.dataExpiracao), new Date())
  if (d < 0) return { l:`Vencida há ${Math.abs(d)}d`, cor:'#ef4444', bg:'rgba(239,68,68,0.1)', bd:'rgba(239,68,68,0.3)' }
  if (d <= 15) return { l:`Vence em ${d}d`, cor:'#f97316', bg:'rgba(249,115,22,0.1)', bd:'rgba(249,115,22,0.3)' }
  return { l:`${d}d restantes`, cor:'#00FF41', bg:'rgba(0,255,65,0.1)', bd:'rgba(0,255,65,0.3)' }
}

export default function GarantiasPage() {
  const router = useRouter()
  const [list, setList]     = useState([])
  const [loading, setLoad]  = useState(true)

  const load = async () => {
    setLoad(true)
    try { setList(await db.list()) } catch {}
    setLoad(false)
  }
  useEffect(() => { load() }, [])

  const del = async (g) => {
    if (!confirm('Remover garantia?')) return
    await db.delete(g.id); toast.success('Removida'); load()
  }

  const vencendo = list.filter(g => {
    const d = differenceInDays(new Date(g.dataExpiracao), new Date()); return d >= 0 && d <= 15
  })

  return (
    <div className="fu">
      <div className="flex items-center justify-between mb-5">
        <div>
          <h1 className="text-xl font-black flex items-center gap-2"><Shield className="w-5 h-5 text-neon"/>Garantias</h1>
          <p className="text-xs text-gray-500">{list.length} registradas</p>
        </div>
        <button onClick={() => router.push('/garantias/nova')} className="btn-neon flex items-center gap-2 text-sm">
          <Plus className="w-4 h-4"/>Nova
        </button>
      </div>

      {vencendo.length > 0 && (
        <div className="card border-orange-500/30 mb-4 flex items-center gap-2">
          <AlertTriangle className="w-4 h-4 text-orange-400 flex-shrink-0"/>
          <p className="text-sm font-medium text-orange-400">{vencendo.length} garantia(s) vencendo em até 15 dias</p>
        </div>
      )}

      {loading
        ? <div className="flex justify-center py-12"><div className="w-6 h-6 border-2 border-neon border-t-transparent rounded-full animate-spin"/></div>
        : list.length === 0
          ? <div className="card text-center py-12">
              <Shield className="w-10 h-10 text-gray-700 mx-auto mb-3"/>
              <p className="text-gray-500 text-sm">Nenhuma garantia registrada</p>
              <button onClick={()=>router.push('/garantias/nova')} className="btn-neon mt-4 text-sm">Registrar primeira</button>
            </div>
          : <div className="flex flex-col gap-2">
              {list.map(g => {
                const st = getSt(g)
                return (
                  <div key={g.id} className="card flex items-center gap-3 hover:border-neon/20 transition-colors">
                    <div style={{width:40,height:40,borderRadius:12,background:st.bg,border:`1px solid ${st.bd}`,display:'flex',alignItems:'center',justifyContent:'center',flexShrink:0}}>
                      <Shield size={18} color={st.cor}/>
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-semibold text-sm">{g.clienteNome}</p>
                      <p className="text-xs text-gray-400 truncate">{g.descricao}</p>
                      <div className="flex items-center gap-2 mt-0.5">
                        <span className="text-[10px] text-gray-600">OS #{g.osNumero}</span>
                        {g.pecaNome && <span className="text-[10px] text-gray-600">· {g.pecaNome}</span>}
                        {g.fornecedorNome && <span className="text-[10px] text-gray-600">· {g.fornecedorNome}</span>}
                      </div>
                    </div>
                    <div className="text-right flex-shrink-0">
                      <span style={{fontSize:11,fontWeight:700,color:st.cor}}>{st.l}</span>
                      <p className="text-[10px] text-gray-600 mt-0.5">até {g.dataExpiracao ? format(new Date(g.dataExpiracao),'dd/MM/yy',{locale:ptBR}) : '—'}</p>
                    </div>
                    <button onClick={()=>del(g)} className="p-2 hover:bg-red-500/10 rounded-lg flex-shrink-0">
                      <Trash2 className="w-3.5 h-3.5 text-red-500/50"/>
                    </button>
                  </div>
                )
              })}
            </div>
      }
    </div>
  )
}
