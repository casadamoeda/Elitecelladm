'use client'
import { useEffect, useState, useCallback } from 'react'
import { getFinanceResumo as getDashStats } from '@/lib/firestore'
import { ordens } from '@/lib/firestore'
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts'
import { Wrench, CheckCircle, Zap, DollarSign, TrendingUp, RefreshCw, Smartphone, ArrowRight } from 'lucide-react'
import Link from 'next/link'
import { format } from 'date-fns'
import { ptBR } from 'date-fns/locale'

const R$ = v => (v||0).toLocaleString('pt-BR',{style:'currency',currency:'BRL'})
const SL = {recebido:'Recebido',em_analise:'Análise',aguardando_aprovacao:'Aprov.',aguardando_peca:'Aguard.Peça',em_reparo:'Reparo',testes_finais:'Testes',pronto:'Pronto',entregue:'Entregue',cancelado:'Cancelado',sem_reparo:'Sem reparo'}
const SC = {recebido:'text-blue-400',em_analise:'text-yellow-400',aguardando_aprovacao:'text-orange-400',aguardando_peca:'text-purple-400',em_reparo:'text-cyan-400',testes_finais:'text-indigo-400',pronto:'text-neon',entregue:'text-gray-400',cancelado:'text-red-400',sem_reparo:'text-red-500'}

// Mostra primeiro as OS que exigem ação (em andamento), completando com as
// mais recentes se faltar — a lista de "Últimas OS" do dashboard deve ajudar
// no dia a dia, não misturar com entregues/canceladas antigas.
function pegarRecentes(lista, limite = 6) {
  const ativas = lista.filter(o => !['entregue','cancelado','sem_reparo'].includes(o.status))
  if (ativas.length >= limite) return ativas.slice(0, limite)
  const resto = lista.filter(o => ['entregue','cancelado','sem_reparo'].includes(o.status))
  return [...ativas, ...resto].slice(0, limite)
}

function KPI({icon:Icon, label, value, highlight}){
  return(
    <div className={`card flex flex-col gap-2 ${highlight?'border-neon/20 bg-neon/5':''}`}>
      <Icon className={`w-4 h-4 ${highlight?'text-neon':'text-gray-500'}`}/>
      <p className={`text-2xl font-black tabular-nums ${highlight?'text-neon':''}`}>{value}</p>
      <p className="text-xs text-gray-500 leading-tight">{label}</p>
    </div>
  )
}

export default function DashboardPage(){
  const [stats,  setStats]  = useState(null)
  const [recent, setRecent] = useState([])
  const [chart,  setChart]  = useState([])
  const [loading,setLoad]   = useState(true)
  const [lastUpd,setLastUpd]= useState(null)

  const load = useCallback(async () => {
    setLoad(true)
    try{
      const s = await getDashStats()
      setStats(s)
      setChart(s.ultimos7 || [])
      const lista = await ordens.list()
      setRecent(pegarRecentes(lista))
      setLastUpd(new Date())
    }catch(e){console.error(e)}
    setLoad(false)
  },[])

  useEffect(()=>{
    load()
    // Atualiza a cada 60 segundos automaticamente
    const interval = setInterval(load, 60_000)
    // Também atualiza quando a aba volta ao foco
    const onFocus = () => load()
    window.addEventListener('focus', onFocus)
    return () => { clearInterval(interval); window.removeEventListener('focus', onFocus) }
  },[load])

  // Subscrição em tempo real (Firestore listener)
  useEffect(()=>{
    const unsub = ordens.subscribe(async (lista) => {
      setRecent(pegarRecentes(lista))
      // Re-calcula stats leves sem nova query ao financeiro
      const aberto  = lista.filter(o=>!['entregue','cancelado','sem_reparo'].includes(o.status)).length
      const prontos = lista.filter(o=>o.status==='pronto').length
      const entregues=lista.filter(o=>o.status==='entregue').length
      setStats(p => p ? {...p, emAberto:aberto, prontos, entregues, totalOS:lista.length} : p)
      setLastUpd(new Date())
    })
    return () => unsub()
  },[])

  if(loading && !stats) return(
    <div className="flex justify-center py-24">
      <div className="w-8 h-8 border-2 border-neon border-t-transparent rounded-full animate-spin"/>
    </div>
  )

  const hasChart = chart.some(d=>d.v>0)

  return(
    <div className="fu">
      {/* Header */}
      <div className="flex items-center justify-between mb-5">
        <div>
          <h1 className="text-xl font-black">Dashboard <span className="text-neon">●</span></h1>
          <p className="text-xs text-gray-500">
            {format(new Date(),"EEEE, d 'de' MMMM",{locale:ptBR})}
            {lastUpd&&<span className="ml-2 text-gray-600">· atualizado {lastUpd.toLocaleTimeString('pt-BR',{hour:'2-digit',minute:'2-digit'})}</span>}
          </p>
        </div>
        <button onClick={load} disabled={loading} className="p-2 hover:bg-surface-light rounded-lg border border-surface-border">
          <RefreshCw className={`w-4 h-4 text-gray-400 ${loading?'animate-spin':''}`}/>
        </button>
      </div>

      {stats && (
        <>
          {/* KPIs */}
          <div className="grid grid-cols-3 gap-2 mb-3">
            <KPI icon={Wrench}       label="Em aberto"  value={stats.emAberto}/>
            <KPI icon={Zap}          label="Prontos"    value={stats.prontos}   highlight/>
            <KPI icon={CheckCircle}  label="Entregues"  value={stats.entregues}/>
          </div>
          <div className="grid grid-cols-3 gap-2 mb-5">
            <KPI icon={DollarSign}   label="Hoje"       value={R$(stats.faturHoje)}  highlight/>
            <KPI icon={TrendingUp}   label="Mês"        value={R$(stats.faturMes)}   highlight/>
            <KPI icon={TrendingUp}   label="Lucro/mês"  value={R$(stats.lucroMes)}   highlight/>
          </div>

          {/* Gráfico */}
          <div className="card mb-4">
            <p className="text-sm font-bold mb-1">Faturamento — últimos 7 dias</p>
            <p className="text-xs text-gray-600 mb-3">Soma das OS criadas por dia</p>
            {!hasChart
              ?<p className="text-xs text-gray-700 text-center py-8">Nenhuma OS registrada nos últimos 7 dias</p>
              :<ResponsiveContainer width="100%" height={140}>
                <AreaChart data={chart}>
                  <defs>
                    <linearGradient id="g" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%"  stopColor="#00FF41" stopOpacity={0.2}/>
                      <stop offset="95%" stopColor="#00FF41" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <XAxis dataKey="d" tick={{fill:'#555',fontSize:11}} axisLine={false} tickLine={false}/>
                  <YAxis hide/>
                  <Tooltip contentStyle={{background:'#161616',border:'1px solid #222',borderRadius:8,color:'#fff',fontSize:12}}
                    formatter={v=>[R$(v),'Faturamento']}/>
                  <Area type="monotone" dataKey="v" stroke="#00FF41" strokeWidth={2} fill="url(#g)" dot={{fill:'#00FF41',r:3}}/>
                </AreaChart>
              </ResponsiveContainer>
            }
          </div>
        </>
      )}

      {/* Últimas OS */}
      <div className="card">
        <div className="flex items-center justify-between mb-3">
          <p className="text-sm font-bold">OS que precisam de atenção</p>
          <Link href="/ordens" className="text-xs text-neon flex items-center gap-1">Ver todas <ArrowRight className="w-3 h-3"/></Link>
        </div>
        {recent.length===0
          ?<p className="text-xs text-gray-600 py-4 text-center">Nenhuma OS ainda</p>
          :recent.map(o=>(
            <div key={o.id} className="flex items-center gap-3 py-2.5 border-b border-surface-border last:border-0">
              <Smartphone className="w-4 h-4 text-neon flex-shrink-0"/>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium truncate">{o.clienteNome}</p>
                <p className="text-xs text-gray-500 truncate">{o.marca} {o.modelo}</p>
              </div>
              <div className="text-right flex-shrink-0">
                <p className="text-xs text-neon font-bold">{R$(o.valorTotal ?? o.valorServico ?? 0)}</p>
                <p className={`text-[10px] ${SC[o.status]||'text-gray-500'}`}>{SL[o.status]||o.status}</p>
              </div>
            </div>
          ))
        }
      </div>
    </div>
  )
}
