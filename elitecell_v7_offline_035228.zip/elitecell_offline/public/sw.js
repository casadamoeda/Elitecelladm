// ═══════════════════════════════════════════════════════════════
//  ELITECELL — Service Worker v3.0 (Offline-First)
// ═══════════════════════════════════════════════════════════════

const CACHE_NAME   = 'elitecell-v3'
const OFFLINE_PAGE = '/offline.html'

// Recursos críticos cacheados na instalação
const PRECACHE_URLS = [
  '/',
  '/dashboard/',
  '/clientes/',
  '/ordens/',
  '/financeiro/',
  '/fornecedores/',
  '/garantias/',
  '/entregas/',
  '/relatorios/',
  '/sincronizacao/',
  '/offline.html',
  '/manifest.json',
  '/icon-192.png',
  '/icon-512.png',
  '/logo.png',
  '/favicon.ico',
  '/favicon-32x32.png',
  '/apple-touch-icon.png',
]

// ── Instalação: pré-cacheia recursos críticos ──────────────────
self.addEventListener('install', event => {
  self.skipWaiting()
  event.waitUntil(
    caches.open(CACHE_NAME).then(cache =>
      Promise.allSettled(
        PRECACHE_URLS.map(url =>
          cache.add(url).catch(e => console.warn('[SW] Pré-cache falhou:', url, e.message))
        )
      )
    )
  )
})

// ── Ativação: limpa caches antigos ────────────────────────────
self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys()
      .then(keys => Promise.all(
        keys.filter(k => k !== CACHE_NAME).map(k => caches.delete(k))
      ))
      .then(() => self.clients.claim())
  )
})

// ── Fetch: estratégias por tipo de recurso ────────────────────
self.addEventListener('fetch', event => {
  const { request } = event
  const url = new URL(request.url)

  // Ignora requisições externas (Firebase, APIs, Google)
  if (url.origin !== self.location.origin) return

  // Ignora métodos não-GET
  if (request.method !== 'GET') return

  // Ignora requisições de extensões do Chrome
  if (url.protocol === 'chrome-extension:') return

  const isNavigation = request.mode === 'navigate'
  const isStaticAsset = /\.(png|jpg|jpeg|gif|svg|ico|woff2?|css|js)$/i.test(url.pathname)
  const isNextJS = url.pathname.startsWith('/_next/')

  if (isNextJS || isStaticAsset) {
    // Cache First: assets estáticos (JS, CSS, imagens)
    event.respondWith(
      caches.match(request).then(cached => {
        if (cached) return cached
        return fetch(request).then(response => {
          if (response.ok) {
            const clone = response.clone()
            caches.open(CACHE_NAME).then(c => c.put(request, clone))
          }
          return response
        }).catch(() => cached || new Response('', { status: 408 }))
      })
    )

  } else if (isNavigation) {
    // Stale-While-Revalidate: páginas HTML
    // Responde do cache imediatamente, atualiza em background
    event.respondWith(
      caches.match(request).then(cached => {
        const networkFetch = fetch(request).then(response => {
          if (response.ok) {
            const clone = response.clone()
            caches.open(CACHE_NAME).then(c => c.put(request, clone))
          }
          return response
        }).catch(() => null)

        // Se tem cache, retorna imediatamente (não espera a rede)
        if (cached) {
          networkFetch.catch(() => {}) // atualiza em background
          return cached
        }

        // Sem cache: espera a rede ou retorna offline.html
        return networkFetch.then(r => r || caches.match(OFFLINE_PAGE))
                           .catch(() => caches.match(OFFLINE_PAGE))
      })
    )

  } else {
    // Network First com fallback para cache: outros recursos
    event.respondWith(
      fetch(request)
        .then(response => {
          if (response.ok) {
            const clone = response.clone()
            caches.open(CACHE_NAME).then(c => c.put(request, clone))
          }
          return response
        })
        .catch(() => caches.match(request) || caches.match(OFFLINE_PAGE))
    )
  }
})

// ── Mensagens do cliente ──────────────────────────────────────
self.addEventListener('message', event => {
  if (event.data?.type === 'SKIP_WAITING') {
    self.skipWaiting()
  }

  // Força atualização do cache de uma URL específica
  if (event.data?.type === 'CACHE_URL') {
    const url = event.data.url
    caches.open(CACHE_NAME).then(cache =>
      fetch(url).then(r => cache.put(url, r)).catch(() => {})
    )
  }
})
