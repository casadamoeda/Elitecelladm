'use client'
import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { fornecedores as fornDb } from '@/lib/firestore'
import toast from 'react-hot-toast'
import { ArrowLeft, Truck } from 'lucide-react'

export default function NovoFornecedorPage() {
  const router = useRouter()
  const [form, setForm] = useState({ nome: '', whatsapp: '', endereco: '', observacoes: '' })
  const [saving, setSaving] = useState(false)

  const set = (f, v) => setForm(p => ({ ...p, [f]: v }))

  const save = async () => {
    if (!form.nome.trim()) return toast.error('Nome obrigatório')
    setSaving(true)
    try {
      await fornDb.add(form)
      toast.success('Fornecedor cadastrado!')
      router.back()
    } catch { toast.error('Erro ao salvar') } finally { setSaving(false) }
  }

  return (
    <div className="fu">
      {/* Header */}
      <div className="flex items-center gap-3 mb-6">
        <button onClick={() => router.back()} className="p-2 hover:bg-surface-light rounded-lg transition-colors flex-shrink-0">
          <ArrowLeft className="w-5 h-5 text-gray-400" />
        </button>
        <div>
          <h1 className="text-xl font-black flex items-center gap-2">
            <Truck className="w-5 h-5 text-neon" />Novo Fornecedor
          </h1>
          <p className="text-xs text-gray-500">Dados do fornecedor de peças</p>
        </div>
      </div>

      {/* Formulário */}
      <div className="flex flex-col gap-4 mb-6">
        <div>
          <label className="lbl">Nome *</label>
          <input type="text" value={form.nome} onChange={e => set('nome', e.target.value)} className="input-dark" placeholder="Nome do fornecedor" autoFocus />
        </div>
        <div>
          <label className="lbl">WhatsApp</label>
          <input type="tel" value={form.whatsapp} onChange={e => set('whatsapp', e.target.value)} className="input-dark" placeholder="(99) 99999-9999" />
        </div>
        <div>
          <label className="lbl">Endereço</label>
          <input type="text" value={form.endereco} onChange={e => set('endereco', e.target.value)} className="input-dark" placeholder="Endereço do fornecedor" />
        </div>
        <div>
          <label className="lbl">Observações</label>
          <textarea value={form.observacoes} onChange={e => set('observacoes', e.target.value)} rows={3} className="input-dark resize-none" placeholder="Informações adicionais..." />
        </div>
      </div>

      {/* Ações */}
      <div className="flex flex-col gap-2">
        <button onClick={save} disabled={saving} className="btn-neon w-full py-3 text-base">
          {saving ? 'Salvando...' : 'Salvar Fornecedor'}
        </button>
        <button onClick={() => router.back()} className="btn-ghost w-full py-3">
          Cancelar
        </button>
      </div>
    </div>
  )
}
