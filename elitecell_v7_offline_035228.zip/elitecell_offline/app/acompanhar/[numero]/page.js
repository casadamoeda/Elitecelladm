// ─── SERVIDOR — sem 'use client' ────────────────────────────────
// generateStaticParams e 'use client' NÃO podem coexistir.
// Solução: page.js é server component, UI fica em AcompanharClient.js
// O Netlify redireciona /acompanhar/* → /acompanhar/_/
// O client lê o número real via window.location.pathname

import AcompanharClient from './AcompanharClient'

export async function generateStaticParams() {
  // Gera apenas a rota genérica "_" no build.
  // O redirect do Netlify envia qualquer /acompanhar/XXXXX → /acompanhar/_/
  return [{ numero: '_' }]
}

export default function AcompanharPage() {
  return <AcompanharClient />
}
