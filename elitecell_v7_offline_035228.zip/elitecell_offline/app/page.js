'use client'
import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { useAuth } from '@/lib/contexts/AuthContext'
import toast from 'react-hot-toast'
import { Smartphone, Mail, Lock, Zap } from 'lucide-react'

export default function LoginPage() {
  const [email, setEmail]     = useState('')
  const [senha, setSenha]     = useState('')
  const [loading, setLoading] = useState(false)
  const { login } = useAuth()
  const router    = useRouter()

  const handle = async (e) => {
    e.preventDefault()
    if (!email || !senha) return toast.error('Preencha e-mail e senha')
    setLoading(true)
    try { await login(email, senha); router.push('/dashboard') }
    catch { toast.error('E-mail ou senha incorretos') }
    finally { setLoading(false) }
  }

  return (
    <div className="min-h-screen bg-dark flex items-center justify-center p-4 relative overflow-hidden">
      <div className="absolute inset-0 pointer-events-none" style={{backgroundImage:'linear-gradient(rgba(0,255,65,.03) 1px,transparent 1px),linear-gradient(90deg,rgba(0,255,65,.03) 1px,transparent 1px)',backgroundSize:'40px 40px'}} />
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
        <div className="w-72 h-72 rounded-full bg-neon/5 blur-[100px]" />
      </div>

      <div className="relative w-full max-w-sm fu">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-20 h-20 rounded-2xl bg-neon/10 border-2 border-neon/30 mb-4 shadow-neon">
            <Smartphone className="w-10 h-10 text-neon" />
          </div>
          <h1 className="text-3xl font-black tracking-tight">ELITE<span className="text-neon">CELL</span></h1>
          <p className="text-xs text-gray-500 mt-1 tracking-widest uppercase">Assistência Técnica & Acessórios</p>
        </div>

        <div className="card">
          <div className="flex items-center gap-2 mb-5">
            <Zap className="w-4 h-4 text-neon" />
            <span className="text-sm text-gray-400 font-medium">Acesso ao sistema</span>
          </div>
          <form onSubmit={handle} className="flex flex-col gap-4">
            <div>
              <label className="lbl">E-mail</label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
                <input type="email" value={email} onChange={e=>setEmail(e.target.value)} placeholder="seu@email.com" className="input-dark pl-10" autoComplete="email" />
              </div>
            </div>
            <div>
              <label className="lbl">Senha</label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
                <input type="password" value={senha} onChange={e=>setSenha(e.target.value)} placeholder="••••••••" className="input-dark pl-10" autoComplete="current-password" />
              </div>
            </div>
            <button type="submit" disabled={loading} className="btn-neon w-full mt-1 disabled:opacity-50">
              {loading ? 'Entrando...' : 'Entrar'}
            </button>
          </form>
        </div>
        <p className="text-center text-xs text-gray-700 mt-6">ELITECELL Sistema v2.0</p>
      </div>
    </div>
  )
}
