'use client'
import { useEffect, useState, Suspense } from 'react'
import { useRouter, useSearchParams } from 'next/navigation'
import { clientes as db, ordens as ordensDb } from '@/lib/firestore'
import toast from 'react-hot-toast'
import {
  ArrowLeft, User, Phone, MapPin, ClipboardList,
  Pencil, Trash2, Plus, ChevronRight, MessageCircle, AlertCircle
} from 'lucide-react'

const R$ = v => (v || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })
const SL = {
  recebido:'Recebido', em_analise:'Em análise', aguardando_aprovacao:'Ag. aprovação',
  aguardando_peca:'Ag. peça', em_reparo:'Em reparo', testes_finais:'Testes',
  pronto:'Pronto ✓', entregue:'Entregue', cancelado:'Cancelado', sem_reparo:'Sem reparo'
}
const SC = {
  recebido:'#3b82f6', em_analise:'#eab308', aguardando_aprovacao:'#f97316',
  aguardando_peca:'#a855f7', em_reparo:'#06b6d4', testes_finais:'#6366f1',
  pronto:'#00FF41', entregue:'#6b7280', cancelado:'#ef4444', sem_reparo:'#dc2626'
}

// Busca ordens do cliente — offline-first
async function fetchOrdensDoCliente(clienteId) {
  try {
    const { ordens } = await import('@/lib/firestore')
    return await ordens.byCliente(clienteId)
  } catch { return [] }
}

function DetalheClienteInner() {
  const router = useRouter()
  const params = useSearchParams()
  const id = params.get('id')
  const [cliente, setCliente] = useState(null)
  const [ordens, setOrdens] = useState([])
  const [loading, setLoading] = useState(true)
  const [erro, setErro] = useState(false)

  useEffect(() => {
    if (!id) { router.replace('/clientes'); return }
    setLoading(true)
    setErro(false)
    Promise.all([
      db.get(id).catch(() => null),
      fetchOrdensDoCliente(id)
    ]).then(([c, o]) => {
      setCliente(c)
      setOrdens(o)
    }).catch(() => {
      setErro(true)
    }).finally(() => {
      setLoading(false)
    })
  }, [id])

  const totalGasto = ordens.reduce((s,o)=>s+(o.valorTotal||o.valorServico||0)+(o.valorPeca||0),0)
  const R$ = v=>(v||0).toLocaleString('pt-BR',{style:'currency',currency:'BRL'})

  const remover = async () => {
    if (!confirm(`Remover ${cliente.nome}? Esta ação não pode ser desfeita.`)) return
    try {
      await db.delete(id)
      toast.success('Cliente removido')
      router.push('/clientes')
    } catch {
      toast.error('Erro ao remover')
    }
  }

  if (loading) return (
    <div className="flex flex-col items-center justify-center py-20 gap-3">
      <div className="w-7 h-7 border-2 border-neon border-t-transparent rounded-full animate-spin" />
      <p className="text-xs text-gray-500">Carregando...</p>
    </div>
  )

  if (erro || !cliente) return (
    <div className="flex flex-col items-center justify-center py-20 gap-4">
      <AlertCircle className="w-10 h-10 text-red-500" />
      <p className="text-gray-400 text-sm">Erro ao carregar cliente</p>
      <button onClick={() => router.back()} className="btn-ghost text-sm">Voltar</button>
    </div>
  )

  return (
    <div className="fu">
      {/* Header */}
      <div className="flex items-center gap-3 mb-6">
        <button onClick={() => router.back()} className="p-2 hover:bg-surface-light rounded-lg transition-colors flex-shrink-0">
          <ArrowLeft className="w-5 h-5 text-gray-400" />
        </button>
        <div className="flex-1 min-w-0">
          <h1 className="text-xl font-black truncate">{cliente.nome}</h1>
          <p className="text-xs text-gray-500">Detalhes do cliente</p>
        </div>
        <div className="w-11 h-11 rounded-xl bg-neon/10 border border-neon/20 flex items-center justify-center flex-shrink-0">
          <User className="w-5 h-5 text-neon" />
        </div>
      </div>

      {/* Contato */}
      <div className="card mb-4">
        <p className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-3">Contato</p>
        <div className="flex flex-col gap-3">
          {cliente.telefone && (
            <a href={`tel:${cliente.telefone}`} className="flex items-center gap-3 text-sm">
              <Phone className="w-4 h-4 text-neon flex-shrink-0" /><span>{cliente.telefone}</span>
            </a>
          )}
          {cliente.whatsapp && (
            <a href={`https://wa.me/55${cliente.whatsapp.replace(/\D/g,'')}`}
              target="_blank" rel="noreferrer"
              className="flex items-center gap-3 text-sm text-neon hover:underline">
              <MessageCircle className="w-4 h-4 flex-shrink-0" />WhatsApp: {cliente.whatsapp}
            </a>
          )}
          {cliente.cpf && (
            <div className="flex items-center gap-3 text-sm">
              <User className="w-4 h-4 text-gray-500 flex-shrink-0" />
              <span className="text-gray-400">CPF: {cliente.cpf}</span>
            </div>
          )}
          {(cliente.cidade || cliente.bairro || cliente.endereco) && (
            <div className="flex items-start gap-3 text-sm">
              <MapPin className="w-4 h-4 text-neon flex-shrink-0 mt-0.5" />
              <span className="text-gray-300">{[cliente.endereco, cliente.bairro, cliente.cidade].filter(Boolean).join(', ')}</span>
            </div>
          )}
          {cliente.observacoes && (
            <div className="mt-1 p-3 bg-surface-light rounded-xl">
              <p className="text-xs text-gray-500 mb-1">Observações</p>
              <p className="text-sm text-gray-300">{cliente.observacoes}</p>
            </div>
          )}
        </div>
      </div>

      {/* Stats */}
      {ordens.length > 0 && (
        <div className="grid grid-cols-2 gap-3 mb-4">
          <div className="card text-center">
            <p className="text-2xl font-black text-neon">{ordens.length}</p>
            <p className="text-xs text-gray-500">Serviços realizados</p>
          </div>
          <div className="card text-center">
            <p className="text-lg font-black text-neon">{R$(totalGasto)}</p>
            <p className="text-xs text-gray-500">Total gasto</p>
          </div>
        </div>
      )}

      {/* Ações */}
      <div className="flex flex-col gap-2 mb-6">
        <button onClick={() => router.push(`/ordens/nova?clienteId=${id}&clienteNome=${encodeURIComponent(cliente.nome)}`)}
          className="btn-neon w-full py-3 flex items-center justify-center gap-2">
          <ClipboardList className="w-4 h-4" />Nova OS para este cliente
        </button>
        <button onClick={() => router.push(`/clientes/editar?id=${id}`)}
          className="btn-ghost w-full py-3 flex items-center justify-center gap-2">
          <Pencil className="w-4 h-4" />Editar cadastro
        </button>
        <button onClick={remover}
          className="btn-ghost w-full py-3 text-red-400 flex items-center justify-center gap-2">
          <Trash2 className="w-4 h-4" />Remover cliente
        </button>
      </div>

      {/* Ordens */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <p className="text-sm font-bold flex items-center gap-2">
            <ClipboardList className="w-4 h-4 text-neon" />Ordens de Serviço ({ordens.length})
          </p>
          <button onClick={() => router.push(`/ordens/nova?clienteId=${id}&clienteNome=${encodeURIComponent(cliente.nome)}`)}
            className="flex items-center gap-1 text-xs text-neon hover:underline">
            <Plus className="w-3 h-3" />Nova
          </button>
        </div>
        {ordens.length === 0
          ? <div className="card text-center py-8">
              <p className="text-gray-600 text-sm">Nenhuma ordem de serviço ainda</p>
            </div>
          : <div className="flex flex-col gap-2">
              {ordens.map(o => (
                <button key={o.id} onClick={() => router.push(`/ordens/detalhe?id=${o.id}`)}
                  className="card text-left flex items-center gap-3 hover:border-neon/20 transition-colors w-full">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-xs font-mono text-neon">#{o.numero}</span>
                      <span className="text-xs px-2 py-0.5 rounded-full border font-medium"
                        style={{color:SC[o.status], borderColor:SC[o.status]+'40', background:SC[o.status]+'10'}}>
                        {SL[o.status]}
                      </span>
                    </div>
                    <p className="text-sm font-medium truncate">{o.marca} {o.modelo}</p>
                  </div>
                  <div className="flex items-center gap-2 flex-shrink-0">
                    <p className="text-sm font-bold text-neon">{R$((o.valorServico||0)+(o.valorPeca||0))}</p>
                    <ChevronRight className="w-4 h-4 text-gray-600" />
                  </div>
                </button>
              ))}
            </div>
        }
      </div>
    </div>
  )
}

export default function DetalheClientePage() {
  return (
    <Suspense fallback={
      <div className="flex flex-col items-center justify-center py-20 gap-3">
        <div className="w-7 h-7 border-2 border-neon border-t-transparent rounded-full animate-spin" />
        <p className="text-xs text-gray-500">Carregando...</p>
      </div>
    }>
      <DetalheClienteInner />
    </Suspense>
  )
}
