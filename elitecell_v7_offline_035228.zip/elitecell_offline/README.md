# ⚡ ELITECELL — Sistema de Gestão

> **100% pelo celular. Sobe no GitHub → Netlify builda e publica sozinho.**  
> Firebase já configurado. Só seguir os passos abaixo.

---

## ✅ O que já está pronto nesse ZIP

- 🔥 Firebase configurado (projeto `elitecell-52652`)
- 🎨 Tema verde neon + preto
- 📱 Interface responsiva para celular
- 🗂️ 8 módulos completos

---

## 🚀 PASSO A PASSO — Só pelo celular

### PASSO 1 — Ativar o Firebase

Acesse **console.firebase.google.com** e faça isso no projeto `elitecell-52652`:

**Ativar o login por e-mail:**
1. Menu lateral → **Build → Authentication**
2. Clique em **"Começar"**
3. Clique em **"E-mail/senha"**
4. Ative a primeira opção → **Salvar**

**Criar seu usuário de acesso:**
5. Clique na aba **"Usuários"**
6. Clique em **"Adicionar usuário"**
7. Digite seu e-mail e uma senha
8. Clique em **"Adicionar usuário"**
9. ✅ Guarde esse e-mail e senha — é o que você usará para entrar no sistema

**Criar o banco de dados:**
10. Menu lateral → **Build → Firestore Database**
11. Clique em **"Criar banco de dados"**
12. Escolha **"Iniciar no modo de produção"** → Próximo
13. Região: **southamerica-east1 (São Paulo)** → **Ativar**

**Regras de segurança:**
14. Dentro do Firestore, clique na aba **"Regras"**
15. Apague o que está lá e cole isso:
```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /{document=**} {
      allow read, write: if request.auth != null;
    }
  }
}
```
16. Clique em **"Publicar"**

---

### PASSO 2 — Subir no GitHub

1. Acesse **github.com** e faça login (ou crie conta gratuita)
2. Clique no **+** → **"New repository"**
3. Nome: `elitecell` → deixe **Public** → **"Create repository"**
4. Na página do repositório, clique em **"uploading an existing file"**
5. Extraia o ZIP no celular e selecione **todos os arquivos**
6. Clique em **"Commit changes"**

> ⚠️ Se não aparecer a pasta `app`, ative "Mostrar arquivos ocultos" no gerenciador de arquivos do celular. Ou use o app **GitHub Mobile** da Play Store que aceita qualquer pasta.

---

### PASSO 3 — Publicar no Netlify

1. Acesse **app.netlify.com** e faça login com sua conta Google
2. Clique em **"Add new site" → "Import an existing project"**
3. Clique em **"GitHub"** e autorize o acesso
4. Selecione o repositório **`elitecell`**
5. As configurações já estão automáticas:
   - Build command: `npm run build`
   - Publish directory: `out`
6. Clique em **"Deploy site"**
7. Aguarde ~3 minutos ⏳

Pronto! Seu sistema estará em:
```
https://nome-aleatorio.netlify.app
```

**Para ter um nome personalizado** (opcional e gratuito):
- No painel do Netlify → **"Site settings" → "Domain management"**
- Clique em **"Options" → "Edit site name"**
- Coloque: `elitecell` → Salvar
- URL vira: `https://elitecell.netlify.app`

---

## 🔄 Como atualizar no futuro

Sempre que você editar qualquer arquivo no GitHub pelo celular e clicar em **"Commit changes"**, o Netlify detecta automaticamente e republica. Leva ~3 minutos.

---

## 📋 Módulos do sistema

| Módulo | Função |
|---|---|
| Dashboard | KPIs, gráfico, ordens recentes |
| Clientes | Cadastro, histórico de OS, WhatsApp direto |
| Ordens de Serviço | CRUD completo, 10 status, troca rápida |
| Peças & Fornecedores | Registro com cálculo de lucro |
| Financeiro | Entradas/saídas, saldo, histórico |
| Garantias | Controle com alerta de vencimento |
| Coletas & Entregas | Agenda com status de rota |
| Relatórios | Gráficos, faturamento, top clientes |

---

## ❓ Problemas comuns

**Deploy falhou no Netlify**
→ Vá em "Deploys" no Netlify e clique no deploy com erro para ver o log

**Tela branca ao abrir**
→ Aguarde 2-3 min e atualize. O Netlify pode demorar para propagar.

**"E-mail ou senha incorretos" no login**
→ Confirme o usuário criado no Firebase Authentication

**Não consigo subir todos os arquivos**
→ Use o app **GitHub Mobile** (Play Store) — mais fácil para uploads pelo celular

---

*ELITECELL Sistema v2.0 — Next.js + Firebase + Netlify*
