'use client'
import { useState, useEffect, Suspense } from 'react'
import { useRouter, useSearchParams } from 'next/navigation'
import { clientes as db } from '@/lib/firestore'
import toast from 'react-hot-toast'
import { ArrowLeft, Users } from 'lucide-react'

const EMPTY = { nome:'', telefone:'', whatsapp:'', cpf:'', endereco:'', bairro:'', cidade:'', observacoes:'' }

function NovoClienteInner() {
  const router  = useRouter()
  const params  = useSearchParams()
  const [form, setForm] = useState(EMPTY)
  const [saving, setSaving] = useState(false)

  useEffect(() => {
    const nome    = params.get('nome') || ''
    const retorno = params.get('retorno') || ''
    if (nome) setForm(p => ({...p, nome}))
  }, [])

  const set = (f,v) => setForm(p=>({...p,[f]:v}))

  const save = async () => {
    if (!form.nome.trim()) return toast.error('Nome obrigatório')
    setSaving(true)
    try {
      const ref = await db.add(form)
      toast.success('Cliente cadastrado!')
      const retorno = params.get('retorno')
      if (retorno) {
        // Voltar para a OS com o cliente já preenchido
        router.push(`${retorno}?clienteId=${ref.id}&clienteNome=${encodeURIComponent(form.nome)}`)
      } else {
        router.back()
      }
    } catch { toast.error('Erro ao salvar') } finally { setSaving(false) }
  }

  return (
    <div className="fu">
      <div className="flex items-center gap-3 mb-6">
        <button onClick={() => router.back()} className="p-2 hover:bg-surface-light rounded-lg transition-colors flex-shrink-0">
          <ArrowLeft className="w-5 h-5 text-gray-400"/>
        </button>
        <div>
          <h1 className="text-xl font-black flex items-center gap-2"><Users className="w-5 h-5 text-neon"/>Novo Cliente</h1>
          <p className="text-xs text-gray-500">Preencha os dados do cliente</p>
        </div>
      </div>

      <div className="flex flex-col gap-4 mb-6">
        <div>
          <label className="lbl">Nome completo *</label>
          <input type="text" value={form.nome} onChange={e=>set('nome',e.target.value)} className="input-dark" placeholder="Nome completo" autoFocus/>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div><label className="lbl">Telefone</label><input type="tel" value={form.telefone} onChange={e=>set('telefone',e.target.value)} className="input-dark" placeholder="(91) 99999-0000"/></div>
          <div><label className="lbl">WhatsApp</label><input type="tel" value={form.whatsapp} onChange={e=>set('whatsapp',e.target.value)} className="input-dark" placeholder="(91) 99999-0000"/></div>
          <div><label className="lbl">CPF</label><input type="text" value={form.cpf} onChange={e=>set('cpf',e.target.value)} className="input-dark" placeholder="000.000.000-00"/></div>
          <div><label className="lbl">Cidade</label><input type="text" value={form.cidade} onChange={e=>set('cidade',e.target.value)} className="input-dark"/></div>
          <div><label className="lbl">Bairro</label><input type="text" value={form.bairro} onChange={e=>set('bairro',e.target.value)} className="input-dark"/></div>
        </div>
        <div><label className="lbl">Endereço</label><input type="text" value={form.endereco} onChange={e=>set('endereco',e.target.value)} className="input-dark"/></div>
        <div><label className="lbl">Observações</label><textarea value={form.observacoes} onChange={e=>set('observacoes',e.target.value)} rows={2} className="input-dark resize-none"/></div>
      </div>

      <div className="flex flex-col gap-2">
        <button onClick={save} disabled={saving} className="btn-neon w-full py-3 text-base">
          {saving?'Salvando...':'Cadastrar Cliente'}
        </button>
        <button onClick={() => router.back()} className="btn-ghost w-full py-3">Cancelar</button>
      </div>
    </div>
  )
}

export default function NovoClientePage() {
  return (
    <Suspense fallback={<div className="flex justify-center py-20"><div className="w-6 h-6 border-2 border-neon border-t-transparent rounded-full animate-spin"/></div>}>
      <NovoClienteInner/>
    </Suspense>
  )
}
