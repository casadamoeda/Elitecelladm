/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ['./app/**/*.{js,jsx}', './components/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        neon: { DEFAULT: '#00FF41' },
        dark: { DEFAULT: '#0A0A0A' },
        surface: { DEFAULT: '#111111', card: '#161616', light: '#1A1A1A', border: '#222222', hover: '#1E1E1E' },
      },
      boxShadow: { neon: '0 0 12px rgba(0,255,65,0.3)' },
    },
  },
  plugins: [],
}
