'use client'
import { useEffect, useState, Suspense } from 'react'
import { useRouter, useSearchParams } from 'next/navigation'
import { clientes as cliDb, ordens as ordensDb } from '@/lib/firestore'
import toast from 'react-hot-toast'
import { ArrowLeft, ClipboardList, Search, Lock } from 'lucide-react'

const MARCAS_MODELOS = {
  'Samsung': ['Galaxy A05','Galaxy A05s','Galaxy A15','Galaxy A15 5G','Galaxy A25','Galaxy A35','Galaxy A55','Galaxy A14','Galaxy A34','Galaxy A54','Galaxy M14','Galaxy M15','Galaxy M35','Galaxy S21','Galaxy S22','Galaxy S23','Galaxy S24','Galaxy S24 Ultra','Galaxy Z Flip 5','Outro Samsung'],
  'Apple': ['iPhone 11','iPhone 11 Pro','iPhone 12','iPhone 12 Pro','iPhone 12 Pro Max','iPhone 13','iPhone 13 Pro','iPhone 13 Pro Max','iPhone 14','iPhone 14 Pro','iPhone 14 Pro Max','iPhone 15','iPhone 15 Pro','iPhone 15 Pro Max','iPhone SE (2020)','iPhone SE (2022)','Outro iPhone'],
  'Motorola': ['Moto G04','Moto G04s','Moto G14','Moto G24','Moto G34','Moto G54','Moto G84','Moto G100','Edge 30','Edge 40','Edge 40 Neo','Edge 50','Moto E22','Moto E32','Outro Motorola'],
  'Xiaomi': ['Redmi 12','Redmi 12C','Redmi 13C','Redmi Note 12','Redmi Note 13','Redmi Note 13 Pro','Redmi A2','Redmi A3','Poco X5','Poco X6','Poco X6 Pro','Poco M5','Poco M6','Outro Xiaomi'],
  'Realme': ['C30','C33','C51','C53','C55','C67','9i','10','11','11 Pro','Narzo 50','Narzo 60','Outro Realme'],
  'Infinix': ['Hot 20','Hot 30','Hot 30i','Hot 40','Hot 40i','Note 30','Note 40','Smart 7','Smart 8','Smart 8 Plus','Outro Infinix'],
  'Tecno': ['Spark 10','Spark 10 Pro','Spark 20','Pop 7','Pop 8','Camon 20','Camon 30','Outro Tecno'],
  'LG': ['K22','K52','K62','Velvet','Wing','Q60','Outro LG'],
  'Outro': [],
}
const MARCAS = Object.keys(MARCAS_MODELOS)

function MarcaModeloSelector({ marca, modelo, onMarca, onModelo }) {
  const [modeloManual, setModeloManual] = useState(false)
  const modelos = marca && MARCAS_MODELOS[marca] ? MARCAS_MODELOS[marca] : []

  useEffect(() => {
    if (modelo && modelos.length > 0 && !modelos.includes(modelo)) setModeloManual(true)
  }, [marca])

  const handleMarca = (m) => { onMarca(m); onModelo(''); setModeloManual(false) }
  const handleModelo = (m) => {
    if (m.startsWith('Outro')) { setModeloManual(true); onModelo('') }
    else { setModeloManual(false); onModelo(m) }
  }

  return (
    <div className="flex flex-col gap-3">
      <div>
        <label className="lbl">Marca *</label>
        <div style={{display:'grid',gridTemplateColumns:'repeat(3,1fr)',gap:6}}>
          {MARCAS.map(m => (
            <button key={m} type="button" onClick={() => handleMarca(m)}
              style={{padding:'8px 4px',borderRadius:9,fontSize:11,fontWeight:700,border:'none',cursor:'pointer',transition:'all .15s',
                background:marca===m?'rgba(0,255,65,0.12)':'rgba(255,255,255,0.04)',
                color:marca===m?'#00FF41':'#666',
                boxShadow:marca===m?'inset 0 0 0 1.5px rgba(0,255,65,0.4)':'inset 0 0 0 1px rgba(255,255,255,0.07)'}}>
              {m}
            </button>
          ))}
        </div>
      </div>

      {marca && marca !== 'Outro' && modelos.length > 0 && !modeloManual && (
        <div>
          <label className="lbl">Modelo *</label>
          <select value={modelo} onChange={e => handleModelo(e.target.value)} className="input-dark">
            <option value="">Selecione o modelo...</option>
            {modelos.map(m => <option key={m} value={m}>{m}</option>)}
          </select>
        </div>
      )}

      {(marca === 'Outro' || modeloManual || (marca && modelos.length === 0)) && (
        <div>
          <label className="lbl">Modelo * <span style={{fontSize:10,color:'#555',fontWeight:400}}>(digitação manual)</span></label>
          <input type="text" value={modelo} onChange={e => onModelo(e.target.value)} className="input-dark" placeholder="Ex: Galaxy A73..."/>
          {modeloManual && <button type="button" onClick={()=>{setModeloManual(false);onModelo('')}} style={{fontSize:11,color:'#555',background:'none',border:'none',cursor:'pointer',marginTop:4}}>← Ver lista</button>}
        </div>
      )}
    </div>
  )
}

const R$ = v => (v||0).toLocaleString('pt-BR',{style:'currency',currency:'BRL'})

function EditarOSInner() {
  const router = useRouter()
  const params = useSearchParams()
  const id = params.get('id')
  const [form, setForm] = useState(null)
  const [clis, setClis] = useState([])
  const [saving, setSaving] = useState(false)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (!id) { router.replace('/ordens'); return }
    Promise.all([ordensDb.get(id), cliDb.list()])
      .then(([ordem, c]) => {
        if (ordem) {
          setForm({
            clienteId: ordem.clienteId||'', clienteNome: ordem.clienteNome||'',
            marca: ordem.marca||'', modelo: ordem.modelo||'',
            imei: ordem.imei||'', cor: ordem.cor||'',
            defeito: ordem.defeito||'', senha: ordem.senha||'',
            observacoes: ordem.observacoes||'',
            valorTotal: ordem.valorTotal || ordem.valorServico || '',
            status: ordem.status||'recebido', dataPrevista: ordem.dataPrevista||'',
          })
        }
        setClis(c); setLoading(false)
      }).catch(() => setLoading(false))
  }, [id])

  const set = (f,v) => setForm(p=>({...p,[f]:v}))

  const save = async () => {
    if (!form.clienteId) return toast.error('Selecione um cliente')
    if (!form.modelo)    return toast.error('Informe o modelo')
    setSaving(true)
    try {
      const valorTotal = parseFloat(form.valorTotal)||0
      await ordensDb.update(id, {
        ...form,
        valorTotal,
        valorServico: valorTotal,
        valorPeca: 0,
      })
      toast.success('OS atualizada!')
      router.back()
    } catch { toast.error('Erro ao salvar') } finally { setSaving(false) }
  }

  if (loading) return <div className="flex justify-center py-20"><div className="w-6 h-6 border-2 border-neon border-t-transparent rounded-full animate-spin"/></div>
  if (!form)   return <div className="text-center py-20 text-gray-500">OS não encontrada</div>

  return (
    <div className="fu">
      <div className="flex items-center gap-3 mb-6">
        <button onClick={()=>router.back()} className="p-2 hover:bg-surface-light rounded-lg transition-colors flex-shrink-0">
          <ArrowLeft className="w-5 h-5 text-gray-400"/>
        </button>
        <div>
          <h1 className="text-xl font-black flex items-center gap-2"><ClipboardList className="w-5 h-5 text-neon"/>Editar OS</h1>
          <p className="text-xs text-gray-500 truncate">{form.clienteNome} — {form.marca} {form.modelo}</p>
        </div>
      </div>

      <div className="flex flex-col gap-4 mb-6">
        <div>
          <label className="lbl">Cliente *</label>
          <select value={form.clienteId} onChange={e=>{const c=clis.find(x=>x.id===e.target.value);set('clienteId',e.target.value);set('clienteNome',c?.nome||'')}} className="input-dark">
            <option value="">Selecione...</option>
            {clis.map(c=><option key={c.id} value={c.id}>{c.nome}</option>)}
          </select>
        </div>

        <MarcaModeloSelector
          marca={form.marca} modelo={form.modelo}
          onMarca={v=>set('marca',v)} onModelo={v=>set('modelo',v)}
        />

        <div className="grid grid-cols-2 gap-3">
          <div><label className="lbl">IMEI / Serial</label><input type="text" value={form.imei} onChange={e=>set('imei',e.target.value)} className="input-dark"/></div>
          <div><label className="lbl">Cor</label><input type="text" value={form.cor} onChange={e=>set('cor',e.target.value)} className="input-dark"/></div>
          <div><label className="lbl">Senha</label><input type="text" value={form.senha} onChange={e=>set('senha',e.target.value)} className="input-dark"/></div>
          <div><label className="lbl">Data prevista</label><input type="date" value={form.dataPrevista} onChange={e=>set('dataPrevista',e.target.value)} className="input-dark"/></div>
        </div>

        <div><label className="lbl">Defeito relatado</label><textarea value={form.defeito} onChange={e=>set('defeito',e.target.value)} rows={3} className="input-dark resize-none"/></div>
        <div><label className="lbl">Obs. técnicas</label><textarea value={form.observacoes} onChange={e=>set('observacoes',e.target.value)} rows={2} className="input-dark resize-none"/></div>

        <div>
          <label className="lbl">Valor cobrado do cliente (R$)</label>
          <input type="number" value={form.valorTotal} onChange={e=>set('valorTotal',e.target.value)} className="input-dark" step="0.01" placeholder="0,00"/>
        </div>
      </div>

      <div className="flex flex-col gap-2">
        <button onClick={save} disabled={saving} className="btn-neon w-full py-3 text-base">{saving?'Salvando...':'Salvar Alterações'}</button>
        <button onClick={()=>router.back()} className="btn-ghost w-full py-3">Cancelar</button>
      </div>
    </div>
  )
}

export default function EditarOSPage() {
  return (
    <Suspense fallback={<div className="flex justify-center py-20"><div className="w-6 h-6 border-2 border-neon border-t-transparent rounded-full animate-spin"/></div>}>
      <EditarOSInner/>
    </Suspense>
  )
}
