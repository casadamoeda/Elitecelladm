'use client'
import { useEffect, useState } from 'react'
import { getDocs, collection, query, where } from 'firebase/firestore'
import { db as firedb } from '@/lib/firebase'
import { CheckCircle, AlertCircle, ShieldCheck, Calendar, Clock, MessageSquare } from 'lucide-react'

const STATUS_INFO = {
  recebido:             { label:'Aparelho Recebido',        icon:'📥', desc:'Seu aparelho foi recebido e está na fila.' },
  em_analise:           { label:'Em Análise',               icon:'🔍', desc:'Nossos técnicos estão avaliando o problema.' },
  aguardando_aprovacao: { label:'Aguardando sua Aprovação', icon:'⏳', desc:'Enviamos o orçamento. Aguardamos sua confirmação.' },
  aguardando_peca:      { label:'Aguardando Peça',          icon:'🚚', desc:'Peça solicitada ao fornecedor. Em breve chegará.' },
  em_reparo:            { label:'Em Reparo',                icon:'🔧', desc:'Técnico realizando o conserto agora.' },
  testes_finais:        { label:'Testes Finais',            icon:'✅', desc:'Quase pronto! Passando pelos testes de qualidade.' },
  pronto:               { label:'Pronto para Retirada',     icon:'🎉', desc:'Seu aparelho está pronto! Pode vir buscar.' },
  entregue:             { label:'Entregue',                 icon:'✓',  desc:'Aparelho entregue. Obrigado pela confiança!' },
  cancelado:            { label:'Cancelado',                icon:'✗',  desc:'Esta ordem foi cancelada.' },
  sem_reparo:           { label:'Sem Reparo Possível',      icon:'⚠', desc:'Infelizmente não foi possível realizar o conserto.' },
}

const ORDER = ['recebido','em_analise','aguardando_aprovacao','aguardando_peca','em_reparo','testes_finais','pronto','entregue']

export default function AcompanharClient() {
  const [os,      setOs]      = useState(null)
  const [loading, setLoading] = useState(true)
  const [erro,    setErro]    = useState(false)
  const [numero,  setNumero]  = useState('')

  useEffect(() => {
    const path = window.location.pathname.replace(/\/+$/, '')
    const num  = path.split('/').filter(Boolean).pop()
    setNumero(num || '')
    if (!num || num === '_') { setErro(true); setLoading(false); return }

    const tryLocal = async () => {
      try {
        const { localDB } = await import('@/lib/db')
        const rows = await localDB.ordens.filter(r => r.numero === num && r._syncStatus !== 'pending_delete').toArray()
        if (rows.length > 0) return rows[0]
      } catch {}
      return null
    }

    getDocs(query(collection(firedb,'ordens'), where('numero','==',num)))
      .then(snap => {
        if (snap.empty) { setErro(true) }
        else setOs({ id: snap.docs[0].id, ...snap.docs[0].data() })
      })
      .catch(async () => {
        // Offline: tenta buscar do IndexedDB local
        const local = await tryLocal()
        if (local) setOs(local)
        else setErro(true)
      })
      .finally(() => setLoading(false))
  }, [])

  const s = {
    page:  { minHeight:'100dvh', background:'#0a0a0a', padding:'20px 16px', fontFamily:'system-ui,sans-serif' },
    card:  { background:'#111', border:'1px solid rgba(255,255,255,0.08)', borderRadius:20, padding:20, marginBottom:16 },
    lbl:   { fontSize:11, color:'#555', marginBottom:4, letterSpacing:'0.1em', fontWeight:700, textTransform:'uppercase' },
    inner: { background:'rgba(255,255,255,0.03)', borderRadius:12, padding:'12px 14px', marginTop:10 },
    spin:  { width:32, height:32, border:'2px solid #00FF41', borderTopColor:'transparent', borderRadius:'50%', animation:'spin 1s linear infinite', margin:'0 auto' },
    infoRow: { display:'flex', alignItems:'center', gap:10, padding:'10px 0', borderBottom:'1px solid rgba(255,255,255,0.04)', fontSize:13 },
  }

  const statusIdx = os ? ORDER.indexOf(os.status) : -1

  return (
    <div style={s.page}>
      {/* Logo */}
      <div style={{ textAlign:'center', marginBottom:28 }}>
        <p style={{ fontSize:11, color:'#555', letterSpacing:'0.2em', marginBottom:4 }}>ASSISTÊNCIA TÉCNICA</p>
        <h1 style={{ fontSize:24, fontWeight:900, color:'#fff', letterSpacing:'-0.5px' }}>
          ELITE<span style={{ color:'#00FF41' }}>CELL</span>
        </h1>
      </div>

      {loading && (
        <div style={{ textAlign:'center', paddingTop:60 }}>
          <div style={s.spin}/>
          <p style={{ color:'#555', marginTop:16, fontSize:13 }}>Buscando ordem...</p>
        </div>
      )}

      {erro && !loading && (
        <div style={{ textAlign:'center', paddingTop:60 }}>
          <AlertCircle size={40} color="#ef4444" style={{ margin:'0 auto 12px' }}/>
          <p style={{ color:'#ef4444', fontWeight:700 }}>Ordem não encontrada</p>
          <p style={{ color:'#555', fontSize:12, marginTop:6 }}>Verifique o número {numero ? `#${numero}` : 'informado'}</p>
        </div>
      )}

      {os && !loading && (() => {
        const info = STATUS_INFO[os.status] || STATUS_INFO.recebido
        return (
          <div style={{ maxWidth:480, margin:'0 auto' }}>
            {/* Status principal */}
            <div style={s.card}>
              <div style={{ display:'flex', alignItems:'center', gap:12, marginBottom:16 }}>
                <div style={{ width:48, height:48, borderRadius:14, background:'rgba(0,255,65,0.1)', border:'1px solid rgba(0,255,65,0.2)', display:'flex', alignItems:'center', justifyContent:'center', fontSize:22 }}>
                  {info.icon}
                </div>
                <div>
                  <p style={s.lbl}>OS #{os.numero}</p>
                  <p style={{ fontSize:16, fontWeight:900, color:'#fff' }}>{info.label}</p>
                </div>
              </div>
              <p style={{ fontSize:13, color:'#888', lineHeight:1.5, marginBottom:16 }}>{info.desc}</p>

              {/* Aparelho */}
              <div style={s.inner}>
                <p style={s.lbl}>APARELHO</p>
                <p style={{ fontSize:14, fontWeight:700, color:'#fff' }}>{os.marca} {os.modelo}</p>
                {os.cor && <p style={{ fontSize:12, color:'#666', marginTop:2 }}>{os.cor}</p>}
              </div>

              {/* Defeito */}
              {os.defeito && (
                <div style={s.inner}>
                  <p style={s.lbl}>DEFEITO RELATADO</p>
                  <p style={{ fontSize:13, color:'#aaa', lineHeight:1.4 }}>{os.defeito}</p>
                </div>
              )}
            </div>

            {/* Informações adicionais */}
            <div style={s.card}>
              <p style={{ ...s.lbl, marginBottom:8 }}>INFORMAÇÕES</p>
              {os.dataPrevista && (
                <div style={s.infoRow}>
                  <Calendar size={15} color="#00FF41" style={{flexShrink:0}}/>
                  <div>
                    <p style={{fontSize:11,color:'#555'}}>Data prevista de entrega</p>
                    <p style={{fontSize:13,color:'#fff',fontWeight:600}}>
                      {new Date(os.dataPrevista+'T00:00:00').toLocaleDateString('pt-BR',{weekday:'long',day:'2-digit',month:'long'})}
                    </p>
                  </div>
                </div>
              )}
              {os.observacoes && (
                <div style={{...s.infoRow, borderBottom:'none'}}>
                  <MessageSquare size={15} color="#555" style={{flexShrink:0}}/>
                  <div>
                    <p style={{fontSize:11,color:'#555'}}>Observações técnicas</p>
                    <p style={{fontSize:13,color:'#aaa',lineHeight:1.4}}>{os.observacoes}</p>
                  </div>
                </div>
              )}
              {!os.dataPrevista && !os.observacoes && (
                <p style={{fontSize:12,color:'#444',textAlign:'center',padding:'8px 0'}}>Sem informações adicionais</p>
              )}
            </div>

            {/* Timeline */}
            <div style={s.card}>
              <p style={{ ...s.lbl, marginBottom:14 }}>PROGRESSO</p>
              {ORDER.map((st, i) => {
                const inf    = STATUS_INFO[st]
                const done   = i < statusIdx || os.status === 'entregue'
                const active = st === os.status
                return (
                  <div key={st} style={{ display:'flex', gap:12, paddingBottom: i < ORDER.length-1 ? 16 : 0, position:'relative' }}>
                    {i < ORDER.length-1 && (
                      <div style={{ position:'absolute', left:15, top:28, bottom:0, width:2, background: done ? '#00FF41' : 'rgba(255,255,255,0.08)' }}/>
                    )}
                    <div style={{ width:30, height:30, borderRadius:'50%', flexShrink:0, zIndex:1, display:'flex', alignItems:'center', justifyContent:'center',
                      background: active ? '#00FF41' : done ? 'rgba(0,255,65,0.2)' : 'rgba(255,255,255,0.04)',
                      border:`1.5px solid ${active ? '#00FF41' : done ? 'rgba(0,255,65,0.4)' : 'rgba(255,255,255,0.08)'}`,
                    }}>
                      {done && !active ? <CheckCircle size={14} color="#00FF41"/>
                        : active ? <span style={{fontSize:13}}>{inf.icon}</span>
                        : <span style={{fontSize:10,color:'#333'}}>·</span>}
                    </div>
                    <div style={{ paddingTop:4 }}>
                      <p style={{ fontSize:13, fontWeight: active ? 700 : 400, color: active ? '#fff' : done ? '#555' : '#333' }}>
                        {inf.label}
                      </p>
                      {active && os.dataPrevista && st !== 'entregue' && (
                        <p style={{fontSize:11,color:'#00FF41',marginTop:2}}>
                          Previsão: {new Date(os.dataPrevista+'T00:00:00').toLocaleDateString('pt-BR')}
                        </p>
                      )}
                    </div>
                  </div>
                )
              })}
            </div>

            {/* Garantia */}
            {os.finalizacao && (
              <div style={{ background:'rgba(0,255,65,0.05)', border:'1px solid rgba(0,255,65,0.2)', borderRadius:20, padding:20, marginBottom:16 }}>
                <p style={{ fontSize:11, color:'#00FF41', marginBottom:10, display:'flex', alignItems:'center', gap:6, fontWeight:700 }}>
                  <ShieldCheck size={13}/> GARANTIA
                </p>
                {os.finalizacao.pecasResumo?.length > 0 && <p style={{fontSize:13,color:'#aaa'}}>Peças: <span style={{color:'#fff',fontWeight:600}}>{os.finalizacao.pecasResumo.join(', ')}</span></p>}
                {os.finalizacao.garantiaDias && <p style={{fontSize:13,color:'#aaa',marginTop:4}}>Período: <span style={{color:'#fff',fontWeight:600}}>{os.finalizacao.garantiaDias} dias</span></p>}
                {os.finalizacao.dataEntrega && (
                  <p style={{fontSize:13,color:'#aaa',marginTop:4}}>
                    Entregue em: <span style={{color:'#fff',fontWeight:600}}>{new Date(os.finalizacao.dataEntrega).toLocaleDateString('pt-BR')}</span>
                  </p>
                )}
              </div>
            )}

            <p style={{ textAlign:'center', fontSize:11, color:'#333', marginTop:20 }}>
              Dúvidas? Entre em contato com a loja.
            </p>
          </div>
        )
      })()}

      <style>{`@keyframes spin { to { transform:rotate(360deg) } }`}</style>
    </div>
  )
}
