'use client'
import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { financeiro as db } from '@/lib/firestore'
import toast from 'react-hot-toast'
import { ArrowLeft, DollarSign } from 'lucide-react'

const CATS_IN  = ['Serviço','Sinal','PIX','Dinheiro','Cartão','Transferência','Outros']
const CATS_OUT = ['Compra de peça','Ferramenta','Energia','Internet','Transporte','Alimentação','Outros']

export default function NovoLancamentoPage() {
  const router = useRouter()
  const [form, setForm] = useState({ tipo:'entrada', categoria:'', descricao:'', valor:'', formaPagamento:'PIX' })
  const [saving, setSaving] = useState(false)
  const set = (f,v) => setForm(p=>({...p,[f]:v}))

  const save = async () => {
    if (!form.categoria) return toast.error('Selecione categoria')
    if (!form.valor)     return toast.error('Informe o valor')
    setSaving(true)
    try {
      await db.add({...form, valor: parseFloat(form.valor)})
      toast.success('Lançamento salvo!')
      router.back()
    } catch { toast.error('Erro ao salvar') } finally { setSaving(false) }
  }

  return (
    <div className="fu">
      <div className="flex items-center gap-3 mb-6">
        <button onClick={()=>router.back()} className="p-2 hover:bg-surface-light rounded-lg transition-colors flex-shrink-0">
          <ArrowLeft className="w-5 h-5 text-gray-400"/>
        </button>
        <div>
          <h1 className="text-xl font-black flex items-center gap-2"><DollarSign className="w-5 h-5 text-neon"/>Novo Lançamento</h1>
          <p className="text-xs text-gray-500">Entrada ou saída de caixa</p>
        </div>
      </div>

      <div className="flex flex-col gap-4 mb-6">
        <div>
          <label className="lbl">Tipo</label>
          <div className="flex gap-3">
            {[['entrada','↑ Entrada'],['saida','↓ Saída']].map(([v,l])=>(
              <button key={v} type="button" onClick={()=>{set('tipo',v);set('categoria','')}}
                className={`flex-1 py-3 rounded-xl text-sm font-bold border transition-all ${form.tipo===v?(v==='entrada'?'bg-neon/10 border-neon/40 text-neon':'bg-red-500/10 border-red-500/40 text-red-400'):'border-surface-border text-gray-500'}`}>
                {l}
              </button>
            ))}
          </div>
        </div>

        <div>
          <label className="lbl">Categoria</label>
          <select value={form.categoria} onChange={e=>set('categoria',e.target.value)} className="input-dark">
            <option value="">Selecione...</option>
            {(form.tipo==='entrada'?CATS_IN:CATS_OUT).map(c=><option key={c} value={c}>{c}</option>)}
          </select>
        </div>

        <div>
          <label className="lbl">Descrição</label>
          <input type="text" value={form.descricao} onChange={e=>set('descricao',e.target.value)} className="input-dark" placeholder="Detalhes do lançamento..."/>
        </div>

        <div>
          <label className="lbl">Valor (R$)</label>
          <input type="number" value={form.valor} onChange={e=>set('valor',e.target.value)} className="input-dark" step="0.01" placeholder="0,00" autoFocus/>
        </div>

        {form.tipo==='entrada' && (
          <div>
            <label className="lbl">Forma de pagamento</label>
            <div className="grid grid-cols-3 gap-2">
              {['PIX','Dinheiro','Cartão crédito','Cartão débito','Transferência','Outro'].map(f=>(
                <button key={f} type="button" onClick={()=>set('formaPagamento',f)}
                  className={`py-2 rounded-lg text-xs font-bold border transition-all ${form.formaPagamento===f?'bg-neon/10 border-neon/40 text-neon':'border-surface-border text-gray-500'}`}>
                  {f}
                </button>
              ))}
            </div>
          </div>
        )}
      </div>

      <div className="flex flex-col gap-2">
        <button onClick={save} disabled={saving} className="btn-neon w-full py-3 text-base">
          {saving?'Salvando...':'Salvar Lançamento'}
        </button>
        <button onClick={()=>router.back()} className="btn-ghost w-full py-3">Cancelar</button>
      </div>
    </div>
  )
}
