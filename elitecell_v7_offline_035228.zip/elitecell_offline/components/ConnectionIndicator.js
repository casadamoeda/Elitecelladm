'use client'
/**
 * ELITECELL — Indicador de Conexão
 * Mostra 🟢 Online / 🔴 Offline / 🔄 Sincronizando no topo do app.
 */
import { useConnection } from '@/lib/contexts/ConnectionContext'
import { useRouter } from 'next/navigation'
import { RefreshCw, Wifi, WifiOff, CheckCircle2 } from 'lucide-react'

export default function ConnectionIndicator() {
  const { online, status, pending, lastSync } = useConnection()
  const router = useRouter()

  const configs = {
    synced:   { icon: <CheckCircle2 className="w-3 h-3" />, text: 'Online', color: 'text-neon',    bg: 'bg-neon/10    border-neon/20'    },
    syncing:  { icon: <RefreshCw    className="w-3 h-3 animate-spin" />, text: 'Sincronizando...', color: 'text-yellow-400', bg: 'bg-yellow-500/10 border-yellow-500/20' },
    offline:  { icon: <WifiOff      className="w-3 h-3" />, text: 'Offline', color: 'text-red-400', bg: 'bg-red-500/10  border-red-500/20'  },
    error:    { icon: <WifiOff      className="w-3 h-3" />, text: 'Erro de sync', color: 'text-orange-400', bg: 'bg-orange-500/10 border-orange-500/20' },
  }

  const cfg = configs[status] || configs.synced

  return (
    <button
      onClick={() => router.push('/sincronizacao')}
      className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full border text-xs font-medium transition-all ${cfg.color} ${cfg.bg}`}
      title={pending > 0 ? `${pending} registros pendentes` : 'Clique para detalhes'}
    >
      {cfg.icon}
      <span>{cfg.text}</span>
      {pending > 0 && (
        <span className="bg-yellow-400 text-black text-[10px] font-black px-1.5 py-0.5 rounded-full leading-none">
          {pending}
        </span>
      )}
    </button>
  )
}
