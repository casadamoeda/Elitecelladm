import Link from 'next/link'
export default function NotFound(){return(<div className="min-h-screen bg-dark flex items-center justify-center"><div className="text-center"><p className="text-6xl font-black text-neon mb-2">404</p><p className="text-gray-400 mb-6">Página não encontrada</p><Link href="/dashboard" className="btn-neon">Voltar ao Dashboard</Link></div></div>)}
