'use client'
import { useEffect, useRef, useState, Suspense } from 'react'
import { useRouter, useSearchParams } from 'next/navigation'
import { ordens as db, clientes as cliDb } from '@/lib/firestore'
import toast from 'react-hot-toast'
import {
  ArrowLeft, ClipboardList, Search, UserPlus, CheckCircle,
  XCircle, MinusCircle, Wifi, Camera, Bluetooth, Mic,
  Volume2, BatteryCharging, Smartphone, Fingerprint, ChevronDown, Lock, Signal
} from 'lucide-react'

// ── Marcas e modelos pré-cadastrados ────────────────────
const MARCAS_MODELOS = {
  'Samsung': ['Galaxy A05','Galaxy A05s','Galaxy A15','Galaxy A15 5G','Galaxy A25','Galaxy A35','Galaxy A55','Galaxy A14','Galaxy A34','Galaxy A54','Galaxy M14','Galaxy M15','Galaxy M35','Galaxy S21','Galaxy S22','Galaxy S23','Galaxy S24','Galaxy S24 Ultra','Galaxy Z Flip 5','Galaxy Z Fold 5','Outro Samsung'],
  'Apple': ['iPhone 11','iPhone 11 Pro','iPhone 12','iPhone 12 Pro','iPhone 12 Pro Max','iPhone 13','iPhone 13 Pro','iPhone 13 Pro Max','iPhone 14','iPhone 14 Pro','iPhone 14 Pro Max','iPhone 15','iPhone 15 Pro','iPhone 15 Pro Max','iPhone SE (2020)','iPhone SE (2022)','Outro iPhone'],
  'Motorola': ['Moto G04','Moto G04s','Moto G14','Moto G24','Moto G34','Moto G54','Moto G84','Moto G100','Edge 30','Edge 40','Edge 40 Neo','Edge 50','Moto E22','Moto E32','Moto G Power 2024','Outro Motorola'],
  'Xiaomi': ['Redmi 12','Redmi 12C','Redmi 13C','Redmi Note 12','Redmi Note 13','Redmi Note 13 Pro','Redmi A2','Redmi A3','Poco X5','Poco X6','Poco X6 Pro','Poco M5','Poco M6','Outro Xiaomi'],
  'Realme': ['C30','C33','C51','C53','C55','C67','9i','10','11','11 Pro','Narzo 50','Narzo 60','Outro Realme'],
  'Infinix': ['Hot 20','Hot 30','Hot 30i','Hot 40','Hot 40i','Note 30','Note 40','Smart 7','Smart 8','Smart 8 Plus','Outro Infinix'],
  'Tecno': ['Spark 10','Spark 10 Pro','Spark 20','Pop 7','Pop 8','Camon 20','Camon 30','Outro Tecno'],
  'LG': ['K22','K52','K62','Velvet','Wing','Q60','Outro LG'],
  'Outro': [],
}
const MARCAS = Object.keys(MARCAS_MODELOS)

// ── Checklist de recebimento ─────────────────────────────
const CHECKLIST = [
  { id:'tela',      label:'Tela',        Icon: Smartphone   },
  { id:'touch',     label:'Touch',       Icon: Smartphone   },
  { id:'camera_f',  label:'Câm. Frontal',Icon: Camera       },
  { id:'camera_t',  label:'Câm. Traseira',Icon: Camera      },
  { id:'wifi',      label:'Wi-Fi',       Icon: Wifi         },
  { id:'bluetooth', label:'Bluetooth',   Icon: Bluetooth    },
  { id:'microfone', label:'Microfone',   Icon: Mic          },
  { id:'alto_fal',  label:'Alto-falante',Icon: Volume2      },
  { id:'chip',      label:'Chip/SIM',    Icon: Signal       },
  { id:'biometria', label:'Biometria',   Icon: Fingerprint  },
  { id:'botoes',    label:'Botões',      Icon: Smartphone   },
  { id:'carregando',label:'Carregamento',Icon: BatteryCharging},
]
const TESTES_VAZIO = CHECKLIST.reduce((a,t) => ({...a,[t.id]:'nao_testado'}), {})
const TESTES_NENHUM = CHECKLIST.reduce((a,t) => ({...a,[t.id]:'sem_condicoes'}), {})

// ── PatternPad ───────────────────────────────────────────
function PatternPad({ value=[], onChange }) {
  const [drawing, setDrawing] = useState(false)
  const enter = (i) => { if (!drawing||value.includes(i)) return; onChange([...value,i]) }
  const start = (i) => { onChange([i]); setDrawing(true) }
  const end   = ()  => setDrawing(false)
  return (
    <div style={{userSelect:'none',touchAction:'none'}}>
      <div onMouseLeave={end} onTouchEnd={end}
        style={{display:'grid',gridTemplateColumns:'repeat(3,1fr)',gap:12,maxWidth:220,margin:'0 auto'}}>
        {[0,1,2,3,4,5,6,7,8].map(i=>{
          const pos=value.indexOf(i); const used=pos>=0
          return (
            <div key={i} onMouseDown={()=>start(i)} onMouseEnter={()=>enter(i)}
              onTouchStart={e=>{e.preventDefault();start(i)}}
              onTouchMove={e=>{e.preventDefault();const t=e.touches[0];const el=document.elementFromPoint(t.clientX,t.clientY);const idx=el?.dataset?.pidx;if(idx!==undefined)enter(Number(idx))}}
              data-pidx={i}
              style={{width:56,height:56,borderRadius:'50%',border:used?'2px solid #00FF41':'2px solid rgba(255,255,255,0.15)',background:used?'rgba(0,255,65,0.15)':'rgba(255,255,255,0.04)',display:'flex',alignItems:'center',justifyContent:'center',cursor:'pointer',transition:'all .15s',fontSize:13,fontWeight:700,color:used?'#00FF41':'#666'}}>
              {used?pos+1:''}
            </div>
          )
        })}
      </div>
      <p style={{textAlign:'center',fontSize:11,color:'#555',marginTop:8}}>
        {value.length===0?'Toque nos pontos para desenhar o padrão':`Sequência: ${value.map(n=>n+1).join(' → ')}`}
      </p>
      {value.length>0&&<button type="button" onClick={()=>onChange([])} style={{display:'block',margin:'8px auto 0',fontSize:11,color:'#ef4444',background:'none',border:'none',cursor:'pointer'}}>Limpar</button>}
    </div>
  )
}

// ── Busca de cliente ──────────────────────────────────────
function ClienteSearch({ clis, value, onChange, onNovo }) {
  const [q, setQ] = useState('')
  const [open, setOpen] = useState(false)
  const ref = useRef()
  const sel = clis.find(c=>c.id===value)
  const filtrados = q.length>=1 ? clis.filter(c=>c.nome?.toLowerCase().includes(q.toLowerCase())||c.telefone?.includes(q)).slice(0,6) : []
  useEffect(()=>{const h=e=>{if(ref.current&&!ref.current.contains(e.target))setOpen(false)};document.addEventListener('mousedown',h);return()=>document.removeEventListener('mousedown',h)},[])
  if (sel) return (
    <div className="flex items-center gap-2 input-dark">
      <span className="flex-1 text-sm">{sel.nome}</span>
      <button type="button" onClick={()=>{onChange('','');setQ('')}} className="text-gray-500 hover:text-white text-xs">Trocar</button>
    </div>
  )
  return (
    <div ref={ref} style={{position:'relative'}}>
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500"/>
        <input value={q} onChange={e=>{setQ(e.target.value);setOpen(true)}} onFocus={()=>setOpen(true)}
          placeholder="Nome ou telefone..." className="input-dark pl-9" autoComplete="off"/>
      </div>
      {open&&q.length>=1&&(
        <div style={{position:'absolute',top:'100%',left:0,right:0,zIndex:100,background:'#1a1a1a',border:'1px solid rgba(255,255,255,0.1)',borderRadius:10,marginTop:4,overflow:'hidden',boxShadow:'0 8px 32px rgba(0,0,0,0.5)'}}>
          {filtrados.length>0?filtrados.map(c=>(
            <button key={c.id} type="button" onClick={()=>{onChange(c.id,c.nome);setOpen(false);setQ('')}}
              style={{display:'flex',alignItems:'center',gap:10,width:'100%',padding:'10px 14px',textAlign:'left',background:'none',border:'none',cursor:'pointer',borderBottom:'1px solid rgba(255,255,255,0.06)',color:'#fff'}}>
              <div style={{width:32,height:32,borderRadius:'50%',background:'rgba(0,255,65,0.1)',border:'1px solid rgba(0,255,65,0.2)',display:'flex',alignItems:'center',justifyContent:'center',flexShrink:0,fontSize:13,fontWeight:700,color:'#00FF41'}}>{c.nome?.[0]?.toUpperCase()}</div>
              <div><p style={{fontSize:13,fontWeight:600}}>{c.nome}</p>{c.telefone&&<p style={{fontSize:11,color:'#666'}}>{c.telefone}</p>}</div>
            </button>
          )):<p style={{padding:'12px 14px',fontSize:12,color:'#666',textAlign:'center'}}>Nenhum cliente encontrado</p>}
          <button type="button" onClick={()=>{setOpen(false);onNovo(q)}}
            style={{display:'flex',alignItems:'center',gap:8,width:'100%',padding:'10px 14px',background:'rgba(0,255,65,0.05)',border:'none',borderTop:'1px solid rgba(255,255,255,0.06)',cursor:'pointer',color:'#00FF41',fontSize:12,fontWeight:600}}>
            <UserPlus size={14}/> Cadastrar "{q||'novo cliente'}"
          </button>
        </div>
      )}
    </div>
  )
}

// ── Seletor Marca/Modelo ──────────────────────────────────
function MarcaModeloSelector({ marca, modelo, onMarca, onModelo }) {
  const [modeloManual, setModeloManual] = useState(false)
  const modelos = marca && MARCAS_MODELOS[marca] ? MARCAS_MODELOS[marca] : []
  const precisaDigitar = marca === 'Outro' || modeloManual || (modelo && !modelos.includes(modelo) && modelos.length > 0)

  const handleMarca = (m) => {
    onMarca(m); onModelo(''); setModeloManual(false)
  }
  const handleModelo = (m) => {
    if (m === `Outro ${marca}` || m === 'Outro (digitar)' || m === 'Outro') {
      setModeloManual(true); onModelo('')
    } else {
      setModeloManual(false); onModelo(m)
    }
  }

  return (
    <div className="flex flex-col gap-3">
      <div>
        <label className="lbl">Marca *</label>
        <div style={{display:'grid',gridTemplateColumns:'repeat(3,1fr)',gap:6}}>
          {MARCAS.map(m=>(
            <button key={m} type="button" onClick={()=>handleMarca(m)}
              style={{padding:'8px 4px',borderRadius:9,fontSize:11,fontWeight:700,border:'none',cursor:'pointer',transition:'all .15s',
                background:marca===m?'rgba(0,255,65,0.12)':'rgba(255,255,255,0.04)',
                color:marca===m?'#00FF41':'#666',
                boxShadow:marca===m?'inset 0 0 0 1.5px rgba(0,255,65,0.4)':'inset 0 0 0 1px rgba(255,255,255,0.07)'}}>
              {m}
            </button>
          ))}
        </div>
      </div>

      {marca && marca !== 'Outro' && modelos.length > 0 && !modeloManual && (
        <div>
          <label className="lbl">Modelo *</label>
          <select value={modelo} onChange={e=>handleModelo(e.target.value)} className="input-dark">
            <option value="">Selecione o modelo...</option>
            {modelos.map(m=><option key={m} value={m}>{m}</option>)}
          </select>
        </div>
      )}

      {(marca === 'Outro' || modeloManual || (marca && modelos.length === 0)) && (
        <div>
          <label className="lbl">Modelo * <span style={{fontSize:10,color:'#555',fontWeight:400}}>(digitação manual)</span></label>
          <input type="text" value={modelo} onChange={e=>onModelo(e.target.value)} className="input-dark" placeholder="Ex: Galaxy A73, Redmi Note 12..."/>
          {modeloManual && <button type="button" onClick={()=>{setModeloManual(false);onModelo('')}} style={{fontSize:11,color:'#555',background:'none',border:'none',cursor:'pointer',marginTop:4}}>← Ver lista de modelos</button>}
        </div>
      )}
    </div>
  )
}

// ── Item de Teste ─────────────────────────────────────────
function TesteBtn({ label, Icon, status, onChange }) {
  const cfg = {
    ok:           {color:'#00FF41',bg:'rgba(0,255,65,.12)',   border:'rgba(0,255,65,.3)',   Icon:CheckCircle,  txt:'OK'},
    defeito:      {color:'#ef4444',bg:'rgba(239,68,68,.12)',  border:'rgba(239,68,68,.3)',  Icon:XCircle,      txt:'Defeito'},
    nao_testado:  {color:'#555',   bg:'rgba(255,255,255,.04)',border:'rgba(255,255,255,.1)',Icon:MinusCircle,  txt:'N/T'},
    sem_condicoes:{color:'#888',   bg:'rgba(255,255,255,.04)',border:'rgba(255,255,255,.08)',Icon:MinusCircle, txt:'—'},
  }
  const c = cfg[status] || cfg.nao_testado
  const cycle = () => {
    if (status==='sem_condicoes') return
    onChange(status==='nao_testado'?'ok':status==='ok'?'defeito':'nao_testado')
  }
  return (
    <button type="button" onClick={cycle}
      style={{display:'flex',flexDirection:'column',alignItems:'center',gap:4,padding:'8px 4px',borderRadius:10,border:`1px solid ${c.border}`,background:c.bg,cursor:status==='sem_condicoes'?'default':'pointer',transition:'all .15s'}}>
      <Icon size={16} color={c.color}/>
      <span style={{fontSize:10,color:c.color,fontWeight:600,textAlign:'center',lineHeight:1.2}}>{label}</span>
      <span style={{fontSize:9,color:c.color,fontWeight:700}}>{c.txt}</span>
    </button>
  )
}

const EMPTY = {
  clienteId:'',clienteNome:'',marca:'',modelo:'',imei:'',cor:'',
  defeito:'',senha:'',senhaPatrao:[],tipoSenha:'texto',
  observacoes:'',valorTotal:'',status:'recebido',dataPrevista:'',
  testes:{...TESTES_VAZIO},
}

function NovaOSInner() {
  const router   = useRouter()
  const params   = useSearchParams()
  const [form, setForm]     = useState(EMPTY)
  const [clis, setClis]     = useState([])
  const [saving, setSaving] = useState(false)
  const [loading, setLoad]  = useState(true)
  const [section, setSection] = useState('dados')

  useEffect(() => {
    cliDb.list().then(c => {
      setClis(c)
      const clienteId   = params.get('clienteId')||''
      const clienteNome = params.get('clienteNome')||''
      if (clienteId) setForm(p=>({...p,clienteId,clienteNome}))
      else if (clienteNome) {
        const cli = c.find(x=>x.nome===clienteNome)
        setForm(p=>({...p,clienteId:cli?.id||'',clienteNome}))
      }
      setLoad(false)
    })
  }, [])

  const set = (f,v) => setForm(p=>({...p,[f]:v}))
  const setTeste = (id,v) => setForm(p=>({...p,testes:{...p.testes,[id]:v}}))
  const semTestes = () => setForm(p=>({...p,testes:{...TESTES_NENHUM}}))
  const resetTestes = () => setForm(p=>({...p,testes:{...TESTES_VAZIO}}))

  const save = async () => {
    if (!form.clienteId) return toast.error('Selecione um cliente')
    if (!form.modelo)    return toast.error('Informe o modelo')
    setSaving(true)
    try {
      const senhaFinal = form.tipoSenha==='padrao'
        ? form.senhaPatrao.map(n=>n+1).join('-')
        : form.senha
      await db.add({
        ...form,
        senha: senhaFinal,
        senhaPatrao: form.tipoSenha==='padrao' ? form.senhaPatrao : [],
        valorTotal: parseFloat(form.valorTotal)||0,
        // compat: mantém valorServico = valorTotal para dashboard legado
        valorServico: parseFloat(form.valorTotal)||0,
        valorPeca: 0,
      })
      toast.success('OS criada!')
      router.back()
    } catch { toast.error('Erro ao salvar') } finally { setSaving(false) }
  }

  const isSemCondicoes = Object.values(form.testes).every(v=>v==='sem_condicoes')

  if (loading) return <div className="flex justify-center py-20"><div className="w-6 h-6 border-2 border-neon border-t-transparent rounded-full animate-spin"/></div>

  const tabs = [['dados','Dados'],['checklist','Checklist'],['senha','Senha']]

  return (
    <div className="fu">
      <div className="flex items-center gap-3 mb-5">
        <button onClick={()=>router.back()} className="p-2 hover:bg-surface-light rounded-lg transition-colors flex-shrink-0">
          <ArrowLeft className="w-5 h-5 text-gray-400"/>
        </button>
        <div>
          <h1 className="text-xl font-black flex items-center gap-2"><ClipboardList className="w-5 h-5 text-neon"/>Nova OS</h1>
          <p className="text-xs text-gray-500">Ordem de serviço</p>
        </div>
      </div>

      {/* Abas */}
      <div style={{display:'flex',gap:4,marginBottom:20,background:'rgba(255,255,255,0.04)',borderRadius:12,padding:4}}>
        {tabs.map(([id,l])=>(
          <button key={id} type="button" onClick={()=>setSection(id)}
            style={{flex:1,padding:'8px 4px',borderRadius:9,fontSize:12,fontWeight:700,border:'none',cursor:'pointer',transition:'all .2s',
              background:section===id?'#00FF41':'transparent',color:section===id?'#000':'#666'}}>
            {l}
          </button>
        ))}
      </div>

      {/* ─── DADOS ─── */}
      {section==='dados' && (
        <div className="flex flex-col gap-4">
          <div>
            <label className="lbl">Cliente *</label>
            <ClienteSearch clis={clis} value={form.clienteId}
              onChange={(id,nome)=>{set('clienteId',id);set('clienteNome',nome)}}
              onNovo={nome=>router.push(`/clientes/novo?nome=${encodeURIComponent(nome)}&retorno=/ordens/nova`)}
            />
          </div>

          <MarcaModeloSelector
            marca={form.marca} modelo={form.modelo}
            onMarca={v=>set('marca',v)} onModelo={v=>set('modelo',v)}
          />

          <div className="grid grid-cols-2 gap-3">
            <div><label className="lbl">IMEI / Serial</label><input type="text" value={form.imei} onChange={e=>set('imei',e.target.value)} className="input-dark"/></div>
            <div><label className="lbl">Cor</label><input type="text" value={form.cor} onChange={e=>set('cor',e.target.value)} className="input-dark"/></div>
            <div className="col-span-2"><label className="lbl">Data prevista</label><input type="date" value={form.dataPrevista} onChange={e=>set('dataPrevista',e.target.value)} className="input-dark"/></div>
          </div>

          <div>
            <label className="lbl">Defeito relatado</label>
            <textarea value={form.defeito} onChange={e=>set('defeito',e.target.value)} rows={3} className="input-dark resize-none" placeholder="Descreva o defeito reportado..."/>
          </div>
          <div>
            <label className="lbl">Obs. técnicas</label>
            <textarea value={form.observacoes} onChange={e=>set('observacoes',e.target.value)} rows={2} className="input-dark resize-none" placeholder="Estado do aparelho, riscos, avarias..."/>
          </div>

          <div>
            <label className="lbl">Valor cobrado do cliente (R$)</label>
            <input type="number" value={form.valorTotal} onChange={e=>set('valorTotal',e.target.value)} className="input-dark" step="0.01" placeholder="0,00"/>
            <p className="text-xs text-gray-600 mt-1">Custo das peças é registrado separadamente nas Peças da OS</p>
          </div>

          <button type="button" onClick={()=>setSection('checklist')} className="btn-ghost w-full">
            Próximo: Checklist de Recebimento →
          </button>
        </div>
      )}

      {/* ─── CHECKLIST ─── */}
      {section==='checklist' && (
        <div className="flex flex-col gap-5">
          <div>
            <p className="lbl mb-1">Checklist de Recebimento</p>
            <p className="text-xs text-gray-500 mb-4">Toque para alternar: — Não testado → ✓ OK → ✗ Defeito</p>

            {/* Botão sem condições */}
            <button type="button" onClick={isSemCondicoes ? resetTestes : semTestes}
              style={{width:'100%',padding:'12px',borderRadius:12,marginBottom:16,fontSize:12,fontWeight:700,cursor:'pointer',transition:'all .2s',
                background:isSemCondicoes?'rgba(239,68,68,0.12)':'rgba(255,255,255,0.04)',
                border:isSemCondicoes?'1.5px solid rgba(239,68,68,0.4)':'1px solid rgba(255,255,255,0.1)',
                color:isSemCondicoes?'#ef4444':'#666'}}>
              {isSemCondicoes ? '✗ Aparelho sem condições de teste (clique para desfazer)' : '⚠ Não foi possível realizar nenhum teste'}
            </button>

            <div style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:8}}>
              {CHECKLIST.map(t=>(
                <TesteBtn key={t.id} label={t.label} Icon={t.Icon}
                  status={form.testes[t.id]||'nao_testado'}
                  onChange={v=>setTeste(t.id,v)}/>
              ))}
            </div>
          </div>

          {!isSemCondicoes && Object.values(form.testes).some(v=>v!=='nao_testado') && (
            <div style={{background:'rgba(255,255,255,0.03)',borderRadius:10,padding:12}}>
              <div style={{display:'flex',gap:16,fontSize:12}}>
                <span style={{color:'#00FF41'}}>✓ {Object.values(form.testes).filter(v=>v==='ok').length} OK</span>
                <span style={{color:'#ef4444'}}>✗ {Object.values(form.testes).filter(v=>v==='defeito').length} defeito</span>
                <span style={{color:'#555'}}>— {Object.values(form.testes).filter(v=>v==='nao_testado').length} n/t</span>
              </div>
            </div>
          )}

          <div className="flex flex-col gap-2 pt-2">
            <button type="button" onClick={()=>setSection('senha')} className="btn-ghost w-full">Próximo: Senha / Padrão →</button>
            <button type="button" onClick={()=>setSection('dados')} style={{fontSize:12,color:'#555',background:'none',border:'none',cursor:'pointer',padding:'8px'}}>← Voltar</button>
          </div>
        </div>
      )}

      {/* ─── SENHA ─── */}
      {section==='senha' && (
        <div className="flex flex-col gap-5">
          <div>
            <label className="lbl">Tipo de desbloqueio</label>
            <div style={{display:'flex',gap:8,marginTop:4}}>
              {[['texto','PIN / Senha'],['padrao','Padrão visual']].map(([v,l])=>(
                <button key={v} type="button" onClick={()=>set('tipoSenha',v)}
                  style={{flex:1,padding:'10px 8px',borderRadius:10,fontSize:12,fontWeight:700,cursor:'pointer',
                    border:form.tipoSenha===v?'1.5px solid #00FF41':'1px solid rgba(255,255,255,0.1)',
                    background:form.tipoSenha===v?'rgba(0,255,65,0.1)':'rgba(255,255,255,0.03)',
                    color:form.tipoSenha===v?'#00FF41':'#666',
                    display:'flex',alignItems:'center',justifyContent:'center',gap:6}}>
                  <Lock size={13}/>{l}
                </button>
              ))}
            </div>
          </div>

          {form.tipoSenha==='texto'
            ? <div><label className="lbl">Senha / PIN</label><input type="text" value={form.senha} onChange={e=>set('senha',e.target.value)} className="input-dark" placeholder="Ex: 1234, 0000..."/></div>
            : <div><label className="lbl" style={{textAlign:'center',display:'block',marginBottom:16}}>Desenhe o padrão</label><PatternPad value={form.senhaPatrao} onChange={v=>set('senhaPatrao',v)}/></div>
          }

          <div className="flex flex-col gap-2 pt-4">
            <button type="button" onClick={save} disabled={saving} className="btn-neon w-full py-3 text-base">
              {saving?'Salvando...':'Criar OS'}
            </button>
            <button type="button" onClick={()=>setSection('checklist')} style={{fontSize:12,color:'#555',background:'none',border:'none',cursor:'pointer',padding:'8px'}}>← Voltar</button>
          </div>
        </div>
      )}
    </div>
  )
}

export default function NovaOSPage() {
  return (
    <Suspense fallback={<div className="flex justify-center py-20"><div className="w-6 h-6 border-2 border-neon border-t-transparent rounded-full animate-spin"/></div>}>
      <NovaOSInner/>
    </Suspense>
  )
}
