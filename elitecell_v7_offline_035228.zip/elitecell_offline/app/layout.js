import { Toaster } from 'react-hot-toast'
import { AuthProvider } from '@/lib/contexts/AuthContext'
import { ConnectionProvider } from '@/lib/contexts/ConnectionContext'
import RegisterSW from '@/components/RegisterSW'
import './globals.css'

export const metadata = {
  title: 'ELITECELL — Assistência Técnica',
  description: 'Sistema de Gestão ELITECELL Assistência Técnica e Acessórios',
  manifest: '/manifest.json',
  appleWebApp: {
    capable: true,
    statusBarStyle: 'black-translucent',
    title: 'ELITECELL',
  },
}

export const viewport = {
  themeColor: '#00FF41',
  width: 'device-width',
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
  viewportFit: 'cover',
}

export default function RootLayout({ children }) {
  return (
    <html lang="pt-BR">
      <head>
        <link rel="manifest" href="/manifest.json" />
        <meta name="theme-color" content="#00FF41" />
        <meta name="mobile-web-app-capable" content="yes" />
        <meta name="application-name" content="ELITECELL" />
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />
        <meta name="apple-mobile-web-app-title" content="ELITECELL" />
        <link rel="apple-touch-icon" href="/apple-touch-icon.png" />
        <link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon.png" />
        <link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png" />
        <link rel="icon" href="/favicon.ico" />
        <meta name="msapplication-TileColor" content="#0A0A0A" />
        <meta name="msapplication-TileImage" content="/icon-192.png" />
      </head>
      <body>
        <AuthProvider>
          <ConnectionProvider>
            {children}
            <Toaster
              position="top-center"
              toastOptions={{
                style: { background:'#161616', color:'#fff', border:'1px solid #222', fontSize:13 },
                success: { iconTheme: { primary:'#00FF41', secondary:'#000' } },
              }}
            />
          </ConnectionProvider>
        </AuthProvider>
        <RegisterSW />
      </body>
    </html>
  )
}
